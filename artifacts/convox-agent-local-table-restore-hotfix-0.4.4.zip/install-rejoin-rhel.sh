#!/usr/bin/env bash
# Upgrade an existing control agent for guarded reseed/rejoin support.
# It never starts/stops services, changes a database role, or begins replication.
set -Eeuo pipefail
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
[[ $EUID == 0 && $# == 1 ]] || fail 'Usage as root: install-rejoin-rhel.sh production|dr'
HOST="$1"
case "$HOST" in
    production) PEER_IP=10.3.0.150 ;;
    dr) PEER_IP=10.81.0.11 ;;
    *) fail 'Select production or dr.' ;;
esac
SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
for CMD in flock install python3 restorecon rsync ssh stat; do command -v "$CMD" >/dev/null || fail "Missing: $CMD"; done
[[ -f "$SOURCE_DIR/convox-console-control.py" ]] || fail 'Updated control agent is missing.'
[[ -f /etc/convox-console-agent/control.json && -x /usr/local/libexec/convox-console-control ]] || fail 'Install and configure the control agent first.'
exec 9>/var/lock/convox-console-rejoin-install.lock
flock -n 9 || fail 'Another console upgrade is running.'
exec 8>>/var/lib/convox-console-agent/agent.lock
flock -n 8 || fail 'The control agent is currently running.'
[[ ! -e /var/lib/convox-console-agent/operation.json ]] || fail 'A console operation is reserved. Finish or reconcile it before upgrading.'

python3 - "$HOST" <<'PY'
import json, pathlib, sys
cfg = json.loads(pathlib.Path('/etc/convox-console-agent/control.json').read_text())
if cfg.get('host') != sys.argv[1] or cfg.get('adminReviewedStartup') is not True:
    raise SystemExit('Agent identity/startup review is not ready')
PY

[[ -f /root/convox-repl-password ]] || fail 'Missing /root/convox-repl-password.'
[[ "$(stat -c '%U:%a' /root/convox-repl-password)" == 'root:600' ]] || fail 'Replication password must be root-owned mode 0600.'
grep -Eq '^[A-Za-z0-9_.@%+=:-]{16,128}$' /root/convox-repl-password || fail 'Replication password format is unsafe or unsupported.'
[[ -f /root/.ssh/convox-file-sync && -f /root/.ssh/known_hosts ]] || fail 'Pinned file-sync key or known_hosts file is missing.'
getent passwd convoxsync >/dev/null || fail 'convoxsync account is missing.'
ssh -T -F /dev/null -o BatchMode=yes -o StrictHostKeyChecking=yes \
    -o UserKnownHostsFile=/root/.ssh/known_hosts -o IdentitiesOnly=yes \
    -o IdentityAgent=none -o ClearAllForwardings=yes -o ConnectTimeout=5 \
    -i /root/.ssh/convox-file-sync "convoxsync@$PEER_IP" true || fail 'Reciprocal pinned file-copy SSH failed.'

STAMP="$(date '+%Y%m%d-%H%M%S')"
install -d -o root -g "$(id -gn convoxsync)" -m 0770 /var/lib/convox-console-transfer
if [[ -e /etc/my.cnf.d/95-convox-console-replica.cnf ]]; then
    cp -p /etc/my.cnf.d/95-convox-console-replica.cnf "/root/95-convox-console-replica.cnf.before-$STAMP"
fi
install -o root -g mysql -m 0640 /dev/null /etc/my.cnf.d/95-convox-console-replica.cnf
printf '%s\n' \
    '[mysqld]' \
    'log_slave_updates=ON' \
    'relay_log_recovery=ON' \
    'replicate_wild_ignore_table=convoxcces_global.convoxccs_license_details' \
    'replicate_wild_ignore_table=convoxcces_global.convoxccs_notifications' \
    'replicate_wild_ignore_table=convoxcces_global.convoxccs_servers' \
    'replicate_wild_ignore_table=convoxcces_global.convoxccs_web_servers' \
    > /etc/my.cnf.d/95-convox-console-replica.cnf
cp -p /usr/local/libexec/convox-console-control "/root/convox-console-control.before-$STAMP"
install -o root -g root -m 0755 "$SOURCE_DIR/convox-console-control.py" /usr/local/libexec/convox-console-control
restorecon -RF /var/lib/convox-console-transfer /etc/my.cnf.d/95-convox-console-replica.cnf /usr/local/libexec/convox-console-control
python3 -m py_compile /usr/local/libexec/convox-console-control
printf 'Rejoin-capable agent installed. No service, database role, replication, or application process was changed.\n'
