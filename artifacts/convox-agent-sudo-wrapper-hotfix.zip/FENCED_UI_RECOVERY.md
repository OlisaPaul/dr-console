# 0.3.1: operator-confirmed recovery of the fenced, clock-failed cutover

This is a locally tested UAT update, not a remote deployment or proof of call
readiness. It adds **Recover fenced cutover** to control mode. The current job
must remain reserved: do not reconcile it, restart production, delete state or
manually promote DR while installing this update.

## What the action does

Only the latest failed planned promotion with the recorded clock-evidence error
is eligible. Source database/application fencing must still be verified over SSH.
The target must remain read-only, application-fenced and at its caught-up GTID,
with its original source connection and SQL thread intact. IO may be reconnecting
because production's database is intentionally stopped.

The agent rechecks target identity, role, local mappings/filters, startup syntax
and service files. It compares all eight file roots with checksum dry-runs (no
copy, delete, chmod or ownership change), then rechecks the source's persistent
database/application fence. Only then does it issue NEW job/GTID-bound signed
boundary/file/fence evidence. The captured GTID is retained under the verified
unchanged fence; no old receipt is edited or replayed. A new fence receipt is
required immediately before promotion. Existing freshness limits remain intact.

The target performs the usual guarded promotion and approved runtime startup.
No database restore, RESET MASTER, carrier routing or returning-source startup
occurs. The old failed attempt remains in the UI job's previousAttempts history
and audit log. A successful recovery still pauses for human routing/call tests.
An interrupted controller never automatically resumes a mutation. Another failed
recovery requires administrator inspection; it is not automatically replayed.

## Temporary manual-clock approval

The installer below is deliberately restricted to job
`d6806999-884d-4cd5-b15c-2490123ad9be`, production -> DR, GTID `0-8111-98296`.
It checks each node's actual fenced/read-only state, failure stage and reserved
job before updating code under the agent's exclusive lock. It preserves the
reservation and makes no service or database change. It saves the old agent and
secret-bearing config in a root-private rollback directory; never paste those.

The installer grants a root-owned manual-clock exception for THIS job only,
expiring one hour after installation on each node. Chrony must be paused and
the administrator must already have aligned production's clock from the trusted
DR clock. This is an explicit temporary UAT allowance, not genuine NTP sync or a
global freshness bypass. If clocks are wrong/drift enough, receipts still fail.
The UI confirmation also attests that nobody restarted the source since fencing.
If IT restores chrony, it must actually synchronize before time checks pass.

All NEW cutovers now require synchronized clocks, a selected NTP/refclock source,
a recent reference and bounded clock uncertainty in preflight, BEFORE source
shutdown. The manual exception cannot authorize another job. It does not affect
continued application runtime after this one recovery; restore NTP with IT.

## One-time deployment

1. Upload `convox-dr-console-fenced-recovery-0.3.1.zip` to archival
   `10.3.0.151`, then extract into a NEW root-private directory:

   ```bash
   install -d -m 0700 /root/convox-fenced-recovery-0.3.1
   unzip /root/convox-dr-console-fenced-recovery-0.3.1.zip -d /root/convox-fenced-recovery-0.3.1
   ```

2. On archival, stop ONLY the management console while updating. Do not stop
   Nginx, change controller mode, delete its state or touch the servers' roles:

   ```bash
   systemctl stop convox-dr-console.service
   ```

   Transfer the ZIP to both hosts using your pinned administrator SSH:

   ```bash
   scp -o StrictHostKeyChecking=yes -o UserKnownHostsFile=/etc/convox-console/ssh/known_hosts /root/convox-dr-console-fenced-recovery-0.3.1.zip root@10.81.0.11:/root/
   scp -o StrictHostKeyChecking=yes -o UserKnownHostsFile=/etc/convox-console/ssh/known_hosts /root/convox-dr-console-fenced-recovery-0.3.1.zip root@10.3.0.150:/root/
   ```

3. As root on BOTH production and DR, while the console remains stopped:

   ```bash
   install -d -m 0700 /root/convox-fenced-recovery-0.3.1
   unzip /root/convox-dr-console-fenced-recovery-0.3.1.zip -d /root/convox-fenced-recovery-0.3.1
   bash /root/convox-fenced-recovery-0.3.1/deploy/install-fenced-recovery-rhel.sh d6806999-884d-4cd5-b15c-2490123ad9be
   ```

   Stop if either installer refuses. Do not bypass its checks or substitute a
   different job ID. It can be rerun before any recovery step if the temporary
   approval expires, provided actual state still satisfies ALL installation
   guards. Do not run the older generic hotfix installer against reservations.

4. On archival, upgrade code (current control mode, data, keys, login, TLS and
   port 443 are preserved) and restart the management console:

   ```bash
   bash /root/convox-fenced-recovery-0.3.1/deploy/upgrade-rhel.sh
   ```

   If the update fails, preserve its reported backup and inspect the console
   journal. No server operation runs simply by restarting the console.

## From the UI

Hard-refresh `https://10.3.0.151`, sign in and click **Refresh status**. Production
should be stopped/fenced and DR read-only. If the **Recover fenced cutover**
panel is not available, stop and share the shown status/error. Do NOT click
Bring DR online (a new job), Reconcile state or Prepare production for this
reserved clock-failed job.

Click **Recover fenced cutover**, read the custody/manual-clock warning and type
`RECOVER FENCED CUTOVER`. This starts real, audited recovery only after your
confirmation. Watch target checks -> source fence/file re-verification ->
fresh-evidence promotion -> runtime startup -> Awaiting team validation.

If anything fails, leave source fenced and inspect the actual state before
continuing. Once Awaiting team validation appears, the team changes test web/SIP
routing and verifies calls, queues, transfers and recording creation/playback.
Only then confirm `I TESTED ROUTING AND CALLS`. Old production remains fenced;
there is still NO automatic rebuild/rejoin, reverse sync or outage failover.
