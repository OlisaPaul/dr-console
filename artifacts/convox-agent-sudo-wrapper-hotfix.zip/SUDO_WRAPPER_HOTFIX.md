# 0.3.1 agent hotfix: exclude only this invocation's verified sudo ancestors

The SSH status path runs `sudo -n /usr/local/libexec/convox-console-control`.
The 0.3.1 process detector marked sudo's argv as another control agent and
therefore falsely reported both applications as unfenced. A direct Python import
did not have this ancestor, explaining the user's different diagnostic results.

The correction ignores the current PID and ONLY its own sudo ancestors whose
executable resolves to `/usr/bin/sudo`, whose argv contains the exact installed
agent token, and which are not vendor processes. Other agents, their launchers,
real workers and the primary runtime remain fencing blockers. All persistent
mask, service state and database-absence checks remain unchanged.

## Package and scope

Use `artifacts/convox-agent-sudo-wrapper-hotfix.zip`. Archival already has the
0.3.1 controller; no controller, Nginx or ConVox code update is needed.

This ZIP contains the corrected agent and the existing, guarded
`install-fenced-recovery-rhel.sh`. That installer is for ONLY reserved job
`d6806999-884d-4cd5-b15c-2490123ad9be`, production -> DR, GTID
`0-8111-98296`. It holds the agent lock, verifies actual fences and the target
read-only GTID, saves private backups and leaves the reservation intact.

IMPORTANT: running this installer also renews that exact job's temporary UAT
manual-clock approval for one hour. It preserves the cluster secret, data,
roles and service masks. It must NOT be used after a recovery step has already
been attempted. Do not use the older generic worker hotfix installer, delete
state, reconcile, unmask production or manually promote DR.

## Installation

1. Upload from Windows:

   ```powershell
   scp "C:\Users\DEEPIJA\Documents\ConVoxCCS\dr-console\artifacts\convox-agent-sudo-wrapper-hotfix.zip" root@10.3.0.151:/root/
   ```

2. On archival, with no operation running, stop ONLY the management console and
   transfer the ZIP using pinned administrator SSH. The webpage will be
   temporarily unavailable while this console is stopped.

   ```bash
   systemctl stop convox-dr-console.service
   scp -o StrictHostKeyChecking=yes -o UserKnownHostsFile=/etc/convox-console/ssh/known_hosts /root/convox-agent-sudo-wrapper-hotfix.zip root@10.81.0.11:/root/
   scp -o StrictHostKeyChecking=yes -o UserKnownHostsFile=/etc/convox-console/ssh/known_hosts /root/convox-agent-sudo-wrapper-hotfix.zip root@10.3.0.150:/root/
   ```

3. While production is still database/application-fenced and DR is read-only,
   re-align production from the DR clock through the trusted admin connection.
   Both chronyd services must still be paused for this existing manual UAT
   allowance. Do not stop working NTP synchronization; if IT has restored it,
   stop and use a synchronized-clock recovery deployment instead.

   Run as root on PRODUCTION:

   ```bash
   (
       set -e
       [[ "$(hostname)" == "convox" ]] || { echo 'Wrong server'; exit 1; }
       CONVOX_DR_TIME="$(ssh -T -o ConnectTimeout=10 -o StrictHostKeyChecking=yes -o UserKnownHostsFile=/root/.ssh/known_hosts root@10.3.0.150 "date -u '+%Y-%m-%dT%H:%M:%S.%NZ'")"
       [[ "$CONVOX_DR_TIME" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{9}Z$ ]] || { echo 'Invalid remote timestamp'; exit 1; }
       date -u --date="$CONVOX_DR_TIME" >/dev/null
       date -u --set="$CONVOX_DR_TIME"
   )
   ```

   This establishes temporary relative alignment, not trustworthy NTP time.
   Ensure DR's date/time is actually current against a trusted reference; do
   not enter yesterday's date. It changes production's system clock and nothing
   about database roles. Receipt age/signature checks remain enforced.

4. Run as root on BOTH production and DR:

   ```bash
   install -d -m 0700 /root/convox-sudo-wrapper-hotfix
   unzip /root/convox-agent-sudo-wrapper-hotfix.zip -d /root/convox-sudo-wrapper-hotfix
   bash /root/convox-sudo-wrapper-hotfix/install-fenced-recovery-rhel.sh d6806999-884d-4cd5-b15c-2490123ad9be
   ```

   STOP if either installer refuses. Do not bypass it or retry a mutation.
   The previous agent and secret-bearing config backups are root-private:
   do not paste them. Agents are invoked per SSH request, so no ConVox service
   restart is required.

5. Back on archival:

   ```bash
   systemctl start convox-dr-console.service
   systemctl --no-pager --full status convox-dr-console.service
   ```

## Verification and UI recovery

Hard-refresh `https://10.3.0.151`, then click **Refresh status**. Verify the same
restricted control SSH status request as before if there is any uncertainty:

- Production: `applicationFenced=true`, `databaseFenced=true`, `db=null`.
- DR: `applicationFenced=true`, `databaseFenced=false`, `db.readOnly=true`,
  `gtidCurrent=gtidSlave=0-8111-98296`, SQL applying without a SQL error.
- Both: `recoverySupported=true`. DR IO may be reconnecting because the source
  database is deliberately stopped.

**Recover fenced cutover** should now appear IF the latest controller job is
still the original unattempted clock-evidence promotion failure. If it is not
available, share the actual workflow error/agent status, not secret config. Do
not reconcile or start a new cutover to bypass this.

Within the one-hour approval, click **Recover fenced cutover** and confirm
`RECOVER FENCED CUTOVER` only if nobody restarted the source since fencing.
This is a REAL audited promotion, not a preview. It rechecks the existing target,
source fence and eight file checksums, issues fresh receipts, promotes DR and
starts the approved runtime. Any failure requires inspection; no automatic
rollback or repeat mutation occurs. See `FENCED_UI_RECOVERY.md` for the guards.

Only at **Awaiting team validation** should the team switch test web/SIP routing
and test calls, queues and recordings. Confirm `I TESTED ROUTING AND CALLS` after
those tests. Production stays fenced; no rejoin/reverse sync is implemented.

Restore real NTP with IT. This is a temporary UAT exception for one old reserved
job, not permission for new cutovers with unsynchronized clocks. The package is
locally tested, not deployed or validated on either server by Codex.
