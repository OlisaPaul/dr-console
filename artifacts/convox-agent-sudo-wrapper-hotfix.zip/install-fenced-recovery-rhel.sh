#!/usr/bin/env bash
# One-time code update while this precise failed job stays reserved and fenced.
set -Eeuo pipefail
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
[[ $EUID == 0 && $# == 1 && "$1" == d6806999-884d-4cd5-b15c-2490123ad9be ]] || fail 'Run as root on the managed server: install-fenced-recovery-rhel.sh d6806999-884d-4cd5-b15c-2490123ad9be'
SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
[[ -f "$SOURCE_DIR/convox-console-control.py" && -f /usr/local/libexec/convox-console-control && ! -L /usr/local/libexec/convox-console-control ]] || fail 'Existing agent and update source required.'
for CMD in python3 restorecon; do command -v "$CMD" >/dev/null || fail "Missing $CMD"; done
python3 - "$SOURCE_DIR/convox-console-control.py" "$1" <<'PY'
import ast
import fcntl
import importlib.util
from importlib.machinery import SourceFileLoader
import json
import os
import pathlib
import shutil
import tempfile
import time

os.umask(0o077)
import sys
candidate = pathlib.Path(sys.argv[1])
ast.parse(candidate.read_text())
loader = SourceFileLoader('installed_agent', '/usr/local/libexec/convox-console-control')
spec = importlib.util.spec_from_loader(loader.name, loader)
agent = importlib.util.module_from_spec(spec)
loader.exec_module(agent)
cfg = agent.load_config()
root = agent.ROOT
agent.require(root.stat().st_uid == 0 and root.stat().st_mode & 0o077 == 0, 'Agent state must be root-owned and private')
with open(root / 'agent.lock', 'a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    state = json.loads((root / 'operation.json').read_text())
    agent.require(state.get('jobId') == sys.argv[2] and state.get('source') == 'production' and state.get('target') == 'dr' and state.get('preflightPassed') is True, 'Reserved job identity changed')
    steps = state.get('steps', {})
    agent.require(not any(value == 'running' for value in steps.values()) and not any(k.startswith('recover-') for k in steps), 'Agent step is running or recovery was already attempted')
    agent.require(cfg.get('adminReviewedStartup') is True and agent.application_fenced(), 'Administrator-approved stopped application is required')
    if cfg['host'] == 'production':
        agent.require(state.get('fenced') is True and steps.get('fence') == 'complete' and state.get('boundary') == state.get('filesVerified') == '0-8111-98296' and agent.database_fenced(), 'Production fence or boundary changed')
    elif cfg['host'] == 'dr':
        db = agent.db()
        agent.require(steps.get('promote') == 'failed' and not state.get('promoted') and not state.get('activated') and state.get('caughtUp') == '0-8111-98296', 'DR failure stage changed')
        agent.require(db['serverId'] == 30150 and db['readOnly'] and db['gtidCurrent'] == db['gtidSlave'] == state['caughtUp'], 'DR role or GTID changed')
    else:
        raise SystemExit('Wrong agent host')
    agent.require(agent.unit('chronyd.service')['active'] in ['inactive', 'failed'], 'Pause chrony and confirm manual clocks before this UAT installation')
    directory = pathlib.Path(tempfile.mkdtemp(prefix='convox-before-fenced-recovery-', dir='/root'))
    shutil.copy2('/usr/local/libexec/convox-console-control', directory / 'agent.before')
    shutil.copy2(agent.CONFIG, directory / 'control.json.before')
    cfg['manualRecoveryJobId'] = state['jobId']
    cfg['manualRecoveryExpires'] = time.time() + 3600
    agent.atomic_json(agent.CONFIG, cfg)
    target = pathlib.Path('/usr/local/libexec/convox-console-control')
    descriptor, temporary_name = tempfile.mkstemp(prefix='convox-control-update-', dir=str(target.parent))
    os.close(descriptor)
    temporary = pathlib.Path(temporary_name)
    shutil.copyfile(candidate, temporary)
    os.chmod(temporary, 0o755)
    os.chown(temporary, 0, 0)
    os.replace(temporary, target)
    print('Agent code updated; this exact reserved job retained. Roles, service masks, data and credentials unchanged.')
    print('Manual-clock UAT recovery approval expires in one hour and cannot authorize a new cutover job.')
    print('Private rollback directory:', directory)
PY
restorecon /usr/local/libexec/convox-console-control /etc/convox-console-agent/control.json
