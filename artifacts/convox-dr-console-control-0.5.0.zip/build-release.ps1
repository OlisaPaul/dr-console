param([string]$Version = '0.5.0')
$ErrorActionPreference = 'Stop'
$project = $PSScriptRoot
$manifest = Get-Content -LiteralPath (Join-Path $project 'package.json') -Raw | ConvertFrom-Json
if ($manifest.version -ne $Version) { throw 'Release version does not match package.json' }
$artifactDir = Join-Path $project 'artifacts'
New-Item -ItemType Directory -Force -Path $artifactDir | Out-Null
$artifact = Join-Path $artifactDir "convox-dr-console-control-$Version.zip"
if (Test-Path -LiteralPath $artifact) { throw "Release already exists: $artifact. Use a new version or explicitly archive the existing artifact." }
$paths = @('server.mjs', 'package.json', 'config.example.json', 'README.md', 'build-release.ps1')
foreach ($folder in @('lib', 'public', 'deploy', 'test')) {
    $paths += Get-ChildItem -LiteralPath (Join-Path $project $folder) -File |
        Where-Object { $_.Extension -in @('.mjs', '.js', '.json', '.py', '.sh', '.md', '.html', '.css', '.service', '.conf', '.env') } |
        ForEach-Object { "$folder/$($_.Name)" }
}
$paths = $paths | Sort-Object -Unique
$utf8 = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.IO.Compression
$stream = [System.IO.File]::Open($artifact, [System.IO.FileMode]::CreateNew)
$archive = New-Object System.IO.Compression.ZipArchive($stream, [System.IO.Compression.ZipArchiveMode]::Create, $false)
$hashLines = @()
try {
    foreach ($name in $paths) {
        # Normalize packaged text to LF, including Bash scripts authored on Windows.
        $text = [System.IO.File]::ReadAllText((Join-Path $project $name)).Replace("`r`n", "`n")
        $bytes = $utf8.GetBytes($text)
        $hasher = [System.Security.Cryptography.SHA256]::Create()
        try { $hash = ([BitConverter]::ToString($hasher.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant() }
        finally { $hasher.Dispose() }
        $hashLines += "$hash  $name"
        $entry = $archive.CreateEntry($name, [System.IO.Compression.CompressionLevel]::Optimal)
        $writer = $entry.Open()
        try { $writer.Write($bytes, 0, $bytes.Length) } finally { $writer.Dispose() }
    }
    $entry = $archive.CreateEntry('SHA256SUMS')
    $bytes = $utf8.GetBytes(($hashLines -join "`n") + "`n")
    $writer = $entry.Open()
    try { $writer.Write($bytes, 0, $bytes.Length) } finally { $writer.Dispose() }
} finally { $archive.Dispose(); $stream.Dispose() }
$zipHash = (Get-FileHash -LiteralPath $artifact -Algorithm SHA256).Hash.ToLowerInvariant()
[System.IO.File]::WriteAllText("$artifact.sha256", "$zipHash  $([IO.Path]::GetFileName($artifact))`n", $utf8)
Write-Output "Packaged $($paths.Count) files: $artifact"
Write-Output "SHA256: $zipHash"
