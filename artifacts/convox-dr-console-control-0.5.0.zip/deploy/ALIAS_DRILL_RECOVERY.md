# Recovery of UAT job 5e023f46-bd5f-4aa6-9fd6-c83237a757af

Use this only for the diagnosed partial failure: production ID 8111 is running
read-only at GTID `0-8111-98296`, the source application is fully fenced, the
MariaDB canonical service is masked but active, and mysql.service is the verified
RHEL alias. The job completed backup, quiesce, boundary and file copy but failed
at fence, before promoting DR. This is NOT a generic recovery or rollback tool.

Before running recovery, freshly verify on DR that its database ID is 30150,
readOnly is true, its applicationFenced flag is true, GTID is `0-8111-98296`, and
its replication remains healthy. Keep test traffic paused. The recovery script
cannot independently query DR from production; `--dr-confirmed-read-only` is an
administrator attestation to those peer checks, not automated fencing evidence.
If peer verification fails, stop. Do not run recovery if DR has accepted writes.

1. Upload/extract this ZIP on BOTH production and DR, via archival's trusted
   administrator SSH with pinned host keys. No installer runs automatically.
2. Run only on production, as root:

   `bash recover-failed-alias-drill-rhel.sh --dr-confirmed-read-only`

   It takes the installed agent's exclusive lock, validates this precise job,
   failure stage, source role/GTID/masks and absent application, saves the old
   role file under /root, releases only this source job/read-lock holder, and
   persists production's DB writable using the existing checked role helper.
   The source service masks remain intact and no service is started/restarted.
   The role is for safe reconciliation and a fresh planned drill, not restored
   production traffic. DR is not promoted and remains a replica.
3. Verify source ID8111/readOnly0, DR ID30150/readOnly1 and healthy replication.
   Use UI Refresh status -> Reconcile state -> `I VERIFIED BOTH SERVERS`.
   Reconciliation releases the DR reservation too without changing roles. If
   anything fails, stop and inspect; never delete reservations manually.
4. Run `bash install-agent-hotfix-rhel.sh` on BOTH managed servers after successful
   reconciliation. This installs the corrected MariaDB alias handling and earlier
   parser/self-process fixes. It refuses outstanding reservations and backs up
   the previous code. No credential, vendor config or service change occurs.
5. Refresh and run preflight before a NEW planned UI cutover. Old signed GTID,
   file and fencing receipts are not reused. Keep test traffic paused. Do not
   stop MariaDB or manually promote DR to bypass the failed job.

The scripts were exercised with mocked agents and temporary files locally, not
on the real RHEL servers. Role, alias and process checks may expose another
environment-specific prerequisite; failure is a reason to inspect, not bypass.
