# RHEL mysql.service alias fencing correction

RHEL may have `/etc/systemd/system/mysql.service` already pointing to the vendor
MariaDB unit. A normal systemctl mask refuses to replace that existing symlink.
The original agent masked mariadb.service, then failed to mask the alias before
stopping MariaDB. A mask does not stop an already running database.

The updated agent checks the alias before shutdown, saves a verified MariaDB
alias target in the job backup, and uses force only to mask that exact alias.
Custom unit files and links to unrelated services are rejected. Successful
database fencing now requires persistent masks for both mariadb.service and
mysql.service, an absent database process, and a stopped/masked application.

This agent-only ZIP includes earlier parser, self-process and shutdown fixes.
It does not automatically repair an already failed operation. Do not install
while its reservation exists; do not delete the reservation. Verify actual roles
and application fences first. A failure at this stage can leave both DBs
read-only. The current UI requires a sole writer to reconcile, so a trusted
administrator must plan the recovery of that partial state before a fresh job.
Do not manually promote DR, stop production's still-running DB or release a read
lock without checking the failed job and current roles.

After safe reconciliation, transfer and extract this ZIP on BOTH managed servers
and run `install-agent-hotfix-rhel.sh` as root. It preserves the previous agent
and changes code only, not roles, replication, credentials or vendor settings.
No service restart is needed. Refresh and run preflight before a NEW cutover.
