# Agent self-process fencing fix

When invoked directly by its shebang through SSH/sudo, the control agent can
have a process name beginning with `convox`. Its broad application-process check
then incorrectly counts the agent itself as a worker. Importing the module into
`python3 -` does not reproduce that process name, explaining the different local
diagnostic result.

This update excludes only the executing agent's own PID. Other vendor processes,
web servers, Asterisk, and the separate primary runtime remain fencing blockers.
It includes the previous `=>` worker parser fix. No masks, configuration, keys,
database roles or replication settings are changed.

Extract this ZIP into a new private directory on archival. Transfer
`convox-console-control.py` and `install-agent-hotfix-rhel.sh` together into a new
private directory on BOTH production and DR. Run that installer as root on each
managed server while the console is idle, then refresh status and run preflight.
The installer refuses a running/reserved agent job and saves the old agent under
`/root`. Do not delete reservations to bypass it. No service restart is needed.

This is a locally tested code fix, not a claim that live server preflight passed.
If preflight still fails, inspect the exact response through archival's restricted
control SSH connection. Do not relax masking or writer detection to bypass it.
