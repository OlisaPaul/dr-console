# Prepare DR and repeat the recovery cycle — release 0.5.0

This is the current upgrade/runbook for the existing three-host installation.
It supersedes the 0.4 deployment examples for rejoin. Creating this package does
not install it or run a rebuild on any server.

| Host | Address | Role immediately before Prepare DR |
| --- | --- | --- |
| Archival | 10.3.0.151 | HTTPS console on port 443 |
| Production | 10.81.0.11 | Sole writable primary; approved runtime healthy |
| DR | 10.3.0.150 | Application fenced; database fenced or isolated read-only |

## Before deployment

Complete production routing/call validation in the UI with
`I TESTED ROUTING AND CALLS` if that step is still awaiting validation. There
must be no running, failed/unreconciled, or reserved operation during upgrade.
The rollout refuses these states. Do not delete operation files to bypass it.
Keep other operators out of the console during the upgrade.

DR must reach production on **TCP/3306**. SSH success does not prove this.
The rollout tests that route before installing either agent. Production's
MariaDB must already listen on its reachable IP and the host/network firewall
must persistently allow DR's source IP. This deployment does not change
MariaDB listeners or firewalls. The reverse TCP/3306 route is also needed when
preparing production later.

Existing prerequisites carry forward: pinned control and file-copy keys,
reciprocal `convoxsync` access, both root-private replication password files,
reviewed startup definitions, and the local IP mappings for each server.
No passwords, keys, local role configuration or operator accounts are shipped.

## One complete package, one rollout command

From Windows PowerShell:

```powershell
scp "C:\Users\DEEPIJA\Documents\ConVoxCCS\dr-console\artifacts\convox-dr-console-control-0.5.0.zip" "C:\Users\DEEPIJA\Documents\ConVoxCCS\dr-console\artifacts\convox-dr-console-control-0.5.0.zip.sha256" root@10.3.0.151:/root/
```

On archival, as root (run each stage only if the previous one succeeds):

```bash
cd /root
sha256sum -c convox-dr-console-control-0.5.0.zip.sha256
install -d -m 0700 /root/convox-console-control-0.5.0
unzip -o /root/convox-dr-console-control-0.5.0.zip -d /root/convox-console-control-0.5.0
bash /root/convox-console-control-0.5.0/deploy/rollout-prepare-dr-rhel.sh --uat
```

`--uat` explicitly renews the existing four-hour relative-clock exception on
both agents and archival. Their clocks still must agree within five seconds.
For normal synchronized-NTP operation, omit `--uat`. Before go-live disable the
exception everywhere using the included helper as described in UAT_CLOCK_MODE.md.

The rollout prompts for trusted root SSH access to each managed server if
administrator keys are not configured. It uses the existing pinned host keys;
do not bypass a host-key mismatch. It performs the following:

1. Verifies the package's complete SHA-256 manifest and archival identity.
2. Refuses unfinished jobs, then stops only the archival console during upgrade.
   The console website may briefly show 502 while its backend is stopped.
3. Checks both agent identities/reservations and DR → production TCP/3306.
4. Copies the agent, installer and UAT helper to a fixed root-private versioned
   directory on **both** servers, then installs each agent with a backup.
5. Upgrades archival code while preserving its mode, keys, TLS, authentication,
   settings and audit history. It does not edit Nginx; access stays on port 443.
6. Optionally renews the UAT policy and verifies both restricted control agents
   report `agentVersion: 0.5.0` and `prepareVersion: 2`.

The installer leaves production/DR databases and application services in their
current states. The rollout does not click Prepare DR or restore any data.
It attempts to restart the archival console if deployment stops with an error.
If only one agent was upgraded, the new UI refuses preparation with mixed
versions. Correct the reported deployment issue and rerun this code-only
rollout while no operation is reserved. All helpers are in the extracted ZIP;
there is no dependency on an old `/root/install-rejoin-rhel.sh`.

## Run Prepare DR from the UI

1. Open https://10.3.0.151, refresh the browser and click **Refresh status**.
2. Confirm production is the sole writable, healthy primary. DR's application
   must be fenced. Its database may be stopped or safely read-only.
3. Select **Prepare DR** and type **REBUILD DR**. Do not run cutover preflight
   first; preparation has its own appropriate checks.
4. Let all ten steps finish. Production remains the primary and routing stays
   on production. Mixed-engine backups briefly take database read locks, so
   writes may pause while the source seed is captured.

The target's eight allowlisted application databases are replaced. Before any
replacement the agent verifies its rollback checksums, the signed source seed,
source replication-account login/identity, target read-only role, application
fence, and all four replication exclusions. Source account changes are limited
to `convox_repl` for the other server's exact IP with session binlogging disabled.

The four destination-local tables are preserved and restored into the explicit
`convoxcces_global` schema:

- `convoxccs_license_details`
- `convoxccs_notifications`
- `convoxccs_servers`
- `convoxccs_web_servers`

Their row counts and both IP mappings are verified. The local files
`/var/www/convox4.conf` and `/var/www/convoxwebpanel.conf` are backed up and are
outside the eight copied file roots. Ownership, permissions and extra target
files are not changed/deleted by the baseline copy.

After completion expect:

| Check | Production | DR |
| --- | --- | --- |
| Database | Writable primary | Read-only replica |
| Application | Running | Persistently fenced/stopped |
| Replication | No upstream | Source 10.81.0.11; I/O and SQL healthy; zero lag at verification |
| Traffic | Stays here | Do not route traffic here |

The preparation verifies an exact signed source GTID captured after the file
baseline. Database replication continues afterward. **File copying is a
baseline only**: Lsyncd remains in its existing state, and this feature does not
enable continuous recording synchronization. Active files can change during
the baseline. Planned cutover still quiesces the source and performs the final
checksum-verified copy. Prepare DR alone does not establish readiness for a
zero-loss unplanned outage.

## Repeat the drill

- Production active → Prepare DR → drain calls → Run cutover preflight → Bring
  DR online (`PROMOTE DR`) → route/test and confirm calls.
- DR active → Prepare production (`REBUILD PRODUCTION`) → drain calls → Run
  cutover preflight → Cut over to production (`CUT OVER TO PRODUCTION`) →
  route/test and confirm calls → Prepare DR again.

Preparation and promotion are separate actions. A standby's application remains
fenced after preparation; that is the expected healthy standby state.

## Failure and recovery

Every failed step stops later work and leaves reconciliation required. The
controller does not automatically restart or replay a failed operation. An SSH
timeout does not prove remote work ended. Keep the current primary active,
inspect the indicated private agent log and both roles before reconciliation.
Do not manually unmask the target application or set it writable.

The updated agent reports a direction-specific TCP error before the target DB
is opened, rejects bad source credentials before dropping target data, and logs
replication I/O/SQL errors privately if channel startup fails. Release of server
reservations occurs only after final role, replication and application-fence
checks. Partial release failures still require inspection and reconciliation.

Rollback code backups are under `/root/convox-console-upgrade.*` on archival
and `/root/convox-console-control.before-*` on each managed server. Database
rollback backups remain under `/var/lib/convox-console-agent/<job-id>/`.
Code rollback does not undo a database restore. Do not roll back software or
restore a backup while a job is reserved without inspecting that operation.

Local tests use mocked server actions. They verify both directions, ordering,
protected tables, receipts, fencing and failure handling, but do not prove real
RHEL, SIP, licensing or recording behavior. The supervised UAT run is still the
deployment verification.
