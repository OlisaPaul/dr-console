# Shutdown scan self-process correction

The preceding fencing update excluded the agent's own PID in `writers()`, but
the independent Screen-parent shutdown scan still included it. Through SSH/sudo,
the executing agent can have a `convox`-prefixed process name. Its parent is not
Screen, triggering the unmanaged-writer refusal after some source services stop.

This fix excludes only the executing agent's PID in that scan too. Actual ConVox
workers still require an identified Screen parent owning only ConVox children.
The operation still refuses unknown launchers; it never kills arbitrary sudo,
SSH, Screen, Perl or Python processes. Earlier parser/fencing fixes are included.

Before updating after a failed job, verify actual roles and peer fencing. For the
reported case, production remains the sole writer, DR is read-only with healthy
replication at the same GTID, and only three Screen-managed production workers
remain. With test traffic paused, use the UI's Reconcile state action and type
`I VERIFIED BOTH SERVERS`. It releases failed-operation reservations without
restarting services or changing roles. If observations changed or reconciliation
fails, stop and investigate; never delete reservations manually.

Upload this ZIP to archival, transfer it to BOTH managed servers, extract into
a new root-private directory on each, then run `install-agent-hotfix-rhel.sh`.
That installer refuses running/reserved operations and backs up the old agent.
It changes code only, not DB roles, credentials, filters, masks or vendor config.

Refresh and run preflight again. Start a NEW planned cutover only after it passes.
No interrupted step is resumed or replayed, and no service restart is required
for the update. Keep users paused and do not manually start Asterisk or cron.
