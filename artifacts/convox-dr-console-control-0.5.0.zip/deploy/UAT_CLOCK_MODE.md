# Temporary UAT relative-clock mode — 0.4.1

Use this only while the environment is pre-live and test data is disposable.
It does not claim that production or DR has trusted time. Genuine synchronized
NTP remains mandatory before go-live.

The policy requires separate root-owned approval on archival, production and
DR. Approval expires after four hours. During **Prepare production** and cutover
preflight, the controller requests a fresh epoch sample from both restricted
agents in parallel and compares them with archival's local clock. The operation
stops before mutation unless all three clocks are within five seconds. The UI
shows a persistent warning and the audit log records use of the exception.

## Upgrade order

Install the 0.4.1 agent on production and DR before upgrading archival. The
rejoin installer updates only the restricted agent and keeps existing server
roles, services, secrets and ConVox files unchanged:

```bash
bash /root/install-rejoin-rhel.sh production
```

```bash
bash /root/install-rejoin-rhel.sh dr
```

Then upgrade archival with `deploy/upgrade-rhel.sh`.

## Enable for one demonstration window

Run on production and DR respectively, only when no console operation is
reserved:

```bash
bash /root/configure-uat-clock-skew-rhel.sh agent enable
```

Finally run on archival:

```bash
bash /root/configure-uat-clock-skew-rhel.sh controller enable
```

Opening the UI must now show **UNSYNCHRONIZED-CLOCK UAT MODE** and the expiry.
Keep the manually aligned clocks unchanged. Click **Prepare production** and
type the existing confirmation phrase. The relative-clock check is automatic.
If the clocks differ by more than five seconds, the workflow stops safely and
requires reconciliation; do not retry blindly.

## Disable before go-live

After the demonstration, and after any job has finished or been reconciled,
run on production and DR:

```bash
bash /root/configure-uat-clock-skew-rhel.sh agent disable
```

Run on archival:

```bash
bash /root/configure-uat-clock-skew-rhel.sh controller disable
```

Refresh the UI and verify the UAT warning is gone. Confirm both ConVox servers
then pass genuine Chrony/NTP checks before any production cutover.
