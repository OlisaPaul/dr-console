# Worker parser hotfix for the 0.3 control agent

The deployed ConVox configuration uses `service_active => Y` and similar
Perl-style arrows. The original agent incorrectly retained `>` in the parsed
value and reported no enabled Screen workers. The corrected parser supports
both `=>` and `=`; disabled workers remain disabled and executable checks remain
mandatory. Do not edit `/var/www/convox4.conf` to work around this bug.

Upload `convox-agent-workers-hotfix.zip` to archival, extract into a new private
directory, then transfer both Python and installer files to production and DR.
Use the existing trusted administrator account and pinned host keys. Run the
hotfix installer on BOTH managed servers, not archival. It backs up and replaces
only `/usr/local/libexec/convox-console-control` and checks that no agent job is
reserved or running. It leaves keys, cluster secrets, startup approval, vendor
configuration, services, database roles and replication unchanged.

No console or application restart is required for this parser fix. The next SSH
agent request uses the new code. An already running native runtime continues
using its loaded code; do not restart it during calls or a cutover. Apply this
hotfix before the planned drill, then run UI preflight again. Another failed
prerequisite still blocks cutover and must be investigated separately.
