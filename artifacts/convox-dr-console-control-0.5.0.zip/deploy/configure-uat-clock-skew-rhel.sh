#!/usr/bin/env bash
# Enable or disable a four-hour, three-host relative-clock exception for UAT.
# Run separately on archival (controller) and on each ConVox server (agent).
set -Eeuo pipefail

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
[[ $EUID -eq 0 && $# -eq 2 ]] || fail 'Usage as root: configure-uat-clock-skew-rhel.sh controller|agent enable|disable'
ROLE="$1"
ACTION="$2"
[[ "$ROLE" == controller || "$ROLE" == agent ]] || fail 'Role must be controller or agent.'
[[ "$ACTION" == enable || "$ACTION" == disable ]] || fail 'Action must be enable or disable.'

if [[ "$ROLE" == controller ]]; then
    CONFIG=/etc/convox-console/control.json
    [[ -f "$CONFIG" && -f /opt/convox-dr-console/package.json ]] || fail 'Existing archival control console required.'
else
    CONFIG=/etc/convox-console-agent/control.json
    [[ -f "$CONFIG" && -x /usr/local/libexec/convox-console-control ]] || fail 'Existing server control agent required.'
    [[ ! -e /var/lib/convox-console-agent/operation.json ]] || fail 'A server operation is reserved; finish or reconcile it before changing clock policy.'
fi

STAMP="$(date '+%Y%m%d-%H%M%S')"
cp -p "$CONFIG" "/root/$(basename "$CONFIG").before-uat-clock-$STAMP"

python3 - "$CONFIG" "$ACTION" <<'PY'
import json, math, os, pathlib, stat, sys, time

path = pathlib.Path(sys.argv[1])
action = sys.argv[2]
info = path.stat()
data = json.loads(path.read_text())
if action == 'enable':
    data['uatClockSkewMode'] = True
    data['uatClockSkewExpires'] = math.floor(time.time()) + 4 * 60 * 60
else:
    data['uatClockSkewMode'] = False
    data['uatClockSkewExpires'] = 0
temporary = path.with_name(path.name + '.uat-tmp')
temporary.write_text(json.dumps(data, indent=2) + '\n')
os.chown(temporary, info.st_uid, info.st_gid)
os.chmod(temporary, stat.S_IMODE(info.st_mode))
with temporary.open('rb') as stream:
    os.fsync(stream.fileno())
os.replace(temporary, path)
PY

if command -v restorecon >/dev/null; then restorecon "$CONFIG"; fi
if [[ "$ROLE" == controller ]]; then
    systemctl restart convox-dr-console.service
    systemctl is-active --quiet convox-dr-console.service || fail 'Console did not restart; restore the root-private backup and inspect its journal.'
fi

if [[ "$ACTION" == enable ]]; then
    printf 'Temporary UAT relative-clock mode enabled for four hours on this %s. This is not NTP synchronization.\n' "$ROLE"
else
    printf 'Temporary UAT relative-clock mode disabled on this %s. Genuine synchronized NTP is required again.\n' "$ROLE"
fi
