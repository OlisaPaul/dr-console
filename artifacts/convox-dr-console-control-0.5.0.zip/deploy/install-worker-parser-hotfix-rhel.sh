#!/usr/bin/env bash
# Update agent code only; do not change vendor config, services or database roles.
set -Eeuo pipefail
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
[[ $EUID == 0 ]] || fail 'Run as root on production or DR, not archival.'
SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
SOURCE="$SOURCE_DIR/convox-console-control.py"
TARGET=/usr/local/libexec/convox-console-control
STATE=/var/lib/convox-console-agent
[[ -f "$SOURCE" && -f "$TARGET" && ! -L "$TARGET" && -d "$STATE" ]] || fail 'Existing installed control agent and hotfix source required.'
[[ "$(stat -c %U "$TARGET")" == root && "$(stat -c %U "$STATE")" == root ]] || fail 'Agent and state directory must be root-owned.'
for CMD in python3 flock install restorecon sha256sum; do command -v "$CMD" >/dev/null || fail "Missing command: $CMD"; done
python3 - "$SOURCE" <<'PY'
import ast, json, pathlib, sys
ast.parse(pathlib.Path(sys.argv[1]).read_text())
cfg = json.loads(pathlib.Path('/etc/convox-console-agent/control.json').read_text())
if cfg.get('host') not in ('production', 'dr'):
    raise SystemExit('Wrong agent host')
PY
umask 077
exec 9>>"$STATE/agent.lock"
flock -n 9 || fail 'Agent operation is running; wait until idle.'
[[ ! -e "$STATE/operation.json" ]] || fail 'A cutover reservation exists. Finish or reconcile it first; do not delete it.'
BACKUP="$(mktemp /root/convox-control-before-worker-hotfix.XXXXXX)"
cp -p "$TARGET" "$BACKUP"
install -o root -g root -m 0755 "$SOURCE" "$TARGET"
restorecon "$TARGET"
printf 'Agent hotfix installed. Previous agent: %s\n' "$BACKUP"
sha256sum "$TARGET"
printf 'No service restart, database role change or ConVox configuration change was made. Run UI preflight again.\n'
