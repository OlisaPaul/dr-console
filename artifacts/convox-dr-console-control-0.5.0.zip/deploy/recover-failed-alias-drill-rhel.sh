#!/usr/bin/env bash
# One-off recovery of the exact UAT job reported in this conversation.
# Requires a fresh administrator check that DR remains read-only and fenced.
set -Eeuo pipefail
[[ $EUID == 0 && $# == 1 && "$1" == --dr-confirmed-read-only ]] || {
    printf 'Run on production as root only after verifying DR remains read-only and application-fenced:\n  bash recover-failed-alias-drill-rhel.sh --dr-confirmed-read-only\n' >&2
    exit 1
}
python3 - <<'PY'
import fcntl
import importlib.util
from importlib.machinery import SourceFileLoader
import json
import os
import pathlib
import shutil
import tempfile

os.umask(0o077)
loader = SourceFileLoader('convox_agent', '/usr/local/libexec/convox-console-control')
spec = importlib.util.spec_from_loader(loader.name, loader)
agent = importlib.util.module_from_spec(spec)
loader.exec_module(agent)
cfg = agent.load_config()
agent.require(cfg['host'] == 'production', 'Wrong server: recovery is production-only')

with open(agent.ROOT / 'agent.lock', 'a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    state = json.loads((agent.ROOT / 'operation.json').read_text())
    expected_job = '5e023f46-bd5f-4aa6-9fd6-c83237a757af'
    agent.require(state.get('jobId') == expected_job and state.get('source') == 'production' and state.get('target') == 'dr', 'Different reserved job: stop and inspect')
    steps = state.get('steps', {})
    agent.require(steps.get('fence') == 'failed' and all(steps.get(k) == 'complete' for k in ['backup', 'quiesce', 'boundary', 'files']), 'Unexpected failed step: stop and inspect')
    agent.require(not state.get('fenced') and not state.get('promoted') and not any(k in steps for k in ['promote', 'activate']), 'Later mutation exists: this recovery is not applicable')
    database = agent.db()
    agent.require(database['serverId'] == 8111 and database['readOnly'] and database['gtidCurrent'] == state.get('boundary') == '0-8111-98296', 'Database role or GTID changed: stop and inspect')
    agent.require(agent.application_fenced(), 'Production application is not fenced; refusing writable role')
    agent.require(os.path.islink('/etc/systemd/system/mariadb.service') and os.readlink('/etc/systemd/system/mariadb.service') == '/dev/null', 'Expected production DB mask changed: stop and inspect')
    agent.require(os.path.islink('/etc/systemd/system/mysql.service') and os.readlink('/etc/systemd/system/mysql.service') == '/usr/lib/systemd/system/mariadb.service', 'Expected RHEL database alias changed: stop and inspect')
    descriptor, backup_name = tempfile.mkstemp(prefix='convox-role-before-alias-recovery-', suffix='.cnf', dir='/root')
    os.close(descriptor)
    shutil.copyfile('/etc/my.cnf.d/99-convox-role.cnf', backup_name)
    os.chmod(backup_name, 0o600)
    # Release only this exact failed reservation. The installed agent verifies
    # the lock-holder PID against the job before terminating it. No DB is stopped.
    agent.dispatch(cfg, {'version': 1, 'host': 'production', 'operation': 'release', 'jobId': expected_job})
    agent.persist_role(False)
    agent.require(not agent.db()['readOnly'] and agent.application_fenced(), 'Recovery verification failed; stop and inspect')
    print('Production DB restored writable; application services remain fenced. No database restart, promotion of DR or data restore occurred.')
    print('Previous production role file saved:', backup_name)
    print('Use UI Refresh status and Reconcile state next. Keep test traffic paused.')
PY
