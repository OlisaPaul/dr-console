#!/usr/bin/env bash
# Run on archival. Deploy code; starting Prepare DR remains a UI decision.
set -Eeuo pipefail
umask 077
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
[[ $EUID == 0 && $# -le 1 ]] || fail 'Usage as root on archival: rollout-prepare-dr-rhel.sh [--uat]'
UAT="${1:-}"
[[ -z "$UAT" || "$UAT" == --uat ]] || fail 'Only the optional --uat flag is supported.'
SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
cd "$SOURCE_DIR"
for CMD in python3 ssh scp sha256sum flock systemctl; do command -v "$CMD" >/dev/null || fail "Missing: $CMD"; done
[[ -f SHA256SUMS ]] || fail 'Extract the complete 0.5.0 release package first.'
sha256sum --quiet -c SHA256SUMS
python3 - <<'PY'
import json
import pathlib
import shlex
import subprocess

release = json.loads(pathlib.Path('package.json').read_text())
if release.get('version') != '0.5.0':
    raise SystemExit('Expected release 0.5.0')
addresses = subprocess.check_output(['/usr/sbin/ip', '-4', '-o', 'address', 'show'], text=True)
if not any(word.startswith('10.3.0.151/') for word in addresses.split()):
    raise SystemExit('Run this rollout on archival 10.3.0.151')
env = {}
for line in pathlib.Path('/etc/convox-console/console.env').read_text().splitlines():
    if line.strip() and not line.lstrip().startswith('#') and '=' in line:
        key, value = line.split('=', 1)
        parts = shlex.split(value)
        if len(parts) == 1:
            env[key.strip()] = parts[0]
if env.get('CONVOX_MODE') != 'control':
    raise SystemExit('Existing control-mode console required')
directory = pathlib.Path(env.get('CONVOX_DATA_DIR', '/opt/convox-dr-console/data/control'))
if not directory.is_absolute():
    directory = pathlib.Path('/opt/convox-dr-console') / directory
state = json.loads((directory / 'state.json').read_text())
if state.get('reconcileRequired') or any(j.get('state') in ['running', 'awaiting-validation'] for j in state.get('jobs', [])):
    raise SystemExit('Complete call validation or inspect/reconcile the existing job before upgrade')
PY
exec 9>/var/lock/convox-console-cycle-rollout.lock
flock -n 9 || fail 'Another console rollout is running.'
SSH=(-o StrictHostKeyChecking=yes -o UserKnownHostsFile=/etc/convox-console/ssh/known_hosts -o ConnectTimeout=10 -o ClearAllForwardings=yes)
systemctl is-active --quiet convox-dr-console.service || fail 'Start/inspect the existing archival console before deployment.'
# Close UI job ingress while installing. The server agents also take their own
# locks and refuse any reservation that appeared after the controller check.
trap 'systemctl start convox-dr-console.service || true' EXIT
systemctl stop convox-dr-console.service

# Inspect both nodes before installing either. Do not stop databases/applications.
for ENTRY in production:10.81.0.11 dr:10.3.0.150; do
    NODE="${ENTRY%%:*}"
    ADDRESS="${ENTRY#*:}"
    printf 'Checking %s before deployment...\n' "$NODE"
    ssh -T "${SSH[@]}" "root@$ADDRESS" python3 - "$NODE" <<'PY'
import json
import pathlib
import socket
import sys
node = sys.argv[1]
cfg = json.loads(pathlib.Path('/etc/convox-console-agent/control.json').read_text())
if cfg.get('host') != node or cfg.get('adminReviewedStartup') is not True:
    raise SystemExit('Wrong agent identity or startup not reviewed')
if pathlib.Path('/var/lib/convox-console-agent/operation.json').exists():
    raise SystemExit('An operation is reserved on ' + node + '; finish or reconcile it before upgrading')
if node == 'dr':
    try:
        with socket.create_connection(('10.81.0.11', 3306), timeout=5):
            pass
    except OSError:
        raise SystemExit('DR cannot reach production TCP/3306. Fix the listener/firewall before Prepare DR.')
print(node + ': identity and reservation checks passed')
PY
done

for ENTRY in production:10.81.0.11 dr:10.3.0.150; do
    NODE="${ENTRY%%:*}"
    ADDRESS="${ENTRY#*:}"
    printf 'Installing preparation agent on %s...\n' "$NODE"
    ssh -T "${SSH[@]}" "root@$ADDRESS" 'test ! -L /root/convox-console-0.5.0-agent && install -d -o root -g root -m 0700 /root/convox-console-0.5.0-agent'
    scp "${SSH[@]}" deploy/convox-console-control.py deploy/install-rejoin-rhel.sh deploy/configure-uat-clock-skew-rhel.sh "root@$ADDRESS:/root/convox-console-0.5.0-agent/"
    # The argument values here come only from the fixed host list above.
    ssh -T "${SSH[@]}" "root@$ADDRESS" "bash /root/convox-console-0.5.0-agent/install-rejoin-rhel.sh $NODE"
    if [[ "$UAT" == --uat ]]; then
        ssh -T "${SSH[@]}" "root@$ADDRESS" 'bash /root/convox-console-0.5.0-agent/configure-uat-clock-skew-rhel.sh agent enable'
    fi
done

bash deploy/upgrade-rhel.sh
if [[ "$UAT" == --uat ]]; then
    bash deploy/configure-uat-clock-skew-rhel.sh controller enable
fi

for ENTRY in production:10.81.0.11 dr:10.3.0.150; do
    NODE="${ENTRY%%:*}"
    ADDRESS="${ENTRY#*:}"
    printf '{"version":1,"host":"%s","operation":"status"}\n' "$NODE" |
    sudo -u convoxconsole ssh -T -F /dev/null "${SSH[@]}" -o BatchMode=yes \
      -o IdentitiesOnly=yes -o IdentityAgent=none -i /etc/convox-console/ssh/control_ed25519 \
      "convoxcontrol@$ADDRESS" convox-control-v1 |
    python3 -c 'import json,sys; r=json.load(sys.stdin); c=r.get("control",{}); assert r.get("ok") is True and c.get("prepareVersion")==2, "Preparation agent version mismatch"; print("Verified agent " + str(c.get("agentVersion")) + "; application fenced=" + str(c.get("applicationFenced")))'
done
printf '0.5.0 rollout complete. Refresh https://10.3.0.151 and select Prepare DR, then REBUILD DR.\n'
printf 'Deployment did not execute a rebuild. No production/DR service was started or stopped.\n'
