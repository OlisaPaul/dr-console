let token, state, selectedView = 'overview', pendingAction, connected = true;
const main = document.querySelector('#main');
const dialog = document.querySelector('#confirmation');
const phrases = { failover: 'PROMOTE DR', rejoin: 'REBUILD PRODUCTION', prepareDr: 'REBUILD DR', failback: 'CUT OVER TO PRODUCTION', reconcile: 'I VERIFIED BOTH SERVERS', validate: 'I TESTED ROUTING AND CALLS', recover: 'RECOVER FENCED CUTOVER' };
const names = { failover: 'Bring DR online', rejoin: 'Prepare production', prepareDr: 'Prepare DR', failback: 'Cut over to production', reconcile: 'Reconcile server state', validate: 'Confirm routing and call tests', recover: 'Recover fenced cutover' };
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const time = value => value ? new Date(value).toLocaleString('en-NG', { timeZone: 'Africa/Lagos', hour: '2-digit', minute: '2-digit', second: '2-digit', day: '2-digit', month: 'short' }) + ' WAT' : 'Not checked';
const label = host => host === 'production' ? 'Production' : 'Disaster recovery';
const pill = (text, kind = '') => `<span class="pill ${kind}">${esc(text)}</span>`;
const stepList = {
  failover: ['Fence production and stop its writers', 'Drain received events', 'Persist DR as writable primary', 'Start services and switch routing'],
  rejoin: ['Fence returning production', 'Preserve its licence and local settings', 'Restore a fresh DR seed and recordings', 'Start read-only replication from DR'],
  prepareDr: ['Verify production is the sole writer and DR application is fenced', 'Preserve all four DR-local tables and environment files', 'Restore a fresh production seed and baseline-copy files', 'Leave DR replicating read-only with its application stopped'],
  failback: ['Freeze DR writes', 'Verify final database and file boundaries', 'Promote production and switch routing', 'Rebuild DR as the standby replica'],
  reconcile: ['Inspect both servers and any interrupted remote jobs', 'Refresh verified server roles', 'Acknowledge the state before allowing another operation'],
  validate: ['Switch test web and SIP endpoints to the new primary', 'Verify inbound and outbound calls, queues and recording playback', 'Confirm the old primary is still fenced'],
  recover: ['Confirm source has not been restarted and clocks are now aligned', 'Recheck target GTID, source fence and all eight file checksums', 'Issue fresh signed evidence before target promotion; no old receipt replay', 'Start approved runtime, then require team call and routing tests']
};
async function api(url, data, retried = false) {
  const options = { headers: { 'X-Console-Token': token } };
  if (data !== undefined) { options.method = 'POST'; options.headers['Content-Type'] = 'application/json'; options.body = JSON.stringify(data); }
  const response = await fetch(url, options);
  const result = await response.json();
  if (response.status === 401 && data === undefined && !retried) {
    const session = await fetch('/api/session').then(r => r.json());
    token = session.token;
    return api(url, data, true);
  }
  if (!response.ok) throw new Error(result.error || 'Request failed');
  return result;
}
let toastTimer;
function toast(message) {
  const el = document.querySelector('#toast'); el.textContent = message; el.classList.add('visible');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('visible'), 6000);
}
function header(title, subtitle) {
  return `<div class="page-heading"><div><div class="eyebrow">SERVER CONTINUITY</div><h1>${title}</h1><p>${subtitle}</p></div><button class="button secondary" data-command="refresh">↻ Refresh status</button></div>`;
}
function modeBanner() {
  if (state.mode === 'control') return `<div class="mode-banner live"><span class="mode-mark">●</span><div><strong>${state.uatClockSkewMode ? 'Live control · UNSYNCHRONIZED-CLOCK UAT MODE' : 'Live control · planned recovery'}</strong><span>${state.uatClockSkewMode ? `NTP is temporarily bypassed only when production, DR and archival are within five seconds. Approval expires ${time(state.uatClockSkewExpires)}. Do not use this mode after go-live.` : 'Restricted agents can prepare either fenced standby and perform a separately confirmed cutover. Routing remains team-validated.'}</span></div>${pill(state.uatClockSkewMode ? 'UAT ONLY' : 'REAL SERVER CHANGES', 'warning')}</div>`;
  if (state.mode === 'observe') return `<div class="mode-banner"><span class="mode-mark">●</span><div><strong>Live monitoring · read-only</strong><span>Real SSH status snapshots. Database, service and recovery changes are disabled.</span></div>${pill('READ-ONLY MONITORING')}</div>`;
  return `<div class="mode-banner ${state.mode === 'live' ? 'live' : ''}"><span class="mode-mark">${state.mode === 'simulation' ? '◈' : '●'}</span><div><strong>${state.mode === 'simulation' ? 'Simulation workspace' : 'Live server control'}</strong><span>${state.mode === 'simulation' ? 'All actions use persisted local demo data. No commands are sent to your servers.' : 'Actions execute administrator-provisioned hooks. Confirm the observed roles before switching.'}</span></div>${pill(state.mode === 'simulation' ? 'NO SERVER CHANGES' : 'LIVE EXECUTION', state.mode === 'live' ? 'warning' : '')}</div>`;
}
function serverCard(host) {
  const s = state.servers[host];
  const controlFenced = state.mode === 'control' && s.control?.databaseFenced;
  const primary = state.active === host && state.mode !== 'observe';
  const health = controlFenced ? 'Database fenced · SSH reachable' : s.reachable ? (s.role === 'replica' && s.sql !== true ? 'Needs attention' : 'Reachable') : 'Unreachable';
  const repl = controlFenced ? 'Database intentionally stopped; rejoin required before replication' : !s.reachable ? 'Database status unverified' : s.role === 'replica' ? `${s.io ? 'IO connected' : 'IO disconnected'} · ${s.sql ? 'SQL applying' : 'SQL stopped'}${s.upstream ? ' · upstream ' + s.upstream : ''}` : 'No upstream replica connection reported';
  const writes = controlFenced ? 'Stopped + persistently masked' : !s.reachable ? 'Unknown · last observed' : s.readOnly ? 'Read-only' : 'Writable';
  return `<article class="server-card ${primary ? 'authoritative' : ''}"><div class="server-top"><span class="server-icon">▤</span>${pill(primary ? 'AUTHORITATIVE' : state.mode === 'observe' && s.readOnly === false ? 'WRITABLE (OBSERVED)' : s.role.toUpperCase(), primary ? 'green' : '')}</div><h2>${label(host)}</h2><div class="ip">${esc(s.ip)} <span>MariaDB 10.5</span></div><div class="server-health"><span class="status-dot ${s.reachable ? 'good' : 'bad'}"></span>${health}${s.fenced ? pill('Fenced', 'warning') : ''}</div><dl><div><dt>Database writes</dt><dd>${writes}</dd></div><div><dt>Application services</dt><dd>${esc(s.services)}</dd></div><div><dt>Replication lag</dt><dd>${s.lag === null || s.lag === undefined ? '—' : esc(s.lag) + ' seconds'}</dd></div><div><dt>${state.mode === 'simulation' ? 'Demo records saved' : 'Current GTID'}</dt><dd>${esc(state.mode === 'simulation' ? s.records : s.gtid || 'Not reported')}</dd></div>${state.mode === 'observe' ? `<div><dt>Lsyncd service</dt><dd>${esc(s.fileSync)}</dd></div><div><dt>Asterisk / wrapper processes</dt><dd>${s.processes ? esc(s.processes.asterisk) + ' / ' + esc(s.processes.safeAsterisk) : 'Unverified'}</dd></div>` : ''}</dl>${s.error || s.lastIoError || s.lastSqlError ? `<p class="inline-error">${esc(s.error || s.lastIoError || s.lastSqlError)}</p>` : ''}<div class="server-foot">${esc(repl)}</div></article>`;
}
function actionCard(action, number, description) {
  const available = state.actions[action] || { allowed: false, reason: 'Refresh status after upgrading the console' };
  return `<article class="action-card"><div class="action-number">0${number}</div><h3>${names[action]}</h3><p>${description}</p><button class="button ${action === 'failover' ? 'primary' : 'secondary'}" data-action="${action}" ${!available.allowed || !connected ? 'disabled' : ''}>${names[action]} <span>→</span></button>${!available.allowed ? `<small class="blocked-reason">${esc(available.reason)}</small>` : '<small class="blocked-reason ready">Ready for operator confirmation</small>'}</article>`;
}
function jobPanel(job = state.jobs[0]) {
  if (job?.state === 'awaiting-validation') return `<section class="panel job-panel"><h2>Awaiting team validation</h2><p>Database and service cutover finished. No carrier/DNS changes were made. Test web/SIP routing, actual calls and recordings before confirming.</p><div class="steps">${job.steps.map(s => `<div class="step ${esc(s.state)}"><div><strong>${esc(s.title)}</strong><small>${esc(s.message || s.state)}</small></div></div>`).join('')}</div><button class="button primary" data-action="validate" ${!connected ? 'disabled' : ''}>Confirm routing and call tests</button></section>`;
  if (!job) return `<section class="panel empty-job"><span>✓</span><div><h3>No operations running</h3><p>Your first recovery operation will appear here with a step-by-step execution log.</p></div></section>`;
  const completed = job.steps.filter(s => s.state === 'complete').length;
  return `<section class="panel job-panel"><div class="section-heading"><div><h2>${names[job.action]}</h2><p>Started ${time(job.startedAt)} · ${completed}/${job.steps.length} steps</p></div>${pill(job.state, job.state === 'failed' || job.state === 'interrupted' ? 'red' : job.state === 'complete' ? 'green' : 'blue')}</div><div class="steps">${job.steps.map((s, i) => `<div class="step ${esc(s.state)}"><span class="step-dot">${s.state === 'complete' ? '✓' : s.state === 'failed' ? '!' : i + 1}</span><div><strong>${esc(s.title)}</strong><small>${label(s.host)}${s.message ? ' · ' + esc(s.message) : ''}</small></div><span class="step-state">${esc(s.state)}</span></div>`).join('')}</div>${job.error ? `<div class="inline-error">${esc(job.error)}<p>No automatic rollback is attempted. Verify both servers before continuing.</p></div>` : ''}</section>`;
}
function auditPanel(limit = 8) {
  return `<section class="panel audit-panel"><div class="section-heading"><div><h2>Activity log</h2><p>Durable operation history · times shown in West Africa Time</p></div>${pill(state.audit.length + ' events')}</div>${state.audit.length ? `<div class="audit-list">${state.audit.slice(0, limit).map(e => `<div class="audit-row"><span class="audit-dot"></span><div><strong>${esc(e.event)}</strong><p>${esc(e.details)}</p></div><time>${time(e.at)}</time></div>`).join('')}</div>` : '<p class="empty-text">No events yet. Use the simulation controls to begin a recovery drill.</p>'}</section>`;
}
function simulationPanel() {
  if (state.mode !== 'simulation') return '';
  const disabled = state.busy || !connected ? 'disabled' : '';
  return `<section class="panel demo-panel"><div><h2>Run a recovery drill</h2><p>Simulate an outage, promote DR, save a call, bring production back, then rebuild and cut over.</p></div><div class="demo-buttons"><button class="button secondary" data-demo="outage" ${disabled} ${state.active !== 'production' || !state.servers.production.reachable ? 'disabled' : ''}>Simulate production outage</button><button class="button secondary" data-demo="write" ${disabled}>Save a test call</button><button class="button secondary" data-demo="return" ${disabled} ${state.active !== 'dr' || state.servers.production.reachable ? 'disabled' : ''}>Production returns</button><button class="button text-button" data-demo="reset" ${disabled}>Reset demo</button></div></section>`;
}
function settings() {
  if (state.mode === 'control') return `${header('Connection setup', 'A separate restricted control key is required on archival.')}<section class="panel setup-panel"><h2>Planned recovery agents</h2><p>See <code>deploy/UI_CONTROL.md</code>. The browser cannot send commands, SQL, credentials or paths. Agents reserve one job, preserve four local tables, use signed GTID/checksum evidence, verify persistent fencing and activate only an approved runtime.</p><h3>Server-local data</h3><p>Licence, notifications, server mappings and web-server mappings remain local. The two environment files are never overwritten.</p><h3>Safety boundary</h3><p>Prepare production and Prepare DR replace standby databases only after verified rollback backups and keep the standby application fenced. Promotion requires a separate confirmation. Unreachable-primary failover and carrier/DNS automation remain disabled. Prepare DR is explicit; continuous file synchronization is not enabled by preparation.</p></section>`;
  if (state.mode === 'observe') return `${header('Connection setup', 'Restricted SSH monitoring from archival. Recovery controls are disabled.')}<section class="panel setup-panel"><h2>Live read-only connections</h2><p>Host keys are pinned and each server accepts only a fixed telemetry command for the observer key. Credentials are never entered in this browser. See <code>deploy/LIVE_STATUS.md</code> for installation and verification.</p>${['production', 'dr'].map(host => `<h3>${label(host)} · ${esc(state.servers[host].ip)}</h3><p>${esc(state.servers[host].error || 'Status snapshot obtained; this does not prove fencing or recovery readiness.')}</p><dl>${(state.servers[host].units || []).map(u => `<div><dt>${esc(u.name)}</dt><dd>${esc(u.load)} / ${esc(u.active)}${u.masked ? ' / masked' : ''}</dd></div>`).join('')}</dl>`).join('')}<h3>Recovery execution is not installed</h3><p>We still need verified writer fencing, safe_asterisk startup/stop handling, backups and licence preservation, database seeding, directional file sync and SIP/web routing. Process counts and read-only mode are not fencing evidence.</p></section>`;
  return `${header('Connection setup', 'Prepare the management host before enabling live server operations.')}<section class="panel setup-panel"><h2>Keep the control plane independent</h2><p>Deploy this console on a third management machine so it remains available when either ConVox server fails. The local preview binds to 127.0.0.1 and can be accessed through an SSH tunnel.</p><div class="setup-grid"><div><h3>Production</h3><code>10.81.0.11</code><p>Server ID 8111<br>Original production licence and IP configuration</p></div><div><h3>Disaster recovery</h3><code>10.3.0.150</code><p>Server ID 30150<br>Independent DR licence and IP configuration</p></div></div><h3>Live adapter</h3><p>The backend invokes one administrator-configured executable with a fixed argument list. The browser cannot send shell commands or change credentials. Server-side hooks must implement verified fencing, seeding, replication, file sync, service activation, and routing.</p><p>See <code>dr-console/README.md</code> for the hook contract and deployment procedure. Live mode is unavailable until those hooks are installed and verified.</p><h3>Environment data stays local</h3><ul><li><code>convoxcces_global.convoxccs_license_details</code></li><li><code>/var/www/convox4.conf</code></li><li><code>/var/www/convoxwebpanel.conf</code></li></ul><p>Fresh seeds preserve the destination licence. File transfers exclude the two environment-specific configuration files. A role change must also stop the old file-sync direction.</p><h3>Before remote deployment</h3><p>Add operator authentication, HTTPS, protected secret storage, access controls and verified carrier/NAT routing. Do not expose this local preview directly to the internet.</p></section>`;
}
function render() {
  if (!state) return;
  const focused = document.activeElement?.dataset?.focus;
  const alerts = `${!connected ? '<div class="inline-error" role="alert">Controller connection lost. No action is available until it reconnects.</div>' : ''}${state.uatClockSkewMode ? '<div class="inline-error" role="alert"><strong>UAT clock exception active.</strong> The console will measure relative clock skew over SSH. This is not trusted NTP synchronization and must be disabled before go-live.</div>' : ''}${state.observationError ? `<div class="inline-error" role="alert">${esc(state.observationError)}</div>` : ''}${(state.warnings || []).map(w => `<div class="inline-error" role="alert">${esc(w)}</div>`).join('')}${state.reconcileRequired ? '<div class="inline-error">The previous operation needs reconciliation. Inspect both servers before continuing. <button class="button secondary" data-action="reconcile">Reconcile state</button></div>' : ''}`;
  let content;
  if (selectedView === 'settings') content = settings();
  else if (selectedView === 'audit') content = `${header('Audit history', 'Every recovery step is recorded on the management host.')}${auditPanel(500)}`;
  else if (selectedView === 'operations') content = `${header('Recovery operations', 'Only one operation can run at a time.')}${state.jobs.length ? state.jobs.map(jobPanel).join('') : jobPanel()}${simulationPanel()}`;
  else {
    const a = state.servers[state.active] || {}, other = state.active === 'production' ? 'dr' : 'production';
    const observed = state.mode === 'observe' || state.mode === 'control';
    const fileStrip = observed ? `<div class="replication-strip"><strong>File consistency not verified</strong><span>Production Lsyncd: ${esc(state.servers.production.fileSync)} · DR Lsyncd: ${esc(state.servers.dr.fileSync)}</span><small>Service state does not prove copy direction or catch-up</small></div>` : `<div class="replication-strip"><span class="status-dot ${state.servers[other].role === 'replica' && state.servers[other].io ? 'good' : 'neutral'}"></span><strong>${label(state.fileSource)} → ${label(state.fileSource === 'production' ? 'dr' : 'production')}</strong><span>${state.servers[other].role === 'replica' ? 'Database + recordings' : 'Desired sync direction · peer rebuild required'}</span><small>Licence and local IP settings preserved</small></div>`;
    content = `${header('Disaster recovery', 'Manage server roles, replication and controlled cutover from one place.')}<div class="metrics"><div><span class="metric-label">${observed ? 'OBSERVED WRITER' : 'ACTIVE PRIMARY'}</span><strong>${state.active ? label(state.active) : 'Not verified'}</strong><small>${esc(a.ip || 'Neither sole writer nor fencing verified')}</small></div><div><span class="metric-label">REPLICATION</span><strong>${observed ? (['production', 'dr'].some(h => state.servers[h].io && state.servers[h].sql) ? 'Threads running' : 'Not healthy / verified') : state.servers[other].role === 'replica' && state.servers[other].io && state.servers[other].sql ? 'Connected' : 'Needs attention'}</strong><small>${observed ? 'Replica thread health only · files not verified' : state.servers[other].role === 'replica' ? 'Primary → read-only replica' : 'Standby not yet replicating'}</small></div><div><span class="metric-label">LAST OBSERVATION</span><strong class="metric-time">${time(state.checkedAt)}</strong><small>${state.mode === 'simulation' ? 'Local simulation state' : observed ? 'Read-only SSH snapshots' : 'Verified server hook'}</small></div></div><div class="server-grid">${serverCard('production')}${serverCard('dr')}</div>${fileStrip}<div class="section-heading workflow-title"><div><h2>Recovery workflow</h2><p>One active writer. Controlled promotion. Verified catch-up before cutover.</p></div></div><div class="actions-grid ${state.mode === 'control' ? 'prepare-cycle' : ''}">${actionCard('failover', 1, 'Fence production, persist the DR primary role and restore service on DR.')}${actionCard('rejoin', 2, 'Rebuild returning production from DR and keep it read-only while it catches up.')}${actionCard('failback', 3, 'Freeze DR, verify the final data boundary and return the primary role to production.')}${state.mode === 'control' ? actionCard('prepareDr', 4, 'Rebuild DR from active production. Preserve DR-local settings and leave its application stopped with read-only replication.') : ''}</div>${jobPanel()}${simulationPanel()}${auditPanel()}`;
  }
  const target = state.active === 'dr' ? 'production' : 'DR';
  const cutoverReady = state.mode === 'control' && !state.reconcileRequired && !state.observationError && !state.jobs.some(j => j.state === 'awaiting-validation') && (['production', 'dr'].includes(state.active)) && (() => {
    const replica = state.servers[state.active === 'dr' ? 'production' : 'dr'];
    return replica.reachable && replica.readOnly === true && replica.io === true && replica.sql === true && replica.lag === 0 && !replica.error && !replica.lastIoError && !replica.lastSqlError && replica.upstream === state.servers[state.active].ip && replica.control?.applicationFenced === true;
  })();
  const controls = state.mode === 'control' ? `<section class="panel"><h2>Cutover readiness</h2><p>Use Prepare ${target} to rebuild the standby. Preparation runs its own checks. Run cutover preflight only when the standby is a healthy read-only replica and you intend to switch the active server.</p><button class="button secondary" data-command="preflight" ${state.busy || !connected || !cutoverReady ? 'disabled' : ''}>Run cutover preflight</button>${state.preflight ? `<p>Passed ${time(state.preflight.at)}</p><ul>${state.preflight.checks.map(c => `<li>${esc(c)}</li>`).join('')}</ul>` : '<p>A completed preparation keeps the current primary active; it does not switch traffic.</p>'}</section>` : '';
  const recovery = state.mode === 'control' && state.actions.recover?.allowed ? `<section class="panel"><h2>Recover the fenced cutover</h2><p>Production is already stopped. The failed clock-evidence promotion can be reverified without restarting it. Confirm clocks are aligned and nobody has manually started the source. Manual-clock UAT approval is restricted to this job and expires after one hour.</p><button class="button primary" data-action="recover" ${!connected || state.busy ? 'disabled' : ''}>Recover fenced cutover</button></section>` : '';
  main.innerHTML = modeBanner() + alerts + recovery + controls + content;
  main.querySelectorAll('button').forEach((b, i) => b.dataset.focus = `${selectedView}-${i}`);
  if (focused) main.querySelector(`[data-focus="${focused}"]`)?.focus({ preventScroll: true });
}
function openConfirmation(action) {
  pendingAction = action;
  document.querySelector('#confirm-title').textContent = names[action];
  const descriptions = {
    failover: 'Promotion requires fencing production first. An unreachable server is not proof that it has stopped accepting writes.',
    rejoin: 'A fresh seed replaces the production application databases with the current DR data. Existing destination data must be backed up. Mixed MyISAM tables require a consistent locking backup and may briefly pause writes on DR.',
    prepareDr: 'A fresh seed replaces the DR application databases with current production data. Rollback backups preserve the four DR-local tables and environment files. Consistent locking backups can briefly pause production writes. Production remains primary and test routing stays on production.',
    failback: 'This operation briefly pauses DR writes. Production is promoted only after its database and recordings match the final DR boundary.',
    reconcile: 'Confirm you inspected remote jobs and both server roles. Refreshing status alone does not resolve a partially completed transfer or routing change.',
    validate: 'Confirm you changed test routing and successfully tested inbound/outbound calls, queues and recording playback. This is operator attestation, not an automatic traffic probe.',
    recover: 'Confirm clocks are now aligned and nobody has manually restarted the source database or application since fencing. This UAT recovery rechecks the existing reserved job and issues new evidence; it does not reuse expired receipts, restore databases or relax fencing. Manual-clock approval is job-bound and expires. A new failure will not auto-retry.'
  };
  document.querySelector('#confirm-description').textContent = descriptions[action] + (state.mode === 'simulation' ? ' This is a simulation; no server is changed.' : state.mode === 'control' && ['failover', 'failback'].includes(action) ? ' This planned cutover backs up both databases (brief write locks), pauses application traffic, preserves four local tables, and leaves the old primary fenced. Routing is manual.' : state.mode === 'control' && action === 'rejoin' ? ' This replaces the returning production application databases only after local rollback backups. Production stays read-only and its application stays fenced.' : ' This changes real servers.');
  const preparing = action === 'rejoin' || action === 'prepareDr';
  const from = action === 'prepareDr' ? 'production' : 'DR', to = action === 'prepareDr' ? 'DR' : 'production';
  const steps = state.mode === 'control' && ['failover', 'failback'].includes(action) ? ['Back up both servers and verify four isolated local tables', 'Freeze source writers, wait for exact GTID and checksum files', 'Persistently fence old database and promote/start target', 'Team changes routing and validates real calls; old peer stays fenced'] : state.mode === 'control' && preparing ? [`Verify ${from} authority, ${state.uatClockSkewMode ? 'three-host UAT clock skew' : 'NTP'}, ${to} application fencing and network access`, `Back up both servers and preserve the four ${to}-local tables`, `Verify source login; restore a signed ${from} seed and configure ${to} read-only replication`, `Baseline-copy eight folders; keep ${to} application stopped. Continuous file synchronization is not enabled.`] : stepList[action];
  document.querySelector('#confirm-steps').innerHTML = steps.map(s => `<li>${esc(s)}</li>`).join('');
  document.querySelector('#confirm-phrase').textContent = phrases[action];
  document.querySelector('#confirm-input').value = '';
  document.querySelector('#confirm-error').textContent = '';
  document.querySelector('#outage-label').hidden = action !== 'failover' || state.servers.production.reachable;
  document.querySelector('#outage-accepted').checked = false;
  updateConfirmation(); dialog.showModal(); document.querySelector('#confirm-input').focus();
}
function updateConfirmation() {
  const ack = document.querySelector('#outage-label').hidden || document.querySelector('#outage-accepted').checked;
  document.querySelector('#submit-operation').disabled = document.querySelector('#confirm-input').value !== phrases[pendingAction] || !ack;
}
main.addEventListener('click', async event => {
  const button = event.target.closest('button'); if (!button || button.disabled) return;
  try {
    if (button.dataset.action) return openConfirmation(button.dataset.action);
    if (button.dataset.demo) {
      if (button.dataset.demo === 'reset' && !window.confirm('Reset local simulation data and its demo history?')) return;
      state = await api('/api/demo', { command: button.dataset.demo }); render(); toast('Simulation updated');
    }
    if (button.dataset.command === 'refresh') { state = await api('/api/refresh', {}); render(); toast('Status refreshed'); }
    if (button.dataset.command === 'preflight') { state = await api('/api/preflight', {}); render(); toast('Preflight checks passed'); }
  } catch (error) { toast(error.message); }
});
document.querySelectorAll('[data-view]').forEach(button => button.addEventListener('click', () => {
  selectedView = button.dataset.view;
  document.querySelectorAll('[data-view]').forEach(b => { b.classList.toggle('active', b === button); b.setAttribute('aria-current', b === button ? 'page' : 'false'); }); render();
}));
document.querySelector('#cancel').addEventListener('click', () => dialog.close());
document.querySelector('#confirm-input').addEventListener('input', updateConfirmation);
document.querySelector('#outage-accepted').addEventListener('change', updateConfirmation);
document.querySelector('#confirm-form').addEventListener('submit', async event => {
  event.preventDefault(); document.querySelector('#submit-operation').disabled = true;
  try {
    const confirmation = document.querySelector('#confirm-input').value;
    await api(pendingAction === 'reconcile' ? '/api/reconcile' : pendingAction === 'validate' ? '/api/validate-traffic' : pendingAction === 'recover' ? '/api/recover-cutover' : '/api/jobs', { action: pendingAction, confirmation, outageAccepted: document.querySelector('#outage-accepted').checked });
    dialog.close(); state = await api('/api/state'); render(); toast('Operation recorded');
  } catch (error) { document.querySelector('#confirm-error').textContent = error.message; updateConfirmation(); }
});
async function poll() {
  try { state = await api('/api/state'); connected = true; render(); }
  catch { connected = false; render(); }
  finally { setTimeout(poll, 1800); }
}
try {
  const session = await fetch('/api/session').then(r => r.json()); token = session.token;
  await poll();
} catch (error) { main.textContent = `Unable to connect: ${error.message}. Refresh this page.`; }
