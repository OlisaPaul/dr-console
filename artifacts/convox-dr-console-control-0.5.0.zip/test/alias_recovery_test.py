"""Exercise one-off recovery guards with an entirely fake agent and temp files."""
import contextlib
import importlib.util
from importlib.machinery import SourceFileLoader
import io
import json
import os
import pathlib
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

script = (pathlib.Path(__file__).parents[1] / 'deploy' / 'recover-failed-alias-drill-rhel.sh').read_text()
code = compile(script.split("python3 - <<'PY'\n", 1)[1].rsplit('\nPY', 1)[0], 'recovery-fixture', 'exec')


class RecoveryTests(unittest.TestCase):
    def run_fixture(self, changes=None, fenced=True, expect_error=False):
        def require(condition, message):
            if not condition:
                raise RuntimeError(message)
        with tempfile.TemporaryDirectory() as directory:
            root = pathlib.Path(directory)
            state = {'jobId': '5e023f46-bd5f-4aa6-9fd6-c83237a757af', 'source': 'production', 'target': 'dr',
                     'boundary': '0-8111-98296', 'steps': {'fence': 'failed', 'backup': 'complete', 'quiesce': 'complete', 'boundary': 'complete', 'files': 'complete'}}
            database = {'serverId': 8111, 'readOnly': True, 'gtidCurrent': '0-8111-98296'}
            for key, value in (changes or {}).items():
                (database if key in database else state)[key] = value
            (root / 'operation.json').write_text(json.dumps(state))
            role = root / 'role.cnf'
            role.write_text('[mysqld]\nread_only=ON\n')
            order = []
            def dispatch(cfg, request):
                self.assertEqual(request['operation'], 'release')
                self.assertEqual(request['jobId'], state['jobId'])
                order.append('release')
            def persist(read_only):
                self.assertFalse(read_only)
                order.append('writable')
                database['readOnly'] = False
            agent = SimpleNamespace(ROOT=root, load_config=lambda: {'host': 'production'}, require=require,
                                    db=lambda: database, application_fenced=lambda: fenced,
                                    dispatch=Mock(side_effect=dispatch), persist_role=Mock(side_effect=persist))
            real_mkstemp, real_copy = tempfile.mkstemp, shutil.copyfile
            with patch.object(SourceFileLoader, 'exec_module'), patch.object(importlib.util, 'module_from_spec', return_value=agent), \
                 patch.dict(sys.modules, {'fcntl': SimpleNamespace(flock=Mock(), LOCK_EX=1, LOCK_NB=2)}), \
                 patch.object(os.path, 'islink', return_value=True), \
                 patch.object(os, 'readlink', side_effect=lambda path: '/dev/null' if path.endswith('/mariadb.service') else '/usr/lib/systemd/system/mariadb.service'), \
                 patch.object(tempfile, 'mkstemp', side_effect=lambda **kwargs: real_mkstemp(dir=directory)), \
                 patch.object(shutil, 'copyfile', side_effect=lambda source, target: real_copy(role, target)), \
                 contextlib.redirect_stdout(io.StringIO()):
                if expect_error:
                    with self.assertRaises(RuntimeError):
                        exec(code, {})
                    agent.dispatch.assert_not_called(); agent.persist_role.assert_not_called()
                else:
                    exec(code, {})
                    self.assertEqual(order, ['release', 'writable'])

    def test_exact_failed_job_releases_lock_before_restoring_only_production_role(self):
        self.run_fixture()

    def test_other_job_is_refused(self):
        self.run_fixture({'jobId': 'different-job'}, expect_error=True)

    def test_changed_gtid_or_already_writable_db_is_refused(self):
        for changes in [{'gtidCurrent': '0-8111-98297'}, {'readOnly': False}]:
            with self.subTest(changes=changes):
                self.run_fixture(changes, expect_error=True)

    def test_unfenced_application_is_refused(self):
        self.run_fixture(fenced=False, expect_error=True)

    def test_completed_fence_is_not_rolled_back(self):
        self.run_fixture({'fenced': True}, expect_error=True)
