"""Reserved-job installer tests redirect every mutation to mocks/temp files."""
import contextlib
import importlib.util
from importlib.machinery import SourceFileLoader
import io
import json
import os
import pathlib
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

script = (pathlib.Path(__file__).parents[1] / 'deploy' / 'install-fenced-recovery-rhel.sh').read_text()
code = compile(script.split("<<'PY'\n", 1)[1].rsplit('\nPY', 1)[0], 'fenced-installer-fixture', 'exec')
JOB = 'd6806999-884d-4cd5-b15c-2490123ad9be'


class InstallerTests(unittest.TestCase):
    def run_fixture(self, host='production', changes=None, fenced=True, chrony='inactive', expect_error=False):
        def require(condition, message):
            if not condition:
                raise RuntimeError(message)
        with tempfile.TemporaryDirectory() as directory:
            root = pathlib.Path(directory)
            candidate = root / 'candidate.py'
            candidate.write_text('updated_fixture = True\n')
            cfg = {'host': host, 'adminReviewedStartup': True, 'clusterSecret': 'test-secret-not-real'}
            state = {'jobId': JOB, 'source': 'production', 'target': 'dr', 'preflightPassed': True,
                     'steps': {'backup': 'complete', 'fence': 'complete'} if host == 'production' else {'backup': 'complete', 'promote': 'failed'},
                     'fenced': host == 'production', 'boundary': '0-8111-98296', 'filesVerified': '0-8111-98296', 'caughtUp': '0-8111-98296'}
            db = {'serverId': 30150, 'readOnly': True, 'gtidCurrent': '0-8111-98296', 'gtidSlave': '0-8111-98296'}
            for key, value in (changes or {}).items():
                (db if key in db else state)[key] = value
            before = json.dumps(state)
            (root / 'operation.json').write_text(before)
            atomic = Mock()
            agent = SimpleNamespace(ROOT=root, CONFIG=root / 'control.json', load_config=lambda: cfg, require=require,
                application_fenced=lambda: fenced, database_fenced=lambda: fenced, db=lambda: db,
                unit=lambda name: {'active': chrony}, atomic_json=atomic)
            real_stat, real_mkdtemp, real_mkstemp = pathlib.Path.stat, tempfile.mkdtemp, tempfile.mkstemp
            def stat(path, *args, **kwargs):
                if path == root:
                    return SimpleNamespace(st_uid=0, st_mode=0o40700)
                return real_stat(path, *args, **kwargs)
            with patch.object(SourceFileLoader, 'exec_module'), patch.object(importlib.util, 'module_from_spec', return_value=agent), \
                 patch.dict(sys.modules, {'fcntl': SimpleNamespace(flock=Mock(), LOCK_EX=1, LOCK_NB=2)}), \
                 patch.object(sys, 'argv', ['fixture', str(candidate), JOB]), patch.object(pathlib.Path, 'stat', stat), \
                 patch.object(tempfile, 'mkdtemp', side_effect=lambda **kwargs: real_mkdtemp(dir=directory)), \
                 patch.object(tempfile, 'mkstemp', side_effect=lambda **kwargs: real_mkstemp(dir=directory)), \
                 patch('shutil.copy2') as copy_old, patch.object(os, 'chown', create=True), \
                 patch.object(os, 'replace') as replace, patch('time.time', return_value=100), \
                 contextlib.redirect_stdout(io.StringIO()):
                if expect_error:
                    with self.assertRaises(RuntimeError):
                        exec(code, {})
                    atomic.assert_not_called(); copy_old.assert_not_called(); replace.assert_not_called()
                else:
                    exec(code, {})
                    self.assertEqual(cfg['manualRecoveryJobId'], JOB)
                    self.assertEqual(cfg['manualRecoveryExpires'], 3700)
                    self.assertEqual(cfg['clusterSecret'], 'test-secret-not-real')
                    atomic.assert_called_once(); replace.assert_called_once(); self.assertEqual(copy_old.call_count, 2)
                self.assertEqual((root / 'operation.json').read_text(), before, 'reservation must remain unchanged')

    def test_both_nodes_keep_reservations_and_roles_when_only_code_is_updated(self):
        for host in ['production', 'dr']:
            with self.subTest(host=host):
                self.run_fixture(host)

    def test_different_job_or_running_step_refuses_before_backups_or_install(self):
        for changes in [{'jobId': 'other-job'}, {'steps': {'fence': 'running'}}]:
            with self.subTest(changes=changes):
                self.run_fixture(changes=changes, expect_error=True)

    def test_unfenced_source_refuses_update(self):
        self.run_fixture(fenced=False, expect_error=True)

    def test_changed_target_role_or_gtid_refuses_update(self):
        for changes in [{'readOnly': False}, {'gtidCurrent': '0-30150-99999'}]:
            with self.subTest(changes=changes):
                self.run_fixture('dr', changes=changes, expect_error=True)

    def test_already_attempted_recovery_or_active_chrony_refuses_this_manual_install(self):
        self.run_fixture(changes={'steps': {'fence': 'complete', 'recover-evidence': 'complete'}}, expect_error=True)
        self.run_fixture(chrony='active', expect_error=True)
