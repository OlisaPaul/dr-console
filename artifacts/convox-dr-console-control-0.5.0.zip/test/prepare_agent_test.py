"""Both preparation directions; all MariaDB/SSH/systemctl operations are mocked."""
import contextlib
import hashlib
import json
import pathlib
import tempfile
import unittest
from unittest.mock import patch
from control_agent_test import agent


class PrepareTests(unittest.TestCase):
    def pair(self, target):
        source = 'production' if target == 'dr' else 'dr'
        cfg = {'host': target, 'clusterSecret': 'ab' * 32, 'adminReviewedStartup': True}
        req = {'version': 1, 'host': target, 'source': source, 'target': target, 'prepareVersion': 2,
               'operation': 'rejoin-restore', 'jobId': '12345678-1234-1234-1234-123456789abc'}
        return cfg, req

    @contextlib.contextmanager
    def fixture(self, target='dr'):
        cfg, req = self.pair(target)
        with tempfile.TemporaryDirectory() as folder, contextlib.ExitStack() as stack:
            root = pathlib.Path(folder)
            stack.enter_context(patch.object(agent, 'ROOT', root))
            transfer = root / 'transfer'
            transfer.mkdir()
            stack.enter_context(patch.object(agent, 'TRANSFER', transfer))
            directory = root / req['jobId']
            directory.mkdir()
            counts = dict(zip(agent.TABLES, [1, 1849, 1, 1]))
            for name in ['all.sql', 'local-tables.sql', 'environment.tar.gz']:
                (directory / name).write_bytes(('protected ' + name).encode())
            hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in directory.iterdir()}
            (directory / 'checksums.json').write_text(json.dumps(hashes))
            archive = transfer / (req['jobId'] + '.sql.gz')
            archive.write_bytes(b'checked seed fixture')
            req['seed'] = agent.sign_receipt({**cfg, 'host': req['source']}, req, 'seed',
                gtid='0-' + str(agent.IDS[req['source']]) + '-200', filename=archive.name,
                size=archive.stat().st_size, sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
            state = {'backup': str(directory), 'localCounts': counts, 'databaseOpened': True, 'steps': {'backup': 'complete'}}
            stack.enter_context(patch.object(agent, 'application_fenced', return_value=True))
            stack.enter_context(patch.object(agent, 'db', return_value={'serverId': agent.IDS[target], 'readOnly': True}))
            stack.enter_context(patch.object(agent, 'replica_options_persisted'))
            stack.enter_context(patch.object(agent, 'source_login_check'))
            def sql(statement, **kwargs):
                if statement.startswith('SELECT @@replicate'):
                    return 'filters\n' + ','.join('convoxcces_global.' + t for t in agent.TABLES)
                if statement.startswith('SELECT COUNT'):
                    table = next(t for t in agent.TABLES if '`' + t + '`' in statement)
                    return 'count\n' + str(counts[table])
                return ''
            queries = stack.enter_context(patch.object(agent, 'sql', side_effect=sql))
            imports = stack.enter_context(patch.object(agent, 'import_sql_stream'))
            yield cfg, req, state, directory, archive, queries, imports

    def test_restore_both_directions_preserves_four_tables_and_never_resets_source_binlogs(self):
        for target in ['dr', 'production']:
            with self.subTest(target=target), self.fixture(target) as (cfg, req, state, directory, archive, queries, imports):
                result = agent.rejoin_restore(cfg, req, state)
                self.assertTrue(result['ok'])
                self.assertTrue(state['restored'])
                self.assertEqual(imports.call_args_list[0].args, (archive,))
                self.assertEqual(imports.call_args_list[1].args, (directory / 'local-tables.sql', agent.LOCAL_TABLE_IMPORT_PREFIX))
                drop = next(c.args[0] for c in queries.call_args_list if 'DROP DATABASE' in c.args[0])
                self.assertIn('SET SESSION sql_log_bin=0;', drop)
                self.assertEqual(drop.count('DROP DATABASE'), len(agent.DATABASES))
                self.assertNotIn('`mysql`', drop)
                self.assertNotIn('RESET MASTER', drop)
                self.assertNotIn('read_only=OFF', str(queries.call_args_list))
                self.assertFalse(archive.exists())

    def test_bad_backup_bad_seed_or_login_failure_refuses_before_drop_or_import(self):
        for failure in ['backup', 'seed', 'login', 'writable', 'missing-filter']:
            with self.subTest(failure=failure), self.fixture() as (cfg, req, state, directory, archive, queries, imports), contextlib.ExitStack() as stack:
                if failure == 'backup': (directory / 'local-tables.sql').write_bytes(b'corrupt')
                if failure == 'seed': archive.write_bytes(b'corrupt')
                if failure == 'login': stack.enter_context(patch.object(agent, 'source_login_check', side_effect=agent.Refusal('login failed')))
                if failure == 'writable': stack.enter_context(patch.object(agent, 'db', return_value={'serverId': 30150, 'readOnly': False}))
                if failure == 'missing-filter': queries.side_effect = lambda *a, **kw: 'filters\nconvoxcces_global.convoxccs_license_details'
                with self.assertRaises(agent.Refusal): agent.rejoin_restore(cfg, req, state)
                imports.assert_not_called()
                self.assertFalse(any('DROP DATABASE' in c.args[0] for c in queries.call_args_list))

    def test_tcp_probe_is_target_to_source_and_reports_direction_without_secrets(self):
        for target in ['dr', 'production']:
            cfg, req = self.pair(target)
            with patch.object(agent.socket, 'create_connection', side_effect=TimeoutError) as connect, self.assertRaisesRegex(agent.Refusal, agent.IPS[req['source']] + ':3306'):
                agent.source_tcp_check(req)
            connect.assert_called_once_with((agent.IPS[req['source']], 3306), timeout=5)

    def test_source_login_uses_private_temporary_defaults_and_verifies_identity(self):
        cfg, req = self.pair('dr')
        for valid in [True, False]:
            with tempfile.TemporaryDirectory() as folder, patch.object(agent, 'ROOT', pathlib.Path(folder)), patch.object(agent, 'replication_password', return_value='not-a-real-password-123'):
                def run(args, **kwargs):
                    self.assertNotIn('not-a-real-password', ' '.join(args))
                    defaults = pathlib.Path(args[1].split('=', 1)[1])
                    self.assertIn('password="not-a-real-password-123"', defaults.read_text())
                    self.assertIn('--host=10.81.0.11', args)
                    return 'serverId\treadOnly\tlogBin\n' + ('8111' if valid else '30150') + '\t0\t1'
                with patch.object(agent, 'command', side_effect=run):
                    if valid: agent.source_login_check(cfg, req)
                    else:
                        with self.assertRaisesRegex(agent.Refusal, 'expected writable'): agent.source_login_check(cfg, req)
                self.assertEqual(list(pathlib.Path(folder).iterdir()), [], 'Secret defaults removed')

    def test_prepare_check_connectivity_failure_precedes_open_or_backup(self):
        cfg, req = self.pair('dr')
        cfg['fileIdentity'] = '/fixture/key'
        with patch.object(agent, 'clock_evidence', return_value={}), patch.object(agent, 'replica_options_persisted'), \
             patch.object(agent.pathlib.Path, 'is_dir', return_value=True), patch.object(agent.pathlib.Path, 'resolve', lambda self: self), \
             patch.object(agent.pathlib.Path, 'is_file', return_value=True), patch.object(agent.shutil, 'disk_usage', return_value=type('Space', (), {'free': 10**10})()), \
             patch.object(agent, 'file_ssh'), patch.object(agent.socket, 'create_connection', side_effect=TimeoutError), \
             patch.object(agent, 'sql') as sql, patch.object(agent, 'unmask_database_units') as unmask, self.assertRaisesRegex(agent.Refusal, '3306'):
            agent.rejoin_check(cfg, req, {})
        sql.assert_not_called(); unmask.assert_not_called()

    def test_preparation_checks_destination_acl_as_receiver_before_restore(self):
        cfg, req = self.pair('dr')
        cfg['host'] = req['source']
        with patch.object(agent.pathlib.Path, 'is_dir', return_value=True), patch.object(agent.pathlib.Path, 'resolve', lambda self: self), \
             patch.object(agent, 'file_ssh', return_value='/etc/asterisk/private\n') as ssh, self.assertRaisesRegex(agent.Refusal, 'directory access'):
            agent.preparation_file_checks(cfg, req)
        self.assertEqual(ssh.call_args.args[1], 'dr')
        self.assertNotIn('/var/www/convox4.conf', ssh.call_args.args[2])

    def test_old_controller_cannot_reserve_and_execute_new_preparation_without_protocol(self):
        cfg, req = self.pair('dr')
        del req['prepareVersion']
        with patch.object(agent, 'clock_evidence') as clock, self.assertRaisesRegex(agent.Refusal, 'Upgrade archival'):
            agent.rejoin_check(cfg, req, {})
        clock.assert_not_called()

    def test_replication_direction_and_gtid_slave_pos_are_bound_to_request(self):
        for target in ['dr', 'production']:
            cfg, req = self.pair(target)
            replica = 'Master_Host\tSlave_IO_Running\tSlave_SQL_Running\tLast_IO_Error\tLast_SQL_Error\n' + agent.IPS[req['source']] + '\tYes\tYes\t\t'
            state = {'restored': True, 'seedGtid': '0-8111-200'}
            with patch.object(agent, 'application_fenced', return_value=True), patch.object(agent, 'replication_password', return_value='private-fixture-password'), \
                 patch.object(agent, 'sql_stdin') as write, patch.object(agent, 'sql', side_effect=[replica, 'reached\n0']):
                self.assertTrue(agent.rejoin_replicate(cfg, req, state)['ok'])
                statement = write.call_args.args[0]
                self.assertIn("MASTER_HOST='" + agent.IPS[req['source']] + "'", statement)
                self.assertIn('MASTER_USE_GTID=slave_pos', statement)
                self.assertNotIn('RESET MASTER', statement)

    def test_post_copy_verification_requires_fresh_source_receipt_and_reached_gtid(self):
        cfg, req = self.pair('dr')
        req['operation'] = 'rejoin-verify'
        state = {'replicating': True, 'restored': True}
        with patch.object(agent, 'application_fenced', return_value=True), patch.object(agent, 'sql') as sql:
            with self.assertRaises(agent.Refusal): agent.rejoin_verify(cfg, req, state)
            sql.assert_not_called()
            req['baseline'] = agent.sign_receipt({**cfg, 'host': req['source']}, req, 'baseline', gtid='0-8111-300')
            sql.return_value = 'reached\n-1'
            with self.assertRaisesRegex(agent.Refusal, 'source boundary'): agent.rejoin_verify(cfg, req, state)


if __name__ == '__main__':
    unittest.main()
