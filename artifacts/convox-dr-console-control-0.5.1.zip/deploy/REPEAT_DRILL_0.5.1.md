# Repeat the complete UI drill — 0.5.1

This upgrade is for the current state: production (10.81.0.11) is the sole
writable primary, and Prepare DR has completed, leaving DR (10.3.0.150) a
read-only replica with its application fenced. Archival (10.3.0.151) hosts the
console on HTTPS/443. Do not manually unmask DR application services.

## What was checked and fixed

- The reserved cutover preflight now checks both readiness responses, not just
  whether SSH returned successfully. A failed parallel check waits for the other
  agent to finish before the console permits reconciliation.
- UAT clock checks use a separate small read-only request, including when the
  source database is stopped. The complete two-host SSH measurement window and
  all three clock samples must fit within five seconds. Slow replies or clock
  changes fail closed. Checks repeat before stopping the source, promoting the
  target, opening a returning database and restoring its seed. Receipt lifetimes
  and the four-hour opt-in remain unchanged; this is not NTP synchronization.
  A controller clock rejection after source fencing can use the separately
  confirmed Recover fenced cutover action once clocks are corrected. It must
  reverify the source fence, exact target GTID, file checksums and fresh clocks;
  no failed promotion is blindly replayed.
- Catch-up and promotion verify the target's identity, read-only role and exact
  current/applied GTID. Promotion rechecks after stopping replication and before
  resetting its metadata. A privileged local write blocks promotion.
- Managed service stop gets 60 seconds, exceeding the runtime unit's 45-second
  grace. Controller timeouts cover the bounded activation, file and recovery
  operations. SQL import has a deadline during input streaming as well as wait;
  a full stderr pipe cannot deadlock it. Import diagnostics stay root-private.
- Final role/fence/runtime verification happens before inviting team validation.
  If final reservation release hits a transient SSH error, retry the same routing
  confirmation after checking status; promotion is not replayed.
- Destination directory ACLs are checked during cutover preflight as well as
  standby preparation. Both TCP/3306 directions are checked by this rollout.

The automated tests exercise the real controller against stateful fake restricted
agents through two complete round trips, plus failures and agent guards. SQL,
systemd, SIP/carrier behavior and real RHEL integration still require this
supervised drill; local test success is not a guarantee of a fault-free deployment.
Release validation: 86 Node tests, 78 Python tests and syntax checks on all 11
deployment shell scripts passed. Node and Python source syntax checks also passed.

## Upgrade once, from archival

Finish any outstanding UI validation first. There must be no running/reserved or
unreconciled job. Keep other operators out of the console during installation.
No calls should be active when you subsequently run cutover preflight.

From Windows PowerShell:

```powershell
scp "C:\Users\DEEPIJA\Documents\ConVoxCCS\dr-console\artifacts\convox-dr-console-control-0.5.1.zip" "C:\Users\DEEPIJA\Documents\ConVoxCCS\dr-console\artifacts\convox-dr-console-control-0.5.1.zip.sha256" root@10.3.0.151:/root/
```

Then on **archival as root**, paste this complete block. It stops at the first
error; no unset PACKAGE_DIR variable or separate manual agent copies are needed.

```bash
(
    set -e
    umask 077
    cd /root
    sha256sum -c convox-dr-console-control-0.5.1.zip.sha256
    test ! -L /root/convox-console-control-0.5.1
    install -d -m 0700 /root/convox-console-control-0.5.1
    unzip -o /root/convox-dr-console-control-0.5.1.zip -d /root/convox-console-control-0.5.1
    bash /root/convox-console-control-0.5.1/deploy/rollout-prepare-dr-rhel.sh --uat
)
```

`--uat` renews the explicit four-hour relative-clock approval on archival and both
agents. It does not set or synchronize clocks. Omit it when all hosts have working
NTP and UAT mode is disabled. Do not step clocks during a job. Finish the drill
within the approval window; if it expires, do not edit state/receipt timestamps.

The rollout checks the package manifest, fixed host identities, initial database
roles, peer TCP/3306 routes and absence of reservations. It copies and installs
both agents, upgrades the controller and confirms agent 0.5.1/cutoverVersion 2.
It preserves settings, state, authentication, host keys and all local data. It
backs up the replaced code and configuration. Only archival's console service is
restarted; production/DR databases and applications are not stopped or started.
The website may briefly show 502 during that controller restart.

Root SSH password prompts are normal if administrator SSH keys are not configured.
Do not bypass host-key verification. If the rollout fails, keep the error and
inspect before running UI operations; do not delete reservation files.

## Full UI sequence

Open https://10.3.0.151, hard-refresh (Ctrl+F5), sign in and click **Refresh status**.
Check production is writable/runtime healthy; DR is read-only, replicating from
production with both threads running and no replication errors. DR application
fencing is expected. A stopped Lsyncd service is also expected after managed
cutovers; the console does final copies and preparation baselines, not continuous
file synchronization.

| Step | UI action / confirmation | Required result before continuing |
| --- | --- | --- |
| 1 | Drain test calls; **Run cutover preflight** | Preflight passed. Start within five minutes. |
| 2 | **Bring DR online** → `PROMOTE DR` | Awaiting team validation; DR writable/runtime healthy, production database and application fenced. |
| 3 | Manually route test web/SIP endpoints to **10.3.0.150**; test calls, then **Confirm routing and call tests** → `I TESTED ROUTING AND CALLS` | The cutover job is complete. Keep production fenced. |
| 4 | **Prepare production** → `REBUILD PRODUCTION` | Complete: production replicates from DR read-only; its application stays fenced; DR remains active. Do not switch routing here. |
| 5 | Drain test calls; **Run cutover preflight** again | Fresh preflight passed for DR → production. |
| 6 | **Cut over to production** → `CUT OVER TO PRODUCTION` | Awaiting team validation; production writable/runtime healthy, DR database and application fenced. |
| 7 | Manually route test web/SIP endpoints back to **10.81.0.11**; repeat call tests, then confirm `I TESTED ROUTING AND CALLS` | The return cutover job is complete. |
| 8 | **Prepare DR** → `REBUILD DR` | Complete: production remains primary, DR replicates from production read-only, and DR application remains fenced. |

Both Prepare actions have their own preparation checks. Do **not** run cutover
preflight while the returning server database is still stopped; prepare it first.
Neither Prepare action promotes its target or changes client routing.

At each team-validation pause, verify login, SIP registration, inbound/outbound
calls, audio both ways, queues/agent state and playback of a new recording. Save a
recognizable UAT record on the active primary; verify it survives the return trip.
Also verify each server retains its own licence, notifications, server/web-server
mappings and environment files. These four whole tables are intentionally local,
so differences between them are expected and need local maintenance.

After step 8, Refresh status again. Expected final state:

- Production is the only writer, its managed runtime is healthy, and routing is
  on production.
- DR is reachable/read-only with both replication threads running, zero observed
  lag and production as upstream; its application is stopped/persistently masked.
- Both last jobs are complete, no team validation/reconciliation remains pending,
  and a new cutover still requires fresh preflight.

## Boundaries and failure handling

Backups and consistent seed creation briefly lock database writes. Cutovers pause
application traffic. File copies are asynchronous baselines during preparation,
then checksum-verified after source quiescence at cutover; do not claim continuous
file mirroring, zero recording loss in an unplanned failure or automatic carrier
routing. Copies do not delete destination-only files or rewrite ownership/modes.

The final source read lock remains bounded at ten minutes and evidence expiry is
not extended. A large/slow final copy can deliberately stop the operation. Do not
bypass that check; plan a maintenance window and reduce the final copy workload.

If any stage fails, do not click the next action or manually start both servers.
Keep the job/error, inspect actual roles and let the UI's guarded recovery or
reconciliation procedure determine the next step. An error during final routing
confirmation's reservation release can retry that same confirmation after status
is healthy; do not start a second cutover. No automatic rollback is attempted.

Before go-live, restore genuine NTP on all three hosts and disable the UAT exception.
Complete separate unplanned-outage/fencing, capacity, backup-restore and real routing
acceptance testing. This drill covers planned switchovers, not loss-of-source promotion.
