import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import path from 'node:path';
import { tmpdir } from 'node:os';
import { ControlController } from '../lib/control.mjs';

async function setup(t, refusal) {
  const dataDir = await mkdtemp(path.join(tmpdir(), 'fenced-cutover-'));
  t.after(() => rm(dataDir, { recursive: true, force: true }));
  const observed = { active: null, fileSource: null, warnings: [], servers: {
    production: { sshReachable: true, reachable: false, readOnly: null, control: { applicationFenced: true, databaseFenced: true, recoverySupported: true } },
    dr: { sshReachable: true, reachable: true, readOnly: true, sql: true, upstream: '10.81.0.11', gtid: '0-8111-98296', gtidSlave: '0-8111-98296', control: { applicationFenced: true, runtimeHealthy: false, recoverySupported: true } }
  } };
  const calls = [];
  const adapter = { observe: async () => structuredClone(observed), call: async (host, operation, jobId, details) => {
    calls.push({ host, operation, jobId, details: structuredClone(details) });
    if (operation === refusal) throw new Error(`${operation} refused`);
    if (operation === 'recover-promote') { observed.active = 'dr'; observed.servers.dr.readOnly = false; }
    if (operation === 'activate') observed.servers.dr.control.runtimeHealthy = true;
    return { ok: true, ready: true, proofs: { boundary: 'new-boundary', files: 'new-files', fence: 'new-fence' }, proof: 'renewed-fence' };
  } };
  const c = await new ControlController({ dataDir, adapter, mode: 'control' }).init();
  const job = { id: 'd6806999-884d-4cd5-b15c-2490123ad9be', action: 'failover', source: 'production', target: 'dr',
    state: 'failed', error: 'Source evidence is stale; clocks must be synchronized', steps: [{ key: 'fence', state: 'complete' }, { key: 'promote', state: 'failed' }] };
  c.state.jobs = [job]; c.state.reconcileRequired = true;
  await c.refresh();
  return { c, calls, observed, job, dataDir };
}

test('fenced recovery is guarded separately from normal cutover and preserves the failed attempt', async t => {
  const { c, calls, job } = await setup(t);
  assert.equal(c.view().actions.failover.allowed, false);
  assert.equal(c.view().actions.recover.allowed, true);
  await c.recoverCutover('RECOVER FENCED CUTOVER', 'uat-operator'); await c.pending;
  assert.deepEqual(calls.map(c => c.operation), ['recover-check', 'recover-evidence', 'fence', 'recover-promote', 'activate']);
  assert.equal(calls.find(c => c.operation === 'recover-promote').details.fence, 'renewed-fence');
  assert.equal(job.state, 'awaiting-validation'); assert.equal(c.state.reconcileRequired, false);
  assert.equal(job.previousAttempts[0].steps[1].state, 'failed'); assert.equal(job.recoveredBy, 'uat-operator');
  await c.validateTraffic('I TESTED ROUTING AND CALLS', 'tester');
  assert.equal(job.state, 'complete');
});

test('changed target GTID or lost source fence blocks recovery before remote requests', async t => {
  const { c, calls, observed } = await setup(t);
  observed.servers.dr.gtid = '0-30150-999';
  await assert.rejects(c.recoverCutover('RECOVER FENCED CUTOVER'), /unchanged replica GTID/);
  assert.equal(calls.length, 0);
  observed.servers.dr.gtid = observed.servers.dr.gtidSlave;
  observed.servers.production.control.databaseFenced = false;
  await assert.rejects(c.recoverCutover('RECOVER FENCED CUTOVER'), /Verified stopped source/);
});

for (const operation of ['recover-check', 'recover-evidence', 'fence', 'recover-promote', 'activate']) {
  test(`${operation} recovery failure never enables automatic replay`, async t => {
    const { c, calls, job } = await setup(t, operation);
    await c.recoverCutover('RECOVER FENCED CUTOVER'); await c.pending;
    assert.equal(job.state, 'failed'); assert.equal(c.state.reconcileRequired, true);
    await assert.rejects(c.recoverCutover('RECOVER FENCED CUTOVER'));
    if (['recover-check', 'recover-evidence', 'fence'].includes(operation)) assert.equal(calls.some(c => c.operation === 'recover-promote'), false);
  });
}

test('controller restart does not auto-resume a recovered operation', async t => {
  const { c, dataDir } = await setup(t);
  c.state.jobs[0].state = 'running'; c.state.jobs[0].recoveryAttempted = true;
  await c.save();
  const calls = [];
  const restarted = await new ControlController({ dataDir, mode: 'control', adapter: { call: async () => calls.push(true) } }).init();
  assert.equal(restarted.state.jobs[0].state, 'interrupted'); assert.equal(calls.length, 0);
  assert.equal(restarted.view().actions.recover.allowed, false);
});

test('a mixed old/new agent deployment cannot consume the recovery attempt', async t => {
  const { c, observed, calls, job } = await setup(t);
  observed.servers.dr.control.recoverySupported = undefined;
  await assert.rejects(c.recoverCutover('RECOVER FENCED CUTOVER'), /both servers first/);
  assert.equal(job.recoveryAttempted, undefined); assert.equal(calls.length, 0);
});

test('a post-fence controller clock rejection has a guarded UAT recovery path with fresh samples', async t => {
  const { c, calls, job } = await setup(t);
  job.error = 'Production, DR and archival clocks must be within 5 seconds';
  job.recoveryCause = 'promotion-clock-check';
  c.adapter.config = { uatClockSkewMode: true, uatClockSkewExpires: Date.now() / 1000 + 1000 };
  const original = c.adapter.call;
  c.adapter.call = async (...args) => {
    const result = await original(...args);
    return args[1] === 'clock-check' ? { ...result, clock: { mode: 'uat-relative', epochMs: Date.now() } } : result;
  };
  assert.equal(c.view().actions.recover.allowed, true);
  await c.recoverCutover('RECOVER FENCED CUTOVER'); await c.pending;
  assert.equal(job.state, 'awaiting-validation', job.error);
  assert.equal(calls.filter(call => call.operation === 'clock-check').length, 4);
  assert.equal(calls.find(call => call.operation === 'recover-promote').details.uatClockSkewMode, true);
});
