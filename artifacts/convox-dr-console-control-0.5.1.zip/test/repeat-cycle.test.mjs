// Stateful fake restricted agents: exercise the real controller, never SSH/SQL.
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { ControlController, controlTimeout, verifyRelativeClocks } from '../lib/control.mjs';
import { HOSTS, IP, LOCAL_TABLES } from '../lib/model.mjs';

async function fixture(t, uat = false) {
  const dataDir = await mkdtemp(path.join(tmpdir(), 'convox-repeat-'));
  t.after(() => rm(dataDir, { recursive: true, force: true }));
  const obs = { active: 'production', fileSource: null, warnings: [], servers: {} };
  const reservations = {}, histories = [], calls = [], data = {}, local = {};
  for (const host of HOSTS) {
    const primary = host === 'production';
    obs.servers[host] = { ip: IP[host], reachable: true, sshReachable: true, role: primary ? 'primary' : 'replica',
      readOnly: !primary, upstream: primary ? null : IP.production, io: !primary, sql: !primary, lag: 0,
      control: { prepareVersion: 2, cutoverVersion: 2, databaseFenced: false, applicationFenced: !primary, runtimeHealthy: primary } };
    data[host] = ['initial'];
    local[host] = Object.fromEntries(LOCAL_TABLES.map(name => [name, `${host}:${name}`]));
  }
  const adapter = { config: uat ? { uatClockSkewMode: true, uatClockSkewExpires: Date.now() / 1000 + 14000 } : {},
    observe: async () => structuredClone(obs),
    call: async (host, op, jobId, details = {}) => {
      calls.push({ host, op, jobId, details: structuredClone(details) });
      if (op === 'clock-check') return { ok: true, clock: { mode: 'uat-relative', epochMs: Date.now() } };
      if (op === 'reserve') {
        assert.equal(reservations[host], undefined, 'Previous job must release before the next cycle');
        reservations[host] = { jobId, steps: [], ...structuredClone(details) };
      } else if (op !== 'preflight' || jobId) {
        if (op === 'release' && !reservations[host]) return { ok: true };
        assert.equal(reservations[host]?.jobId, jobId, 'Mutations must match the reserved job');
      }
      const source = details.source, target = details.target, node = obs.servers[host];
      if (op === 'quiesce') {
        assert.equal(host, source); assert.ok(reservations[host].steps.includes('backup'));
        node.readOnly = true; node.control.applicationFenced = true; node.control.runtimeHealthy = false; obs.active = null;
      }
      if (op === 'boundary') assert.equal(node.readOnly, true);
      if (op === 'catchup') data[target] = [...data[source]];
      if (op === 'fence') {
        assert.equal(host, source); assert.ok(reservations[host].steps.includes('files'));
        assert.equal(node.control.applicationFenced, true);
        node.control.databaseFenced = true; node.reachable = false; node.readOnly = null; node.role = 'fenced';
      }
      if (op === 'promote') {
        assert.equal(host, target); assert.equal(obs.servers[source].control.databaseFenced, true);
        assert.deepEqual(data[source], data[target]);
        obs.active = target; node.readOnly = false; node.role = 'primary'; node.upstream = null; node.io = false; node.sql = false;
      }
      if (op === 'activate') {
        assert.equal(obs.active, target); node.control.runtimeHealthy = true; node.control.applicationFenced = false;
      }
      if (op === 'rejoin-open') {
        assert.equal(host, target); assert.equal(node.control.applicationFenced, true);
        node.reachable = true; node.readOnly = true; node.control.databaseFenced = false;
      }
      if (op === 'rejoin-restore') {
        assert.equal(node.readOnly, true); assert.equal(node.control.applicationFenced, true);
        assert.ok(reservations[host].steps.includes('backup'));
        data[target] = [...data[source]]; // Four local tables deliberately not replaced.
      }
      if (op === 'rejoin-replicate') Object.assign(node, { role: 'replica', upstream: IP[source], io: true, sql: true, lag: 0 });
      if (op === 'release') { histories.push(reservations[host]); delete reservations[host]; }
      else if (reservations[host]) reservations[host].steps.push(op);
      return { ok: true, ready: true, prepareVersion: 2, credentialId: 'same', proof: { kind: op }, checks: [] };
    }
  };
  const c = await new ControlController({ dataDir, adapter, mode: 'control' }).init();
  return { c, adapter, obs, calls, data, local, reservations, histories };
}

test('two full live-controller round trips preserve target-local tables and release every reservation', async t => {
  const { c, obs, data, local, reservations, histories, calls } = await fixture(t, true);
  const originalLocal = structuredClone(local);
  for (let cycle = 0; cycle < 2; cycle++) {
    for (const [action, phrase, source, target, prepare, preparePhrase] of [
      ['failover', 'PROMOTE DR', 'production', 'dr', 'rejoin', 'REBUILD PRODUCTION'],
      ['failback', 'CUT OVER TO PRODUCTION', 'dr', 'production', 'prepareDr', 'REBUILD DR']
    ]) {
      data[source].push(`cycle-${cycle}-${source}`);
      await c.preflight(); await c.start(action, phrase); await c.pending;
      assert.equal(c.state.jobs[0].state, 'awaiting-validation', c.state.jobs[0].error);
      assert.equal(obs.active, target); assert.equal(obs.servers[source].control.databaseFenced, true);
      assert.deepEqual(data[target], data[source]);
      await assert.rejects(c.start(prepare, preparePhrase), /Validate routing/);
      await c.validateTraffic('I TESTED ROUTING AND CALLS');
      assert.deepEqual(reservations, {});
      data[target].push(`after-promotion-${cycle}-${target}`);
      await c.start(prepare, preparePhrase); await c.pending;
      assert.equal(c.state.jobs[0].state, 'complete', c.state.jobs[0].error);
      assert.equal(obs.servers[source].readOnly, true);
      assert.equal(obs.servers[source].control.applicationFenced, true);
      assert.deepEqual(data[source], data[target]); assert.deepEqual(local, originalLocal);
      assert.deepEqual(reservations, {}); assert.equal(c.state.preflight, null);
    }
    assert.equal(obs.active, 'production'); assert.equal(obs.servers.dr.upstream, IP.production);
  }
  assert.equal(c.state.jobs.length, 8); assert.equal(histories.length, 16);
  assert.ok(calls.filter(call => call.op === 'clock-check').length >= 24);
});

test('reserved preflight ready=false cannot be ignored after the initial preflight passes', async t => {
  const { c, adapter, calls } = await fixture(t);
  await c.preflight(); const original = adapter.call;
  adapter.call = async (...args) => {
    const result = await original(...args);
    return args[1] === 'preflight' && args[2] ? { ...result, ready: false } : result;
  };
  await c.start('failover', 'PROMOTE DR'); await c.pending;
  assert.equal(c.state.jobs[0].state, 'failed'); assert.match(c.state.jobs[0].error, /Reserved server preflight/);
  assert.ok(!calls.some(call => call.op === 'backup'));
});

test('clock drift after initial preflight is rejected before stopping the source', async t => {
  const { c, adapter, calls } = await fixture(t, true);
  await c.preflight(); const original = adapter.call;
  adapter.call = async (...args) => {
    const result = await original(...args);
    if (args[1] === 'clock-check' && args[0] === 'dr') result.clock.epochMs += 10000;
    return result;
  };
  await c.start('failover', 'PROMOTE DR'); await c.pending;
  assert.match(c.state.jobs[0].error, /within 5 seconds/);
  assert.ok(!calls.some(call => call.op === 'quiesce'));
});

test('clock measurement rejects a slow interval that previously concealed relative skew', () => {
  assert.throws(() => verifyRelativeClocks([
    { clock: { mode: 'uat-relative', epochMs: 16000 } }, { clock: { mode: 'uat-relative', epochMs: 16000 } }
  ], 10000, 20000), /within 5 seconds/);
});

test('parallel preflight failure waits for the other agent before unlocking the controller', async t => {
  const { c, adapter } = await fixture(t);
  const original = adapter.call; let otherFinished = false;
  adapter.call = async (...args) => {
    if (args[1] !== 'preflight') return original(...args);
    if (args[0] === 'production') throw new Error('first check failed');
    await delay(40); otherFinished = true; return { ok: true, ready: true };
  };
  await assert.rejects(c.preflight(), /first check failed/);
  assert.equal(otherFinished, true); assert.equal(c.refreshing, false);
});

test('final runtime loss fails the routing step instead of falsely inviting validation', async t => {
  const { c, adapter, obs } = await fixture(t);
  const original = adapter.call;
  adapter.call = async (...args) => {
    const result = await original(...args);
    if (args[1] === 'activate') obs.servers.dr.control.runtimeHealthy = false;
    return result;
  };
  await c.preflight(); await c.start('failover', 'PROMOTE DR'); await c.pending;
  assert.equal(c.state.jobs[0].state, 'failed'); assert.equal(c.state.jobs[0].steps.at(-1).state, 'failed');
  assert.match(c.state.jobs[0].error, /runtime observation/);
});

test('partial reservation release during call confirmation can retry without replaying promotion', async t => {
  const { c, adapter, reservations, calls } = await fixture(t);
  await c.preflight(); await c.start('failover', 'PROMOTE DR'); await c.pending;
  const original = adapter.call; let fail = true;
  adapter.call = async (...args) => {
    if (args[1] === 'release' && args[0] === 'dr' && fail) { fail = false; throw new Error('temporary SSH failure'); }
    return original(...args);
  };
  await assert.rejects(c.validateTraffic('I TESTED ROUTING AND CALLS'), /temporary SSH/);
  assert.equal(c.state.jobs[0].state, 'awaiting-validation'); assert.equal(c.state.reconcileRequired, false);
  assert.equal(reservations.production, undefined); assert.ok(reservations.dr);
  await c.validateTraffic('I TESTED ROUTING AND CALLS');
  assert.deepEqual(reservations, {}); assert.equal(c.state.jobs[0].state, 'complete');
  assert.equal(calls.filter(call => call.op === 'promote').length, 1);
});

test('mixed cutover agents are rejected before server preflight or mutation', async t => {
  const { c, obs, calls } = await fixture(t);
  delete obs.servers.dr.control.cutoverVersion;
  await assert.rejects(c.preflight(), /0.5.1/); assert.equal(calls.length, 0);
});

test('transport timeouts exceed bounded service, label, restore and file operations', () => {
  assert.ok(controlTimeout('quiesce') > 7 * 60000 + 60000);
  assert.ok(controlTimeout('activate') > 8 * 60000 + 3 * 60000 + 30000);
  assert.ok(controlTimeout('rejoin-restore') > 2 * 245000);
  assert.ok(controlTimeout('files') > 8 * 2 * 180000);
  assert.ok(controlTimeout('recover-evidence') > 8 * 180000);
});
