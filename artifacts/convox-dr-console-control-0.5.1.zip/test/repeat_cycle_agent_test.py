"""Cutover guard tests; no real MariaDB, SSH or systemd operations run."""
import os
import pathlib
import sys
import tempfile
import time
import unittest
from contextlib import ExitStack
from unittest.mock import patch
from control_agent_test import agent


class RepeatCycleAgentTests(unittest.TestCase):
    def setUp(self):
        self.source = {'host': 'production', 'clusterSecret': 'ab' * 32}
        self.cfg = {**self.source, 'host': 'dr'}
        self.request = {'version': 1, 'host': 'dr', 'source': 'production', 'target': 'dr',
                        'operation': 'promote', 'jobId': '12345678-1234-1234-1234-123456789abc'}
        self.state = {'backup': 'fixture', 'steps': {'backup': 'complete'}, 'caughtUp': '0-8111-100'}
        self.database = {'serverId': 30150, 'readOnly': True, 'logBin': True, 'logSlaveUpdates': True,
                         'eventScheduler': 'OFF', 'gtidCurrent': '0-8111-100', 'gtidSlave': '0-8111-100'}
        for kind in ['boundary', 'files', 'fence']:
            self.request[kind] = agent.sign_receipt(self.source, self.request, kind, gtid='0-8111-100')

    def test_each_unsafe_target_change_blocks_promotion_before_stop_reset_or_role_change(self):
        for field, value in [('serverId', 8111), ('readOnly', False), ('logBin', False),
                             ('logSlaveUpdates', False), ('eventScheduler', 'ON'),
                             ('gtidCurrent', '0-30150-101'), ('gtidSlave', '0-8111-99')]:
            with self.subTest(field=field), ExitStack() as stack:
                stack.enter_context(patch.object(agent, 'application_fenced', return_value=True))
                stack.enter_context(patch.object(agent, 'require_clock'))
                stack.enter_context(patch.object(agent, 'db', return_value={**self.database, field: value}))
                sql = stack.enter_context(patch.object(agent, 'sql'))
                role = stack.enter_context(patch.object(agent, 'persist_role'))
                with self.assertRaises(agent.Refusal):
                    agent.promote(self.cfg, self.request, self.state)
                sql.assert_not_called(); role.assert_not_called()

    def test_boundary_is_rechecked_after_stop_before_discarding_replication_metadata(self):
        with patch.object(agent, 'application_fenced', return_value=True), patch.object(agent, 'require_clock'), \
             patch.object(agent, 'db', side_effect=[self.database, {**self.database, 'gtidCurrent': '0-30150-101'}]), \
             patch.object(agent, 'sql', side_effect=[
                 'Master_Host\tSlave_SQL_Running\tLast_SQL_Error\n10.81.0.11\tYes\t\n', '']) as sql, \
             patch.object(agent, 'persist_role') as role:
            with self.assertRaisesRegex(agent.Refusal, 'diverged'):
                agent.promote(self.cfg, self.request, self.state)
            self.assertEqual([call.args[0] for call in sql.call_args_list], ['SHOW ALL SLAVES STATUS', 'STOP SLAVE;'])
            role.assert_not_called()

    def test_reached_wait_result_is_not_enough_if_target_has_privileged_local_writes(self):
        with patch.object(agent, 'application_fenced', return_value=True), \
             patch.object(agent, 'db', return_value={**self.database, 'gtidCurrent': '0-30150-101'}), \
             patch.object(agent, 'sql', side_effect=[
                 'Master_Host\tSlave_IO_Running\tSlave_SQL_Running\tLast_IO_Error\tLast_SQL_Error\n10.81.0.11\tYes\tYes\t\t\n',
                 'reached\n0\n']):
            with self.assertRaisesRegex(agent.Refusal, 'diverged'):
                agent.catchup(self.cfg, self.request, {})

    def test_boundary_guard_is_symmetric_for_return_to_production(self):
        database = {**self.database, 'serverId': 8111, 'gtidCurrent': '0-30150-110', 'gtidSlave': '0-30150-110'}
        with patch.object(agent, 'db', return_value=database):
            agent.verify_target_boundary(self.source, '0-30150-110')

    def test_controller_clock_block_before_promote_still_requires_exact_recovery_boundary(self):
        state = {**self.state, 'steps': {'backup': 'complete', 'catchup': 'complete'}}
        def sql(statement):
            if statement == 'SHOW ALL SLAVES STATUS':
                return 'Master_Host\tSlave_SQL_Running\tLast_SQL_Error\n10.81.0.11\tYes\t\n'
            if statement == 'SELECT @@replicate_wild_ignore_table':
                return 'filters\n' + ','.join('convoxcces_global.' + name for name in agent.TABLES)
            if statement.startswith('SELECT COUNT(*)'):
                return 'count\n1\n'
            self.fail('Unexpected SQL: ' + statement)
        with patch.object(agent, 'application_fenced', return_value=True), patch.object(agent, 'require_clock'), \
             patch.object(agent, 'db', return_value=self.database), patch.object(agent, 'sql', side_effect=sql), \
             patch.object(agent, 'services_from_config'), patch.object(agent, 'wrapper_environment'), \
             patch.object(agent, 'command', return_value=''):
            self.assertTrue(agent.recover_check(self.cfg, self.request, state)['ready'])
            state['caughtUp'] = '0-8111-99'
            with self.assertRaisesRegex(agent.Refusal, 'diverged'):
                agent.recover_check(self.cfg, self.request, state)

    def test_clock_endpoint_does_not_require_a_running_database_or_change_reserved_state(self):
        request = {**self.request, 'operation': 'clock-check'}
        request.pop('jobId')
        with patch.object(agent, 'clock_evidence', return_value={'mode': 'uat-relative', 'epochMs': 123}) as clock, \
             patch.object(agent, 'db') as db, patch.object(agent, 'atomic_json') as save:
            self.assertEqual(agent.dispatch(self.cfg, request)['clock']['epochMs'], 123)
            clock.assert_called_once(); db.assert_not_called(); save.assert_not_called()

    def test_service_stop_allows_managed_runtime_45_second_grace(self):
        source = pathlib.Path(agent.__file__).read_text()
        self.assertIn("command(['/usr/bin/systemctl', 'stop', name], timeout=60)", source)

    def test_import_prefix_and_gzip_are_streamed_to_a_synthetic_local_client(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(agent, 'ROOT', pathlib.Path(directory)), \
             patch.object(agent, 'ENV', dict(os.environ)):
            path = pathlib.Path(directory) / 'fixture.sql.gz'
            with agent.gzip.open(path, 'wb') as stream:
                stream.write(b'SELECT 1;\n')
            expected = agent.LOCAL_TABLE_IMPORT_PREFIX + b'SELECT 1;\n'
            client = [sys.executable, '-c', 'import sys; sys.exit(0 if sys.stdin.buffer.read() == ' + repr(expected) + ' else 3)']
            with patch.object(agent, 'MYSQL', client), patch.object(agent, 'private_log') as log:
                agent.import_sql_stream(path, agent.LOCAL_TABLE_IMPORT_PREFIX)
                log.assert_not_called()

    def test_early_import_failure_retains_private_diagnostic_and_does_not_deadlock_on_stderr(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(agent, 'ROOT', pathlib.Path(directory)), \
             patch.object(agent, 'ENV', dict(os.environ)):
            path = pathlib.Path(directory) / 'fixture.sql'
            path.write_bytes(b'x' * 500000)
            client = [sys.executable, '-c', 'import sys; sys.stderr.write("X"*100000+" TEST MYSQL ERROR"); sys.exit(2)']
            with patch.object(agent, 'MYSQL', client), patch.object(agent, 'private_log') as log:
                with self.assertRaisesRegex(agent.Refusal, 'Database restore failed'):
                    agent.import_sql_stream(path)
                self.assertEqual(log.call_args.args[0]['code'], 2)
                self.assertIn('TEST MYSQL ERROR', log.call_args.args[0]['stderr'])
                self.assertLessEqual(len(log.call_args.args[0]['stderr']), 4096)

    def test_import_deadline_includes_blocked_pipe_writes(self):
        timer = agent.threading.Timer
        with tempfile.TemporaryDirectory() as directory, patch.object(agent, 'ROOT', pathlib.Path(directory)), \
             patch.object(agent, 'ENV', dict(os.environ)):
            path = pathlib.Path(directory) / 'fixture.sql'
            path.write_bytes(b'x' * 500000)
            client = [sys.executable, '-c', 'import time; time.sleep(20)']
            with patch.object(agent, 'MYSQL', client), patch.object(agent, 'private_log') as log, \
                 patch.object(agent.threading, 'Timer', side_effect=lambda seconds, callback: timer(0.2, callback)):
                started = time.monotonic()
                with self.assertRaisesRegex(agent.Refusal, 'Database restore failed'):
                    agent.import_sql_stream(path)
                self.assertLess(time.monotonic() - started, 5)
                self.assertTrue(log.call_args.args[0]['timedOut'])


if __name__ == '__main__':
    unittest.main()
