# Continuous file synchronization — release 0.6.0

This upgrade extends the working 0.5 installation. Archival remains at
https://10.3.0.151. Production is 10.81.0.11/server ID 8111; DR is
10.3.0.150/server ID 30150. Existing TLS, authentication, SSH pins, database
roles, replication configuration, local IPs and startup settings are preserved.

## Install once from archival

Finish any pending routing validation or reconciliation in the console first.
The rollout refuses reserved jobs and active managed senders. Both existing
legacy `lsyncd.service` units must already be stopped and persistently masked,
as they are after the 0.5 cutover cycle. Keep other operators out during upgrade.

From Windows PowerShell:

```powershell
cd C:\Users\DEEPIJA\Documents\ConVoxCCS\dr-console
scp .\artifacts\convox-dr-console-control-0.6.0.zip .\artifacts\convox-dr-console-control-0.6.0.zip.sha256 root@10.3.0.151:/root/
```

On archival as root:

```bash
(
    set -e
    umask 077
    cd /root
    sha256sum -c convox-dr-console-control-0.6.0.zip.sha256
    test ! -L /root/convox-console-control-0.6.0
    install -d -m 0700 /root/convox-console-control-0.6.0
    unzip -o convox-dr-console-control-0.6.0.zip -d /root/convox-console-control-0.6.0
    bash /root/convox-console-control-0.6.0/deploy/rollout-filesync-rhel.sh --uat
)
```

The rollout verifies the package manifest and existing installation, provisions
Lsyncd from the host's already-approved DNF repositories only if missing, installs
both agents and the new masked service, and upgrades archival. Root SSH password
prompts are normal if administrator keys are not configured. No repository is
added. If a dependency cannot be installed, resolve that error before proceeding.

Only the archival console restarts during deployment; its website can briefly
show 502 during that restart. The managed servers' databases and application
services continue. The installer backs up replaced agent code and any existing
file-sync unit under `/root/convox-filesync-upgrade.*`. The legacy
`/etc/lsyncd.conf` is not edited. Nginx site configuration is not edited.

`--uat` explicitly renews the existing four-hour relative-clock approval on all
three hosts. Clocks must agree within five seconds. It does not set clocks.
For normal NTP operation, disable the UAT exception and omit `--uat`.

## Enable now, without another database restore

Since Prepare DR already completed on 0.5:

1. Hard-refresh the console with Ctrl+F5, sign in and Refresh status.
2. Confirm production is the sole writable primary and DR is its healthy
   read-only replica with the application fenced.
3. In **Continuous file sync**, click **Start file sync** and enter
   `START FILE SYNC`.
4. Wait for the job to complete. Production should show `watching` or `pending`,
   with direction Production → Disaster recovery and a verified transfer-probe
   time. DR's sender should show `stopped`; its application remains fenced.

This action reserves both servers, checks identity, roles, clocks and receiver
directory access, stops/masks both managed senders, obtains signed receiver
approval, starts the primary sender and verifies a copied probe before releasing
reservations. It does not restore databases, switch roles, restart application
services or change routing. It is also available in the opposite direction while
DR is primary and production is a prepared read-only standby.

## Future Prepare and cutover operations

Prepare DR and Prepare production retain their database backup, restore,
replication and baseline-copy sequence. They now stop both senders before
preparation and add receiver approval plus sender startup after replica
verification. A successful Prepare automatically leaves continuous copying
running from the active primary to the prepared standby.

The cutover quiesce stage stops and persistently masks the sender before final
GTID capture and the checksum-verified final file copy. Promotion still requires
the old source database/application fence and exact target GTID. After cutover,
the old peer is fenced; its next Prepare action establishes the reverse direction.
There is never an automatic simultaneous reverse sender. Team routing/call
validation remains required before preparing the old primary.

The file receiver runs as `convoxsync` using its existing directory ACLs. A
verified rsync receive process for that account and one of the eight fixed roots
does not count as a ConVox application writer. Other vendor processes, senders,
unmanaged Lsyncd and application services retain the existing fencing checks.

## What is copied and how status is measured

The same eight roots are used: calls, ConVoxCCS, `/var/www/asterisk`, AGI, music on
hold, Perl scripts, sounds and `/etc/asterisk`. Database files, `/etc/nginx`,
`/var/www/convox4.conf` and `/var/www/convoxwebpanel.conf` are outside this set.
The four licence/notifications/server/web-server tables remain isolated through
the existing MariaDB filters; file copying does not alter them.

The dedicated `convox-console-filesync.service` runs Lsyncd with a generated
root-private configuration. It uses strict pinned SSH, checksums, delayed updates
and no destination deletions or ownership/permission changes. Source deletes and
renames can leave older destination files, as with the existing no-delete policy.
The service uses lower CPU/I/O priority to reduce contention with calls.

Each sender periodically changes a fixed-size hidden diagnostic file:
`/var/www/html/calls/.convox-console-sync-check`. It reads the destination copy
over the pinned SSH connection, verifies its current token, and records the
source-side verification time. The probe is not a recording and contains no
credentials. Its same-size changes also exercise checksum-based copying.

The UI reports sender direction, watcher state, queued event count and the last
verified probe separately from database replication. `watching` means a live
watcher, fresh status and a recent successful probe; `pending` additionally means
queued events. These are observations, not proof that every file is current.
Stale heartbeat/status, missing probes or a failed service are shown as
`unverified`/`error`, rather than inferred healthy from an active service alone.

The service checks the source database role and approved primary marker repeatedly.
It terminates its Lsyncd child if the source is no longer primary. At reboot, an
enabled sender can restart only with its original primary approval, valid fixed
configuration and writable source. A standby's sender remains persistently masked.

## Supervised acceptance check

Create a new test recording on production and verify it reaches DR. Change a
harmless test text file to different content of the same byte length and verify
the changed content arrives too. Delete only that test file when finished;
the destination copy is retained by the no-delete policy.

Repeat the full UI drill: preflight → Bring DR online → route/test/confirm →
Prepare production → verify DR → production file copying → preflight → Cut over
to production → route/test/confirm → Prepare DR → verify production → DR copying.
Check database replication, local tables and each host's environment files as in
the existing drill. No manual unmasking of the standby application is needed.

Local automated tests use mocked OS/SSH/database/Lsyncd operations and exercise
both directions and two full controller cycles. The first UI start includes an
actual transfer probe on your servers; verify real recordings during UAT too.
Release checks passed: 100 Node tests, 91 Python tests, source syntax checks and
Bash syntax validation for all 13 deployment scripts.
Open recordings can be copied before writing finishes. This is asynchronous
copying and does not establish zero data loss or unplanned-outage readiness.

## Diagnostics and recovery

Refresh the console to get a new file observation. Root-private logs/status on
the sender are `/var/lib/convox-console-agent/file-sync.log`,
`file-sync-service.log`, `file-sync.status` and `file-sync-heartbeat.json`.
Inspect the unit with `systemctl status convox-console-filesync.service` and
`journalctl -u convox-console-filesync.service`. Do not unmask legacy Lsyncd.

Failed startup stops/masks only the managed sender; the primary database and
application continue. Keep the UI error, inspect the cause, reconcile the failed
job through the normal guarded UI action, then use Start file sync again. A stale
or failed final observation keeps reservations and does not report completion.

To stop copying for inspection, on the current primary as root:

```bash
systemctl mask --now convox-console-filesync.service
```

This affects the file sender only. Restart it through Start file sync after
checking the replica and receiver ACLs. Do not manually enable the sender on both
servers. To roll back code, preserve the installer backup and restore the prior
three-host version only when no job is reserved; retain the new sender masks.

Configuration behavior follows the upstream [Lsyncd configuration documentation](https://lsyncd.github.io/lsyncd/manual/config/layer4/).
