#!/usr/bin/env bash
# Code/service installation only; enable copying separately through the console.
set -Eeuo pipefail
umask 077
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
[[ $EUID == 0 && $# == 1 ]] || fail 'Usage as root: install-filesync-rhel.sh production|dr'
NODE="$1"
[[ "$NODE" == production || "$NODE" == dr ]] || fail 'Unknown node.'
SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
for FILE in convox-console-control.py convox-console-filesync.service; do
    [[ -f "$SOURCE_DIR/$FILE" ]] || fail "Missing $FILE in complete release."
done
[[ -x /usr/bin/lsyncd && -x /usr/bin/rsync ]] || fail 'Install lsyncd and rsync from approved RHEL repositories first.'
[[ -x /usr/local/libexec/convox-console-control && -f /etc/convox-console-agent/control.json ]] || fail 'Existing 0.5 control installation is required.'
python3 -m py_compile "$SOURCE_DIR/convox-console-control.py"
exec 9>/var/lock/convox-console-filesync-install.lock
flock -n 9 || fail 'Another file-sync installation is running.'
exec 8>>/var/lib/convox-console-agent/agent.lock
flock -n 8 || fail 'Agent is currently running.'
[[ ! -e /var/lib/convox-console-agent/operation.json ]] || fail 'Finish or reconcile the reserved job before upgrading.'
python3 - "$NODE" <<'PY'
import json, pathlib, sys
cfg = json.loads(pathlib.Path('/etc/convox-console-agent/control.json').read_text())
if cfg.get('host') != sys.argv[1] or cfg.get('adminReviewedStartup') is not True:
    raise SystemExit('Wrong host or startup review is missing')
PY
UNIT=convox-console-filesync.service
[[ "$(systemctl is-active "$UNIT" || true)" != active ]] || fail 'Managed file sender is active; use its stop/reconciliation workflow before upgrading.'
[[ ! -e "/etc/systemd/system/$UNIT" || "$(readlink "/etc/systemd/system/$UNIT" || true)" == /dev/null ]] || fail 'Custom file-sync unit override exists; inspect first.'
BACKUP_DIR="$(mktemp -d /root/convox-filesync-upgrade.XXXXXX)"
cp -p /usr/local/libexec/convox-console-control "$BACKUP_DIR/convox-console-control"
if [[ -f "/usr/lib/systemd/system/$UNIT" ]]; then cp -p "/usr/lib/systemd/system/$UNIT" "$BACKUP_DIR/$UNIT"; fi
install -o root -g root -m 0755 "$SOURCE_DIR/convox-console-control.py" /usr/local/libexec/convox-console-control
install -o root -g root -m 0644 "$SOURCE_DIR/$UNIT" "/usr/lib/systemd/system/$UNIT"
systemctl mask "$UNIT"
systemctl daemon-reload
restorecon /usr/local/libexec/convox-console-control "/usr/lib/systemd/system/$UNIT"
printf '0.6 file-sync agent installed on %s. Sender remains masked. Backup: %s\n' "$NODE" "$BACKUP_DIR"
printf 'Database roles, replication, application services and legacy /etc/lsyncd.conf were preserved.\n'
