#!/usr/bin/env bash
# Deploy continuous file sync on all three existing hosts. Enable through the UI.
set -Eeuo pipefail
umask 077
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
[[ $EUID == 0 && $# -le 1 ]] || fail 'Usage on archival as root: rollout-filesync-rhel.sh [--uat]'
UAT="${1:-}"
[[ -z "$UAT" || "$UAT" == --uat ]] || fail 'Only --uat is supported.'
SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
cd "$SOURCE_DIR"
for CMD in python3 ssh scp sha256sum flock systemctl; do command -v "$CMD" >/dev/null || fail "Missing: $CMD"; done
[[ -f SHA256SUMS ]] || fail 'Extract the complete 0.6.0 ZIP first.'
sha256sum --quiet -c SHA256SUMS
exec 9>/var/lock/convox-console-cycle-rollout.lock
flock -n 9 || fail 'Another rollout is running.'
python3 - <<'PY'
import json, pathlib, shlex, subprocess
if json.loads(pathlib.Path('package.json').read_text()).get('version') != '0.6.0':
    raise SystemExit('Expected release 0.6.0')
addresses = subprocess.check_output(['/usr/sbin/ip', '-4', '-o', 'address', 'show'], text=True)
if not any(word.startswith('10.3.0.151/') for word in addresses.split()):
    raise SystemExit('Run on archival 10.3.0.151')
env = {}
for line in pathlib.Path('/etc/convox-console/console.env').read_text().splitlines():
    if line.strip() and not line.lstrip().startswith('#') and '=' in line:
        key, value = line.split('=', 1)
        values = shlex.split(value)
        if len(values) == 1: env[key.strip()] = values[0]
if env.get('CONVOX_MODE') != 'control': raise SystemExit('Existing control-mode installation is required')
directory = pathlib.Path(env.get('CONVOX_DATA_DIR', '/opt/convox-dr-console/data/control'))
if not directory.is_absolute(): directory = pathlib.Path('/opt/convox-dr-console') / directory
state = json.loads((directory / 'state.json').read_text())
if state.get('reconcileRequired') or any(j.get('state') in ['running', 'awaiting-validation'] for j in state.get('jobs', [])):
    raise SystemExit('Finish validation or reconcile before upgrading')
PY
SSH=(-o StrictHostKeyChecking=yes -o UserKnownHostsFile=/etc/convox-console/ssh/known_hosts -o ConnectTimeout=10 -o ClearAllForwardings=yes)
systemctl is-active --quiet convox-dr-console.service || fail 'Existing archival console must be running.'
trap 'systemctl start convox-dr-console.service || true' EXIT
systemctl stop convox-dr-console.service
for ENTRY in production:10.81.0.11 dr:10.3.0.150; do
    NODE="${ENTRY%%:*}"
    ADDRESS="${ENTRY#*:}"
    printf 'Checking %s before installing either agent...\n' "$NODE"
    ssh -T "${SSH[@]}" "root@$ADDRESS" python3 - "$NODE" <<'PY'
import json, os, pathlib, subprocess, sys
cfg = json.loads(pathlib.Path('/etc/convox-console-agent/control.json').read_text())
if cfg.get('host') != sys.argv[1] or cfg.get('adminReviewedStartup') is not True:
    raise SystemExit('Wrong host or startup review is missing')
if pathlib.Path('/var/lib/convox-console-agent/operation.json').exists():
    raise SystemExit('Reserved operation exists; finish or reconcile before upgrading')
legacy = subprocess.check_output(['/usr/bin/systemctl', 'show', 'lsyncd.service', '-p', 'ActiveState', '-p', 'UnitFileState'], text=True)
mask = '/etc/systemd/system/lsyncd.service'
if not os.path.islink(mask) or os.readlink(mask) != '/dev/null' or 'UnitFileState=masked' not in legacy or not any(value in legacy for value in ['ActiveState=inactive', 'ActiveState=failed']):
    raise SystemExit('Legacy Lsyncd must already be stopped/masked; inspect existing file syncing before this upgrade')
managed = subprocess.run(['/usr/bin/systemctl', 'show', 'convox-console-filesync.service', '-p', 'ActiveState'], text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout
if any(value in managed for value in ['ActiveState=active', 'ActiveState=activating', 'ActiveState=deactivating']):
    raise SystemExit('A managed sender is active; this upgrade is for the first 0.6 deployment')
PY
    # Install only from the host's already-approved repositories if needed.
    ssh -T "${SSH[@]}" "root@$ADDRESS" 'if [[ ! -x /usr/bin/lsyncd ]]; then dnf -y install lsyncd; fi; test -x /usr/bin/lsyncd && test -x /usr/bin/rsync'
done
for ENTRY in production:10.81.0.11 dr:10.3.0.150; do
    NODE="${ENTRY%%:*}"
    ADDRESS="${ENTRY#*:}"
    ssh -T "${SSH[@]}" "root@$ADDRESS" 'test ! -L /root/convox-console-0.6.0-agent && install -d -o root -g root -m 0700 /root/convox-console-0.6.0-agent'
    scp "${SSH[@]}" deploy/convox-console-control.py deploy/convox-console-filesync.service deploy/install-filesync-rhel.sh deploy/configure-uat-clock-skew-rhel.sh "root@$ADDRESS:/root/convox-console-0.6.0-agent/"
    ssh -T "${SSH[@]}" "root@$ADDRESS" "bash /root/convox-console-0.6.0-agent/install-filesync-rhel.sh $NODE"
    if [[ "$UAT" == --uat ]]; then ssh -T "${SSH[@]}" "root@$ADDRESS" 'bash /root/convox-console-0.6.0-agent/configure-uat-clock-skew-rhel.sh agent enable'; fi
done
bash deploy/upgrade-rhel.sh
if [[ "$UAT" == --uat ]]; then bash deploy/configure-uat-clock-skew-rhel.sh controller enable; fi
for ENTRY in production:10.81.0.11 dr:10.3.0.150; do
    NODE="${ENTRY%%:*}"
    ADDRESS="${ENTRY#*:}"
    printf '{"version":1,"host":"%s","operation":"status"}\n' "$NODE" |
      sudo -u convoxconsole ssh -T -F /dev/null "${SSH[@]}" -o BatchMode=yes -o IdentitiesOnly=yes -o IdentityAgent=none \
      -i /etc/convox-console/ssh/control_ed25519 "convoxcontrol@$ADDRESS" convox-control-v1 |
      python3 -c 'import json,sys; r=json.load(sys.stdin); c=r.get("control",{}); assert r.get("ok") is True and c.get("agentVersion")=="0.6.0" and c.get("fileSyncVersion")==1 and c.get("prepareVersion")==2 and c.get("cutoverVersion")==2; print("Verified 0.6.0 agent; managed sender=" + str(r.get("fileSync",{}).get("state")))'
done
printf '0.6.0 installed on all three hosts. Hard-refresh https://10.3.0.151.\n'
printf 'For your already-prepared DR: Start file sync, then START FILE SYNC. No database rebuild is needed.\n'
printf 'New Prepare actions will start the correct file sender automatically.\n'
