"""Pure/mocked agent tests: never execute systemctl, mysql, SSH or file copies."""
import importlib.util
import pathlib
import unittest
import tempfile
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('agent', pathlib.Path(__file__).parents[1] / 'deploy' / 'convox-console-control.py')
# fcntl does not exist on Windows; provide a test-only import stub.
import sys
from types import SimpleNamespace
if sys.platform == 'win32':
    sys.modules.setdefault('fcntl', SimpleNamespace())
agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent)


class AgentTests(unittest.TestCase):
    def setUp(self):
        self.cfg = {'host': 'production', 'clusterSecret': 'ab' * 32}
        self.request = {'version': 1, 'host': 'production', 'source': 'production', 'target': 'dr',
                        'operation': 'fence', 'jobId': '12345678-1234-1234-1234-123456789abc'}

    def test_unknown_commands_and_arbitrary_host_are_rejected(self):
        for changes in [{'operation': 'shell'}, {'host': 'other'}, {'target': 'production'}, {'jobId': '../escape'}]:
            with self.assertRaises(agent.Refusal):
                agent.valid_request({**self.request, **changes}, 'production')

    def test_every_hyphenated_rejoin_operation_dispatches_to_its_explicit_function(self):
        operations = {
            'rejoin-open': 'rejoin_open',
            'rejoin-seed': 'rejoin_seed',
            'rejoin-restore': 'rejoin_restore',
            'rejoin-replicate': 'rejoin_replicate',
            'rejoin-files': 'rejoin_files',
            'rejoin-verify': 'rejoin_verify',
        }
        cfg = {**self.cfg, 'adminReviewedStartup': True}
        for operation, function in operations.items():
            request = {**self.request, 'operation': operation}
            state = {'jobId': request['jobId'], 'source': request['source'], 'target': request['target'],
                     'preflightPassed': True, 'steps': {}}
            with self.subTest(operation=operation), tempfile.TemporaryDirectory() as directory, \
                 patch.object(agent, 'ROOT', pathlib.Path(directory)), \
                 patch.object(agent, function, return_value={'ok': True}) as handler:
                agent.atomic_json(agent.ROOT / 'operation.json', state)
                self.assertTrue(agent.dispatch(cfg, request)['ok'])
                handler.assert_called_once()

    def test_local_table_restore_explicitly_selects_the_global_database(self):
        self.assertEqual(
            agent.LOCAL_TABLE_IMPORT_PREFIX,
            b'SET SESSION sql_log_bin=0;\nUSE `convoxcces_global`;\n'
        )

    def test_worker_definitions_accept_real_convox_arrows_and_plain_equals(self):
        for separator in [' => ', '=', '=>']:
            config = '\n'.join([
                '[SERVICE_convox-listen]',
                'service_name' + separator + 'convox_manager_listen.pl',
                'service_path' + separator + '/var/www/convox_perl',
                'service_active' + separator + 'Y',
                'service_screen' + separator + 'convox-listen',
                'service_add_to_screen' + separator + 'Y # enabled',
                '[SERVICE_disabled]',
                'service_name' + separator + 'disabled.pl',
                'service_path' + separator + '/var/www/convox_perl',
                'service_active' + separator + 'N',
                'service_add_to_screen' + separator + 'Y',
            ])
            with self.subTest(separator=separator), \
                 patch.object(agent.pathlib.Path, 'read_text', return_value=config), \
                 patch.object(agent.pathlib.Path, 'is_file', return_value=True), \
                 patch.object(agent.os, 'access', return_value=True):
                self.assertEqual(agent.services_from_config(), [pathlib.Path('/var/www/convox_perl/convox_manager_listen.pl')])

    def test_arrow_toggles_disable_optional_workers_and_unrelated_sections_do_not_enable_workers(self):
        config = '''enable_whatsapp => N
[SERVICE_disabled]
service_name => disabled.pl
service_path => /var/www/convox_perl
service_active => N
service_add_to_screen => Y
[UNRELATED]
service_active => Y
[SERVICE_whatsapp]
service_name => whatsapp.pl
service_path => /var/www/convox_perl
service_screen => convox_whatsapp_user_apis
service_active => Y
service_add_to_screen => Y
'''
        with patch.object(agent.pathlib.Path, 'read_text', return_value=config), self.assertRaises(agent.Refusal):
            agent.services_from_config()

    def test_arrow_worker_still_requires_an_executable_service_file(self):
        config = '''[SERVICE_convox-listen]
service_name => convox_manager_listen.pl
service_path => /var/www/convox_perl
service_active => Y
service_add_to_screen => Y
'''
        with patch.object(agent.pathlib.Path, 'read_text', return_value=config), \
             patch.object(agent.pathlib.Path, 'is_file', return_value=True), \
             patch.object(agent.os, 'access', return_value=False), self.assertRaises(agent.Refusal):
            agent.services_from_config()

    def test_receipts_require_matching_job_kind_source_and_signature(self):
        receipt = agent.sign_receipt(self.cfg, self.request, 'fence', gtid='0-8111-100')
        agent.verify_receipt(self.cfg, self.request, receipt, 'fence')
        for field, value in [('gtid', '0-8111-99'), ('jobId', 'different'), ('host', 'dr')]:
            changed = {'payload': {**receipt['payload'], field: value}, 'signature': receipt['signature']}
            with self.assertRaises(agent.Refusal):
                agent.verify_receipt(self.cfg, self.request, changed, 'fence')
        with self.assertRaises(agent.Refusal):
            agent.verify_receipt(self.cfg, self.request, receipt, 'files')

    def test_stale_fencing_evidence_and_future_clock_are_rejected(self):
        with patch.object(agent.time, 'time', return_value=100):
            receipt = agent.sign_receipt(self.cfg, self.request, 'fence', gtid='0-8111-100')
        for now in [99, 131]:
            with patch.object(agent.time, 'time', return_value=now), self.assertRaises(agent.Refusal):
                agent.verify_receipt(self.cfg, self.request, receipt, 'fence')

    def test_uat_receipts_accept_only_the_preflight_five_second_future_skew(self):
        cfg = {**self.cfg, 'uatClockSkewMode': True, 'uatClockSkewExpires': 200}
        request = {**self.request, 'uatClockSkewMode': True}
        with patch.object(agent.time, 'time', return_value=100):
            receipt = agent.sign_receipt(cfg, request, 'fence', gtid='0-8111-100')
        with patch.object(agent.time, 'time', return_value=96):
            self.assertEqual(agent.verify_receipt(cfg, request, receipt, 'fence')['gtid'], '0-8111-100')
        with patch.object(agent.time, 'time', return_value=94), self.assertRaises(agent.Refusal):
            agent.verify_receipt(cfg, request, receipt, 'fence')
        with patch.object(agent.time, 'time', return_value=201), self.assertRaises(agent.Refusal):
            agent.verify_receipt(cfg, request, receipt, 'fence')

    def test_zombies_are_not_live_writers_but_web_and_vendor_processes_are(self):
        processes = [{'pid': 1, 'state': 'Z', 'name': 'asterisk'}, {'pid': 2, 'state': 'S', 'name': 'safe_asterisk'},
                     {'pid': 3, 'state': 'S', 'name': 'nginx'}, {'pid': 4, 'state': 'S', 'name': 'python3', 'vendor': True},
                     {'pid': 5, 'state': 'S', 'name': 'sshd'}]
        with patch.object(agent, 'processes', return_value=processes):
            self.assertEqual([p['pid'] for p in agent.writers()], [2, 3, 4])

    def test_processes_that_exit_during_proc_inspection_are_ignored(self):
        with patch.object(agent, 'command', return_value='100 1 S worker\n'), \
             patch.object(agent.pathlib.Path, 'read_bytes', side_effect=ProcessLookupError()):
            self.assertEqual(agent.processes(), [])
        argv = b'/usr/bin/sudo\0-n\0/usr/local/libexec/convox-console-control\0'
        with patch.object(agent, 'command', return_value='99 1 S sudo\n'), \
             patch.object(agent.pathlib.Path, 'read_bytes', return_value=argv), \
             patch.object(agent.os, 'readlink', side_effect=ProcessLookupError()):
            self.assertEqual(agent.processes(), [])

    def test_shebang_agent_excludes_only_itself_not_real_workers_or_another_runtime(self):
        processes = [
            {'pid': 100, 'parent': 99, 'state': 'S', 'name': 'convox-console-'},
            {'pid': 101, 'parent': 1, 'state': 'S', 'name': 'convox-console-'},
            {'pid': 102, 'parent': 1, 'state': 'S', 'name': 'convox_progress'},
            {'pid': 103, 'parent': 1, 'state': 'S', 'name': 'perl', 'vendor': True},
        ]
        with patch.object(agent.os, 'getpid', return_value=100), patch.object(agent, 'processes', return_value=processes):
            self.assertEqual([p['pid'] for p in agent.writers()], [101, 102, 103])
        with patch.object(agent.os, 'getpid', return_value=100), patch.object(agent, 'processes', return_value=processes[:1]), \
             patch.object(agent.os.path, 'islink', return_value=True), patch.object(agent.os, 'readlink', return_value='/dev/null'), \
             patch.object(agent, 'unit', return_value={'active': 'inactive'}):
            self.assertTrue(agent.application_fenced())

    def test_unfenced_source_never_gets_a_fence_receipt(self):
        state = {'boundary': '0-8111-100', 'filesVerified': '0-8111-100'}
        with patch.object(agent, 'database_fenced', return_value=False), patch.object(agent, 'application_fenced', return_value=False), patch.object(agent, 'command') as cmd:
            with self.assertRaises(agent.Refusal):
                agent.fence(self.cfg, self.request, state)
            cmd.assert_not_called()

    def test_ssh_sudo_inventory_ignores_only_verified_own_ancestors(self):
        ps = '100 99 S convox-console-\n99 98 S sudo\n98 90 S sudo\n90 1 S sshd\n'
        argv = {
            100: b'/usr/bin/python3\0/usr/local/libexec/convox-console-control\0',
            99: b'/usr/bin/sudo\0-n\0/usr/local/libexec/convox-console-control\0',
            98: b'/usr/bin/sudo\0-n\0/usr/local/libexec/convox-console-control\0',
            90: b'sshd\0',
        }
        def read_bytes(path):
            return argv[int(path.parent.name)]
        with patch.object(agent.os, 'getpid', return_value=100), \
             patch.object(agent, 'command', return_value=ps), \
             patch.object(agent.pathlib.Path, 'read_bytes', read_bytes), \
             patch.object(agent.os, 'readlink', return_value='/usr/bin/sudo'):
            self.assertEqual(agent.writers(), [])
            inventory = agent.processes()
            self.assertTrue(next(p for p in inventory if p['pid'] == 99)['controlSudo'])

    def test_separate_agents_and_sudo_launchers_and_actual_workers_remain_writers(self):
        inventory = [
            {'pid': 100, 'parent': 99, 'state': 'S', 'name': 'convox-console-', 'controlAgent': True},
            {'pid': 99, 'parent': 90, 'state': 'S', 'name': 'sudo', 'controlAgent': True, 'controlSudo': True},
            {'pid': 90, 'parent': 1, 'state': 'S', 'name': 'sshd'},
            {'pid': 101, 'parent': 1, 'state': 'S', 'name': 'sudo', 'controlAgent': True, 'controlSudo': True},
            {'pid': 102, 'parent': 101, 'state': 'S', 'name': 'python3', 'controlAgent': True},
            {'pid': 103, 'parent': 1, 'state': 'S', 'name': 'python3', 'controlAgent': True},
            {'pid': 104, 'parent': 99, 'state': 'S', 'name': 'convox_progress'},
            {'pid': 105, 'parent': 1, 'state': 'S', 'name': 'perl', 'vendor': True},
        ]
        with patch.object(agent.os, 'getpid', return_value=100), patch.object(agent, 'processes', return_value=inventory):
            self.assertEqual([p['pid'] for p in agent.writers()], [101, 102, 103, 104, 105])

    def test_unverified_sudo_executable_or_vendor_ancestor_is_never_ignored(self):
        for metadata in [{'controlSudo': False}, {'controlSudo': True, 'vendor': True}]:
            inventory = [
                {'pid': 100, 'parent': 99, 'state': 'S', 'name': 'convox-console-'},
                {'pid': 99, 'parent': 1, 'state': 'S', 'name': 'sudo', 'controlAgent': True, **metadata},
            ]
            with self.subTest(metadata=metadata), patch.object(agent.os, 'getpid', return_value=100), \
                 patch.object(agent, 'processes', return_value=inventory):
                self.assertEqual([p['pid'] for p in agent.writers()], [99])

    def test_sudo_named_binary_must_resolve_to_the_reviewed_system_executable(self):
        argv = b'/usr/bin/sudo\0-n\0/usr/local/libexec/convox-console-control\0'
        with patch.object(agent, 'command', return_value='99 90 S sudo\n'), \
             patch.object(agent.pathlib.Path, 'read_bytes', return_value=argv), \
             patch.object(agent.os, 'readlink', return_value='/tmp/not-sudo'):
            self.assertFalse(agent.processes()[0]['controlSudo'])

    def test_own_sudo_does_not_hide_missing_persistent_masks_or_active_services(self):
        inventory = [
            {'pid': 100, 'parent': 99, 'state': 'S', 'name': 'convox-console-'},
            {'pid': 99, 'parent': 1, 'state': 'S', 'name': 'sudo', 'controlAgent': True, 'controlSudo': True},
        ]
        for link, active in [(False, 'inactive'), (True, 'active'), (True, 'inactive')]:
            with self.subTest(link=link, active=active), patch.object(agent.os, 'getpid', return_value=100), \
                 patch.object(agent, 'processes', return_value=inventory), \
                 patch.object(agent.os.path, 'islink', return_value=link), \
                 patch.object(agent.os, 'readlink', return_value='/dev/null'), \
                 patch.object(agent, 'unit', return_value={'active': active}):
                self.assertEqual(agent.application_fenced(), link and active == 'inactive')

    def test_snapshot_over_ssh_reports_the_real_stopped_source_and_read_only_target(self):
        inventory = [
            {'pid': 100, 'parent': 99, 'state': 'S', 'name': 'convox-console-', 'controlAgent': True},
            {'pid': 99, 'parent': 1, 'state': 'S', 'name': 'sudo', 'controlAgent': True, 'controlSudo': True},
        ]
        target_db = {'serverId': 30150, 'readOnly': True}
        for host in ['production', 'dr']:
            def unit(name):
                return {'name': name, 'load': 'masked', 'active': 'active' if host == 'dr' and name == 'mariadb.service' else 'inactive', 'masked': True}
            with self.subTest(host=host), patch.object(agent.os, 'getpid', return_value=100), \
                 patch.object(agent, 'processes', return_value=inventory), \
                 patch.object(agent.os.path, 'islink', return_value=True), \
                 patch.object(agent.os, 'readlink', return_value='/dev/null'), patch.object(agent, 'unit', side_effect=unit), \
                 patch.object(agent, 'db', side_effect=agent.Refusal('stopped') if host == 'production' else lambda: target_db), \
                 patch.object(agent, 'sql', return_value=''):
                result = agent.snapshot({'host': host, 'startupUnits': ['php-fpm.service', 'nginx.service']})
                self.assertTrue(result['control']['applicationFenced'])
                self.assertEqual(result['control']['databaseFenced'], host == 'production')
                self.assertTrue(result['control']['recoverySupported'])
                self.assertEqual(result['status']['db'], None if host == 'production' else target_db)

    def test_promotion_without_backup_or_target_application_fence_is_refused(self):
        cfg = {**self.cfg, 'host': 'dr'}
        request = {**self.request, 'host': 'dr', 'operation': 'promote'}
        with patch.object(agent, 'sql') as sql:
            with self.assertRaises(agent.Refusal):
                agent.promote(cfg, request, {})
            sql.assert_not_called()

    def test_quiesce_excludes_own_sudo_parent_but_retains_unknown_worker_refusal(self):
        inventory = [
            {'pid': 100, 'parent': 99, 'state': 'S', 'name': 'convox-console-'},
            {'pid': 99, 'parent': 90, 'state': 'S', 'name': 'sudo'},
        ]
        for real_worker in [False, True]:
            with self.subTest(real_worker=real_worker), tempfile.TemporaryDirectory() as directory, \
                 patch.object(agent, 'ROOT', pathlib.Path(directory)), \
                 patch.object(agent.os, 'getpid', return_value=100), \
                 patch.object(agent, 'processes', return_value=inventory + ([
                     {'pid': 101, 'parent': 99, 'state': 'S', 'name': 'convox_progress'}
                 ] if real_worker else [])), \
                 patch.object(agent, 'writers', return_value=[]), \
                 patch.object(agent, 'mask_units'), patch.object(agent, 'unit', return_value={'active': 'inactive'}), \
                 patch.object(agent, 'terminate_named'), patch.object(agent.time, 'sleep'), \
                 patch.object(agent, 'application_fenced', return_value=True), \
                 patch.object(agent, 'persist_role') as persist, patch.object(agent, 'command') as command:
                state = {'backup': 'fixture', 'steps': {'backup': 'complete'}}
                if real_worker:
                    with self.assertRaisesRegex(agent.Refusal, 'unmanaged ConVox writer'):
                        agent.quiesce(self.cfg, self.request, state)
                    persist.assert_not_called()
                else:
                    self.assertTrue(agent.quiesce(self.cfg, self.request, state)['ok'])
                    persist.assert_called_once_with(True)
                    self.assertTrue(state['quiesced'])
                command.assert_called_once_with(['/usr/bin/systemctl', 'stop', agent.SYNC_UNIT], timeout=60)

    def test_promotion_requires_three_agreeing_signed_receipts(self):
        cfg = {**self.cfg, 'host': 'dr'}
        request = {**self.request, 'host': 'dr', 'operation': 'promote'}
        for kind in ['boundary', 'files', 'fence']:
            request[kind] = agent.sign_receipt(self.cfg, self.request, kind, gtid='0-8111-' + ('99' if kind == 'files' else '100'))
        with patch.object(agent, 'application_fenced', return_value=True), patch.object(agent, 'sql') as sql:
            with self.assertRaises(agent.Refusal):
                agent.promote(cfg, request, {'backup': 'fixture', 'steps': {'backup': 'complete'}, 'caughtUp': '0-8111-100'})
            sql.assert_not_called()

    def test_effective_persistent_role_honors_last_option_and_skip_override(self):
        self.assertTrue(agent.effective_read_only('--read_only=OFF\n--read-only=ON\n'))
        self.assertFalse(agent.effective_read_only('--read-only=ON\n--skip-read-only\n'))
        self.assertIsNone(agent.effective_read_only('--some-other-option=1\n'))

    def test_known_rhel_mysql_alias_is_preserved_and_masked_with_scoped_force(self):
        links = {'/etc/systemd/system/mysql.service': '/usr/lib/systemd/system/mariadb.service'}
        def mask(names):
            for name in names:
                links['/etc/systemd/system/' + name] = '/dev/null'
        def command(args):
            if args == ['/usr/bin/systemctl', 'mask', '--force', 'mysql.service']:
                links['/etc/systemd/system/mysql.service'] = '/dev/null'
            return ''
        with tempfile.TemporaryDirectory() as directory, \
             patch.object(agent.os.path, 'lexists', side_effect=lambda path: path in links), \
             patch.object(agent.os.path, 'islink', side_effect=lambda path: path in links), \
             patch.object(agent.os, 'readlink', side_effect=lambda path: links[path]), \
             patch.object(agent, 'mask_units', side_effect=mask), \
             patch.object(agent, 'command', side_effect=command) as cmd:
            agent.mask_database_units({'backup': directory})
            cmd.assert_any_call(['/usr/bin/systemctl', 'mask', '--force', 'mysql.service'])
            saved = agent.json.loads((pathlib.Path(directory) / 'mysql-service-alias.before.json').read_text())
            self.assertEqual(saved['target'], '/usr/lib/systemd/system/mariadb.service')
            self.assertEqual(set(links.values()), {'/dev/null'})

    def test_custom_mysql_units_or_unrelated_aliases_are_never_overwritten(self):
        for is_link, target in [(False, None), (True, '/usr/lib/systemd/system/other.service')]:
            with self.subTest(is_link=is_link), patch.object(agent.os.path, 'lexists', return_value=True), \
                 patch.object(agent.os.path, 'islink', return_value=is_link), \
                 patch.object(agent.os, 'readlink', return_value=target), \
                 patch.object(agent, 'mask_units') as mask, patch.object(agent, 'command') as cmd, self.assertRaises(agent.Refusal):
                agent.mask_database_units({})
            mask.assert_not_called(); cmd.assert_not_called()

    def test_only_fixed_rejoin_steps_not_arbitrary_reseed_or_sql_are_available(self):
        for operation in ['rejoin-check', 'rejoin-open', 'rejoin-seed', 'rejoin-restore', 'rejoin-replicate', 'rejoin-files', 'rejoin-verify']:
            self.assertEqual(agent.valid_request({**self.request, 'operation': operation}, 'production'), operation)
        for operation in ['seed', 'rejoin', 'sql', 'reset-master', 'route', 'restore-path']:
            with self.assertRaises(agent.Refusal):
                agent.valid_request({**self.request, 'operation': operation}, 'production')

    def test_replication_password_is_private_and_restricted_to_safe_sql_characters(self):
        with tempfile.TemporaryDirectory() as directory:
            password_file = pathlib.Path(directory) / 'convox-repl-password'
            password_file.write_text('Safe.Repl_123456789\n')
            password_file.chmod(0o600)
            original_path = pathlib.Path
            private_stat = SimpleNamespace(st_uid=0, st_mode=0o100600)
            with patch.object(agent.pathlib, 'Path', side_effect=lambda value: password_file if value == '/root/convox-repl-password' else original_path(value)), \
                 patch.object(type(password_file), 'stat', return_value=private_stat):
                self.assertEqual(agent.replication_password({'clusterSecret': 'ab' * 32}), 'Safe.Repl_123456789')
            password_file.write_text("unsafe'password123456")
            with patch.object(agent.pathlib, 'Path', side_effect=lambda value: password_file if value == '/root/convox-repl-password' else original_path(value)), \
                 patch.object(type(password_file), 'stat', return_value=private_stat), self.assertRaises(agent.Refusal):
                agent.replication_password({'clusterSecret': 'ab' * 32})

    def test_target_signed_restore_receipt_cannot_be_replayed_as_source_seed(self):
        target_cfg = {**self.cfg, 'host': 'dr'}
        target_request = {**self.request, 'host': 'dr'}
        receipt = agent.sign_receipt(target_cfg, target_request, 'restore', gtid='0-8111-100')
        agent.verify_receipt(target_cfg, target_request, receipt, 'restore', expected_host='dr')
        with self.assertRaises(agent.Refusal):
            agent.verify_receipt(target_cfg, target_request, receipt, 'seed')

    def test_rejoin_restore_refuses_before_any_destructive_sql_without_backup_and_fence(self):
        request = {**self.request, 'host': 'dr', 'source': 'production', 'target': 'dr', 'operation': 'rejoin-restore'}
        cfg = {**self.cfg, 'host': 'dr'}
        with patch.object(agent, 'sql') as sql:
            with self.assertRaises(agent.Refusal):
                agent.rejoin_restore(cfg, request, {})
            sql.assert_not_called()

    def test_transient_asterisk_cli_is_not_counted_as_the_managed_daemon(self):
        inventory = [
            {'pid': 1, 'parent': 0, 'state': 'S', 'name': 'asterisk', 'asteriskDaemon': True},
            {'pid': 2, 'parent': 1, 'state': 'S', 'name': 'asterisk', 'asteriskDaemon': False},
        ]
        with patch.object(agent, 'writers', return_value=inventory):
            self.assertEqual(sum(p.get('asteriskDaemon') for p in agent.writers()), 1)

    def test_wrapper_requires_foreground_support_and_preserves_private_environment(self):
        with patch.object(agent.pathlib.Path, 'is_file', return_value=True), \
             patch.object(agent.os, 'access', return_value=True), \
             patch.object(agent.pathlib.Path, 'read_text', return_value='if test -n "$ASTSAFE_FOREGROUND"; then run_asterisk; fi'):
            env = agent.wrapper_environment()
            self.assertEqual(env['ASTSAFE_FOREGROUND'], '1')
            self.assertEqual(env['HOME'], '/root')
            self.assertNotIn('ASTSAFE_FOREGROUND', agent.ENV)
        with patch.object(agent.pathlib.Path, 'is_file', return_value=True), \
             patch.object(agent.os, 'access', return_value=True), \
             patch.object(agent.pathlib.Path, 'read_text', return_value='run_asterisk &'), self.assertRaises(agent.Refusal):
            agent.wrapper_environment()

    def test_expired_source_read_lock_blocks_file_transfer_before_any_command(self):
        with patch.object(agent, 'application_fenced', return_value=True), patch.object(agent, 'lock_alive', return_value=False), patch.object(agent, 'command') as cmd:
            with self.assertRaises(agent.Refusal):
                agent.files(self.cfg, self.request, {'boundary': '0-8111-100'})
            cmd.assert_not_called()

    def test_partial_backup_cannot_authorize_source_shutdown_or_target_promotion(self):
        state = {'backup': 'partially-written-fixture', 'steps': {'backup': 'failed'}}
        with patch.object(agent, 'sql') as sql, patch.object(agent, 'command') as cmd:
            with self.assertRaises(agent.Refusal):
                agent.quiesce(self.cfg, self.request, state)
            with self.assertRaises(agent.Refusal):
                agent.promote({**self.cfg, 'host': 'dr'}, {**self.request, 'host': 'dr'}, state)
            sql.assert_not_called(); cmd.assert_not_called()

    def test_reserved_job_requires_its_own_preflight_and_cannot_replay_steps(self):
        cfg = {**self.cfg, 'adminReviewedStartup': True}
        with tempfile.TemporaryDirectory() as directory, patch.object(agent, 'ROOT', pathlib.Path(directory)):
            reserve = {**self.request, 'operation': 'reserve'}
            agent.dispatch(cfg, reserve)
            with self.assertRaises(agent.Refusal):
                agent.dispatch(cfg, {**self.request, 'operation': 'backup'})
            with patch.object(agent, 'preflight', return_value={'ok': True, 'ready': True}):
                agent.dispatch(cfg, {**self.request, 'operation': 'preflight'})
            with patch.object(agent, 'backup', return_value={'ok': True}) as backup:
                agent.dispatch(cfg, {**self.request, 'operation': 'backup'})
                with self.assertRaises(agent.Refusal):
                    agent.dispatch(cfg, {**self.request, 'operation': 'backup'})
                self.assertEqual(backup.call_count, 1)
            with self.assertRaises(agent.Refusal):
                agent.dispatch(cfg, {**reserve, 'jobId': 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'})

    def test_valid_promotion_preserves_binlogs_and_never_changes_local_tables(self):
        cfg = {**self.cfg, 'host': 'dr'}
        request = {**self.request, 'host': 'dr', 'operation': 'promote'}
        for kind in ['boundary', 'files', 'fence']:
            request[kind] = agent.sign_receipt(self.cfg, self.request, kind, gtid='0-8111-100')
        state = {'backup': 'fixture', 'steps': {'backup': 'complete'}, 'caughtUp': '0-8111-100'}
        database = {'serverId': 30150, 'readOnly': True, 'logBin': True, 'logSlaveUpdates': True,
                    'eventScheduler': 'OFF', 'gtidCurrent': '0-8111-100', 'gtidSlave': '0-8111-100'}
        with tempfile.TemporaryDirectory() as directory, patch.object(agent, 'ROOT', pathlib.Path(directory)), \
             patch.object(agent, 'application_fenced', return_value=True), \
             patch.object(agent, 'db', side_effect=[database, database, {'readOnly': False}]), \
             patch.object(agent, 'require_clock'), \
             patch.object(agent, 'persist_role') as persist, patch.object(agent, 'sql', side_effect=[
                 'Master_Host\tSlave_SQL_Running\tLast_SQL_Error\n10.81.0.11\tYes\t\n', '', '', '']) as sql:
            result = agent.promote(cfg, request, state)
            self.assertTrue(result['ok']); persist.assert_called_once_with(False)
            self.assertTrue(state['promoted'])
            statements = ' '.join(c.args[0] for c in sql.call_args_list)
            for forbidden in ['RESET MASTER', 'DROP', 'UPDATE', 'DELETE']:
                self.assertNotIn(forbidden, statements)
            self.assertTrue((pathlib.Path(directory) / 'primary').exists())


if __name__ == '__main__':
    unittest.main()
