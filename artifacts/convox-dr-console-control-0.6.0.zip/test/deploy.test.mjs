import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

const read = name => readFileSync(new URL(`../deploy/${name}`, import.meta.url), 'utf8');
const installer = read('install-rhel.sh');

test('archival defaults agree across installer, environment and Nginx', () => {
  assert.ok(installer.includes('CONSOLE_HOST="${CONSOLE_HOST:-10.3.0.151}"'));
  assert.match(read('console.env'), /^CONVOX_PUBLIC_ORIGIN=https:\/\/10\.3\.0\.151$/m);
  assert.match(read('console.env'), /^CONVOX_MODE=simulation$/m);
  assert.match(read('convox-dr-console.conf'), /listen 443 ssl;/);
  assert.match(read('convox-dr-console.conf'), /server_name 10\.3\.0\.151;/);
  assert.match(read('convox-dr-console.conf'), /proxy_pass http:\/\/127\.0\.0\.1:4180;/);
  assert.equal(installer.includes('10.3.0.150'), false);
});

test('installer host validator accepts valid management hosts and rejects unsafe input', () => {
  const match = installer.match(/node --input-type=module -e '([^']+)' "\$CONSOLE_HOST" \|\| fail/);
  assert.ok(match, 'Host validator must exist before installation');
  for (const host of ['10.3.0.151', 'archival', 'archival.example.internal']) {
    assert.equal(spawnSync(process.execPath, ['--input-type=module', '-e', match[1], host]).status, 0, host);
  }
  for (const host of ['999.3.0.151', 'https://10.3.0.151', 'host:443', 'bad..host', '-bad.example', 'bad;host', 'host|injection', 'host\nvalue', 'a'.repeat(64)+'.internal']) {
    assert.notEqual(spawnSync(process.execPath, ['--input-type=module', '-e', match[1], host]).status, 0, host);
  }
});

test('UAT clock exception helper is explicit, expiring and reversible', () => {
  const helper = read('configure-uat-clock-skew-rhel.sh');
  assert.match(helper, /controller\|agent enable\|disable/);
  assert.match(helper, /4 \* 60 \* 60/);
  assert.match(helper, /uatClockSkewMode.*False/s);
  assert.match(helper, /operation\.json/);
});

test('repeat-drill rollout carries one consistent release to both agents and controller', () => {
  const version = '0.5.1'; // Historical package retains its own version-pinned installer.
  const rollout = read('rollout-prepare-dr-rhel.sh');
  assert.equal(version, '0.5.1');
  assert.ok(rollout.includes(`release.get('version') != '${version}'`));
  assert.ok(rollout.includes(`/root/convox-console-${version}-agent`));
  for (const file of ['convox-console-control.py', 'install-rejoin-rhel.sh', 'configure-uat-clock-skew-rhel.sh'])
    assert.ok(rollout.includes(`deploy/${file}`));
  assert.ok(rollout.includes('bash deploy/upgrade-rhel.sh'));
  assert.ok(rollout.includes('"cutoverVersion")==2'));
  assert.ok(rollout.includes('socket.create_connection((expected[2], 3306)'));
  assert.ok(rollout.includes("'production': ('8111', '0', '10.3.0.150')"));
  assert.ok(rollout.includes("'dr': ('30150', '1', '10.81.0.11')"));
  assert.ok(rollout.includes('operation.json'));
  assert.ok(rollout.includes('sha256sum --quiet -c SHA256SUMS'));
});

test('continuous-file rollout ships the service and agent together without triggering database operations', () => {
  const version = JSON.parse(readFileSync(new URL('../package.json', import.meta.url))).version;
  const rollout = read('rollout-filesync-rhel.sh'), installer = read('install-filesync-rhel.sh');
  assert.equal(version, '0.6.0'); assert.ok(rollout.includes(`get('version') != '${version}'`));
  for (const file of ['convox-console-control.py', 'convox-console-filesync.service', 'install-filesync-rhel.sh', 'configure-uat-clock-skew-rhel.sh'])
    assert.ok(rollout.includes(`deploy/${file}`));
  assert.ok(rollout.includes('fileSyncVersion')); assert.ok(rollout.includes('sha256sum --quiet -c SHA256SUMS'));
  assert.ok(installer.includes('operation.json')); assert.ok(installer.includes('systemctl mask "$UNIT"'));
  for (const forbidden of ['RESET SLAVE', 'CHANGE MASTER', 'read_only=', 'restart nginx', 'start nginx', '/etc/lsyncd.conf"'])
    assert.ok(!installer.includes(forbidden));
});
