import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { ControlController, normalizeFileSync } from '../lib/control.mjs';
import { HOSTS, IP } from '../lib/model.mjs';

async function fixture(t, source = 'production', failure = null) {
  const target = HOSTS.find(host => host !== source), calls = [];
  const dataDir = await mkdtemp(path.join(tmpdir(), 'convox-file-only-'));
  t.after(() => rm(dataDir, { recursive: true, force: true }));
  const obs = { active: source, fileSource: null, servers: {}, warnings: [] };
  for (const host of HOSTS) obs.servers[host] = { ip: IP[host], reachable: true, sshReachable: true,
    role: host === source ? 'primary' : 'replica', readOnly: host !== source, io: host !== source, sql: host !== source,
    lag: 0, upstream: host === source ? null : IP[source],
    continuousSync: { state: 'stopped', watcherRunning: false },
    control: { fileSyncVersion: 1, prepareVersion: 2, cutoverVersion: 2, applicationFenced: host !== source,
      databaseFenced: false, runtimeHealthy: host === source } };
  const adapter = { observe: async () => structuredClone(obs), call: async (host, operation, jobId, details) => {
    calls.push({ host, operation, jobId, details: structuredClone(details) });
    if (operation === failure) throw new Error(`${operation} refused`);
    if (operation === 'sync-stop') obs.servers[host].continuousSync = { state: 'stopped', watcherRunning: false };
    if (operation === 'sync-start') obs.servers[host].continuousSync = {
      state: 'pending', source, target, watcherRunning: true, lastProbeAt: new Date().toISOString(), pending: 1 };
    return { ok: true, ready: true, fileSyncVersion: 1, proof: { kind: operation } };
  } };
  const c = await new ControlController({ dataDir, adapter, mode: 'control' }).init();
  await c.refresh(); return { c, adapter, obs, source, target, calls };
}

for (const source of HOSTS) {
  test(`Start file sync ${source} to prepared standby never rebuilds or switches databases/applications`, async t => {
    const { c, obs, target, calls } = await fixture(t, source);
    const roles = HOSTS.map(host => ({ role: obs.servers[host].role, readOnly: obs.servers[host].readOnly,
      control: structuredClone(obs.servers[host].control), upstream: obs.servers[host].upstream }));
    assert.equal(c.view().actions.syncFiles.allowed, true);
    await c.start('syncFiles', 'START FILE SYNC'); await c.pending;
    assert.equal(c.state.jobs[0].state, 'complete', c.state.jobs[0].error);
    assert.deepEqual(HOSTS.map(host => ({ role: obs.servers[host].role, readOnly: obs.servers[host].readOnly,
      control: obs.servers[host].control, upstream: obs.servers[host].upstream })), roles);
    assert.equal(obs.active, source); assert.equal(obs.servers[target].control.applicationFenced, true);
    assert.deepEqual(calls.map(call => call.operation), ['reserve', 'reserve', 'sync-check', 'sync-check',
      'sync-stop', 'sync-stop', 'sync-ready', 'sync-start', 'release', 'release']);
    assert.equal(calls.find(call => call.operation === 'sync-ready').host, target);
    assert.equal(calls.find(call => call.operation === 'sync-start').host, source);
    assert.ok(calls.find(call => call.operation === 'sync-start').details.receiver);
    assert.ok(!calls.some(call => ['backup', 'rejoin-open', 'rejoin-restore', 'promote', 'quiesce', 'activate'].includes(call.operation)));
  });
}
for (const failure of ['sync-check', 'sync-stop', 'sync-ready', 'sync-start']) {
  test(`${failure} failure cannot report file sync complete or advance to a later step`, async t => {
    const { c, calls } = await fixture(t, 'production', failure);
    await c.start('syncFiles', 'START FILE SYNC'); await c.pending;
    assert.equal(c.state.jobs[0].state, 'failed'); assert.equal(c.state.reconcileRequired, true);
    const failedAt = calls.findIndex(call => call.operation === failure);
    assert.ok(calls.slice(failedAt).every(call => call.operation === failure));
  });
}
test('lost replica health, target fence or agent compatibility blocks file action before reservations', async t => {
  for (const change of [node => node.control.applicationFenced = false, node => node.readOnly = false,
    node => node.io = false, node => node.upstream = '10.0.0.99', node => delete node.control.fileSyncVersion]) {
    const { c, obs, calls } = await fixture(t);
    change(obs.servers.dr);
    await assert.rejects(c.start('syncFiles', 'START FILE SYNC'));
    assert.equal(calls.length, 0);
  }
});
test('final stale or failed sender observation keeps reservations and never declares completion', async t => {
  const { c, adapter, obs, calls } = await fixture(t);
  const original = adapter.call;
  adapter.call = async (...args) => {
    const result = await original(...args);
    if (args[1] === 'sync-start') obs.servers.production.continuousSync.state = 'unverified';
    return result;
  };
  await c.start('syncFiles', 'START FILE SYNC'); await c.pending;
  assert.equal(c.state.jobs[0].state, 'failed'); assert.ok(!calls.some(call => call.operation === 'release'));
});
test('file telemetry validates direction, probe, queue size and reports unsupported old agents as unverified', () => {
  assert.equal(normalizeFileSync(undefined, 'production').state, 'unverified');
  const good = { version: 1, state: 'pending', source: 'production', target: 'dr', pending: 3,
    lastProbeAt: new Date().toISOString(), watcherRunning: true };
  assert.equal(normalizeFileSync(good, 'production').pending, 3);
  for (const changes of [{ target: 'production' }, { source: 'dr' }, { pending: -1 }, { lastProbeAt: 'invalid' }, { watcherRunning: 'true' }])
    assert.throws(() => normalizeFileSync({ ...good, ...changes }, 'production'));
});
