"""File sender guards and telemetry; never run real SSH, systemd or Lsyncd."""
import contextlib
import json
import pathlib
import sys
import tempfile
import time
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch
from control_agent_test import agent


class FileSyncTests(unittest.TestCase):
    def pair(self, source='production'):
        target = 'dr' if source == 'production' else 'production'
        cfg = {'host': source, 'clusterSecret': 'ab' * 32, 'adminReviewedStartup': True,
               'fileIdentity': '/root/.ssh/convox-file-sync', 'fileKnownHosts': '/root/.ssh/known_hosts'}
        req = {'version': 1, 'host': source, 'source': source, 'target': target, 'fileSyncVersion': 1,
               'jobId': '12345678-1234-1234-1234-123456789abc', 'operation': 'sync-start'}
        return cfg, req

    def test_generated_config_has_only_eight_roots_correct_direction_checksums_and_no_deletes(self):
        for source in agent.IPS:
            cfg, req = self.pair(source)
            text = agent.file_sync_config(cfg, req['target'])
            self.assertEqual(text.count('sync { default.rsync,'), 8)
            self.assertEqual(text.count('delete = false'), 8)
            self.assertEqual(text.count('checksum = true'), 8)
            for folder in agent.PATHS:
                self.assertIn('convoxsync@' + agent.IPS[req['target']] + ':' + folder, text)
            for path in ['/etc/nginx/', '/var/www/convox4.conf', '/var/www/convoxwebpanel.conf', '/var/lib/mysql/']:
                self.assertNotIn(path, text)
            for option in ['StrictHostKeyChecking=yes', 'BatchMode=yes', 'IdentityAgent=none']:
                self.assertIn(option, text)
            for option in ['--delete', '--inplace', '--size-only', 'default.rsyncssh', '"--recursive"']:
                self.assertNotIn(option, text)
            with self.assertRaises(agent.Refusal): agent.file_sync_config(cfg, source)

    def test_primary_guard_rejects_role_identity_upstream_marker_or_legacy_sender_changes(self):
        cfg, req = self.pair()
        for failure in ['readonly', 'identity', 'upstream', 'marker', 'disarmed', 'legacy']:
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as directory, contextlib.ExitStack() as stack:
                root = pathlib.Path(directory); (root / 'primary').write_text('approved\n')
                stack.enter_context(patch.object(agent, 'ROOT', root))
                database = {'serverId': 8111, 'readOnly': False}
                if failure == 'readonly': database['readOnly'] = True
                if failure == 'identity': database['serverId'] = 30150
                stack.enter_context(patch.object(agent, 'db', return_value=database))
                stack.enter_context(patch.object(agent, 'sql', return_value='Master_Host\n10.3.0.150\n' if failure == 'upstream' else ''))
                stack.enter_context(patch.object(agent, 'unit', return_value={'active': 'active' if failure == 'legacy' else 'inactive', 'masked': True}))
                stack.enter_context(patch.object(agent, 'legacy_sync_fenced', return_value=failure != 'legacy'))
                sender = {'armed': failure != 'disarmed', 'primaryMarker': 'other\n' if failure == 'marker' else 'approved\n'}
                with self.assertRaises(agent.Refusal): agent.file_sender_role(cfg, sender)

    def test_receiver_proof_is_job_bound_and_requires_fenced_readonly_expected_replica(self):
        for source in agent.IPS:
            cfg, req = self.pair(source)
            cfg['host'] = req['host'] = req['target']
            req['operation'] = 'sync-ready'
            replica = 'Master_Host\tSlave_IO_Running\tSlave_SQL_Running\tLast_IO_Error\tLast_SQL_Error\n' + agent.IPS[source] + '\tYes\tYes\t\t\n'
            database = {'serverId': agent.IDS[cfg['host']], 'readOnly': True, 'gtidCurrent': '0-' + str(agent.IDS[source]) + '-100'}
            with patch.object(agent, 'application_fenced', return_value=True), patch.object(agent, 'db', return_value=database), \
                 patch.object(agent, 'sql', return_value=replica):
                proof = agent.sync_ready(cfg, req, {'fileSyncChecked': True})['proof']
                verified = agent.verify_receipt(cfg, req, proof, 'file-receiver', expected_host=cfg['host'])
                self.assertTrue(verified['readOnly']); self.assertTrue(verified['senderStopped'])
                with patch.object(agent, 'application_fenced', return_value=False), self.assertRaises(agent.Refusal):
                    agent.sync_ready(cfg, req, {'fileSyncChecked': True})
                with patch.object(agent, 'db', return_value={**database, 'readOnly': False}), self.assertRaises(agent.Refusal):
                    agent.sync_ready(cfg, req, {'fileSyncChecked': True})

    def test_invalid_receiver_evidence_blocks_start_before_service_or_file_changes(self):
        cfg, req = self.pair()
        with patch.object(agent, 'command') as cmd, patch.object(agent, 'atomic_json') as save:
            with self.assertRaises(agent.Refusal): agent.sync_start(cfg, req, {'fileSyncChecked': True})
            cmd.assert_not_called(); save.assert_not_called()

    def test_failed_start_stops_only_the_managed_sender_and_preserves_database_and_application(self):
        cfg, req = self.pair()
        req['receiver'] = agent.sign_receipt({**cfg, 'host': req['target']}, req, 'file-receiver',
            gtid='0-8111-100', readOnly=True, senderStopped=True)
        with tempfile.TemporaryDirectory() as directory, patch.object(agent, 'ROOT', pathlib.Path(directory)), \
             patch.object(agent, 'preparation_file_checks'), patch.object(agent, 'file_sender_role'), \
             patch.object(agent, 'managed_sync_inventory_safe', return_value=True), \
             patch.object(agent, 'unit', return_value={'active': 'inactive'}), patch.object(agent, 'command') as cmd, \
             patch.object(agent, 'file_sync_status', return_value={'state': 'unverified'}), \
             patch.object(agent, 'stop_file_sync') as stop, patch.object(agent, 'sql') as sql:
            (pathlib.Path(directory) / 'primary').write_text('approved\n')
            with self.assertRaisesRegex(agent.Refusal, 'failed to start'):
                agent.sync_start(cfg, req, {'fileSyncChecked': True})
            stop.assert_called_once(); sql.assert_not_called()
            self.assertTrue(all(call.args[0][-1] == agent.SYNC_UNIT for call in cmd.call_args_list))

    def test_dispatch_registers_all_fixed_sync_operations_and_reservation_checks(self):
        cfg, req = self.pair()
        for operation, function in [('sync-check', 'sync_check'), ('sync-stop', 'sync_stop'), ('sync-ready', 'sync_ready'), ('sync-start', 'sync_start')]:
            with self.subTest(operation=operation), tempfile.TemporaryDirectory() as directory, patch.object(agent, 'ROOT', pathlib.Path(directory)), \
                 patch.object(agent, function, return_value={'ok': True, 'ready': True}) as handler:
                request = {**req, 'operation': operation}
                state = {'jobId': req['jobId'], 'source': req['source'], 'target': req['target'], 'preflightPassed': True, 'steps': {}}
                agent.atomic_json(agent.ROOT / 'operation.json', state)
                self.assertTrue(agent.dispatch(cfg, request)['ok']); handler.assert_called_once()
                with self.assertRaises(agent.Refusal): agent.dispatch(cfg, request)

    def test_scoped_rsync_receiver_is_exempt_but_senders_wrong_uid_and_unrelated_paths_are_not(self):
        cfg, req = self.pair()
        pwd = SimpleNamespace(getpwnam=lambda name: SimpleNamespace(pw_uid=123))
        args = b'/usr/bin/rsync\0--server\0-options\0.\0/var/www/convox_perl/\0'
        with patch.dict(sys.modules, {'pwd': pwd}), patch.object(agent.os, 'readlink', return_value='/usr/bin/rsync'), \
             patch.object(agent.os, 'stat', return_value=SimpleNamespace(st_uid=123)):
            self.assertTrue(agent.is_file_receiver(10, 'rsync', args))
            self.assertFalse(agent.is_file_receiver(10, 'rsync', args.replace(b'--server', b'--server\0--sender')))
            self.assertFalse(agent.is_file_receiver(10, 'rsync', args.replace(b'/var/www/convox_perl/', b'/root/')))
            with patch.object(agent.os, 'stat', return_value=SimpleNamespace(st_uid=0)):
                self.assertFalse(agent.is_file_receiver(10, 'rsync', args))
        inventory = [{'pid': 10, 'state': 'S', 'name': 'rsync', 'vendor': True, 'fileReceiver': True},
                     {'pid': 11, 'state': 'S', 'name': 'perl', 'vendor': True}]
        with patch.object(agent, 'processes', return_value=inventory), patch.object(agent.os, 'getpid', return_value=99):
            self.assertEqual([p['pid'] for p in agent.writers()], [11])

    def test_live_watcher_with_fresh_probe_reports_pending_separately_from_database_replication(self):
        cfg, req = self.pair()
        for pending in [0, 3]:
            with self.subTest(pending=pending), tempfile.TemporaryDirectory() as directory, patch.object(agent, 'ROOT', pathlib.Path(directory)), \
                 patch.object(agent, 'unit', return_value={'active': 'active'}), patch.object(agent, 'file_sender_role'), \
                 patch.object(agent, 'load_file_sender', return_value={'source': req['source'], 'target': req['target'], 'jobId': req['jobId'], 'startedAt': time.time()}):
                root = pathlib.Path(directory)
                agent.atomic_json(root / 'file-sync-heartbeat.json', {'jobId': req['jobId'], 'at': time.time(), 'running': True, 'lastProbeAt': time.time()})
                (root / 'file-sync.status').write_text('\n'.join('Sync' + str(i) + ' source=' + folder + '\nThere are ' + str(pending if i == 0 else 0) + ' delays' for i, folder in enumerate(agent.PATHS)))
                result = agent.file_sync_status(cfg)
                self.assertEqual(result['state'], 'pending' if pending else 'watching')
                self.assertEqual(result['pending'], pending); self.assertTrue(result['watcherRunning'])
                self.assertEqual(result['target'], req['target']); self.assertTrue(result['lastProbeAt'])

    def test_stale_heartbeat_cannot_report_healthy_even_if_service_active(self):
        cfg, req = self.pair()
        with tempfile.TemporaryDirectory() as directory, patch.object(agent, 'ROOT', pathlib.Path(directory)), \
             patch.object(agent, 'unit', return_value={'active': 'active'}), patch.object(agent, 'file_sender_role'), \
             patch.object(agent, 'load_file_sender', return_value={'source': req['source'], 'target': req['target'], 'jobId': req['jobId'], 'startedAt': time.time() - 300}):
            agent.atomic_json(agent.ROOT / 'file-sync-heartbeat.json', {'jobId': req['jobId'], 'at': time.time() - 60, 'running': True, 'lastProbeAt': time.time()})
            result = agent.file_sync_status(cfg)
            self.assertEqual(result['state'], 'unverified'); self.assertFalse(result['watcherRunning'])

    def test_worker_stops_its_child_when_primary_role_is_lost_before_writing_another_probe(self):
        cfg, req = self.pair()
        watcher = Mock(); watcher.poll.return_value = None
        with tempfile.TemporaryDirectory() as directory, patch.object(agent, 'ROOT', pathlib.Path(directory)), \
             patch.object(agent.os, 'geteuid', return_value=0, create=True), \
             patch.object(agent, 'fcntl', SimpleNamespace(flock=lambda *args: None, LOCK_EX=1, LOCK_NB=2)), \
             patch.object(agent, 'load_file_sender', return_value={'source': req['source'], 'target': req['target'], 'armed': True}), \
             patch.object(agent, 'file_sender_role', side_effect=[None, agent.Refusal('primary role lost')]), \
             patch.object(agent, 'managed_sync_inventory_safe', return_value=True), \
             patch.object(agent.subprocess, 'Popen', return_value=watcher), patch.object(agent, 'command') as cmd:
            with self.assertRaisesRegex(agent.Refusal, 'primary role lost'): agent.file_sync_worker(cfg)
            watcher.terminate.assert_called_once(); cmd.assert_not_called()

    def test_runtime_only_legacy_mask_does_not_authorize_a_sender_after_reboot(self):
        with patch.object(agent.os.path, 'islink', return_value=False), patch.object(agent, 'unit', return_value={'active': 'inactive', 'masked': True}):
            self.assertFalse(agent.legacy_sync_fenced())

    def test_manual_lsyncd_process_cannot_hide_behind_an_inactive_legacy_unit(self):
        inventory = [{'pid': 10, 'name': 'lsyncd', 'state': 'S'}]
        with patch.object(agent, 'processes', return_value=inventory), \
             patch.object(agent.pathlib.Path, 'read_bytes', return_value=b'lsyncd\0/etc/lsyncd.conf\0'), \
             patch.object(agent.pathlib.Path, 'read_text', return_value='0::/user.slice/session.scope\n'):
            self.assertFalse(agent.managed_sync_inventory_safe())
        with patch.object(agent, 'processes', return_value=inventory), \
             patch.object(agent.pathlib.Path, 'read_bytes', return_value=b'lsyncd\0' + str(agent.ROOT / 'file-sync.lua').encode() + b'\0'), \
             patch.object(agent.pathlib.Path, 'read_text', return_value='0::/system.slice/' + agent.SYNC_UNIT + '\n'):
            self.assertTrue(agent.managed_sync_inventory_safe())

    def test_sync_checks_are_read_only_and_accept_only_the_expected_primary_replica_pair(self):
        for source in agent.IPS:
            cfg, req = self.pair(source)
            for host in [source, req['target']]:
                with self.subTest(source=source, host=host), contextlib.ExitStack() as stack:
                    config, request = {**cfg, 'host': host}, {**req, 'host': host, 'operation': 'sync-check'}
                    stack.enter_context(patch.object(agent, 'clock_evidence', return_value={'mode': 'ntp', 'epochMs': 1}))
                    stack.enter_context(patch.object(agent.pathlib.Path, 'is_file', return_value=True))
                    stack.enter_context(patch.object(agent, 'legacy_sync_fenced', return_value=True))
                    stack.enter_context(patch.object(agent, 'managed_sync_inventory_safe', return_value=True))
                    stack.enter_context(patch.object(agent, 'preparation_file_checks'))
                    stack.enter_context(patch.object(agent, 'snapshot', return_value={'control': {'runtimeHealthy': True}}))
                    stack.enter_context(patch.object(agent, 'application_fenced', return_value=True))
                    stack.enter_context(patch.object(agent, 'db', return_value={'serverId': agent.IDS[host], 'readOnly': host != source}))
                    replicas = '' if host == source else 'Master_Host\tSlave_IO_Running\tSlave_SQL_Running\tLast_IO_Error\tLast_SQL_Error\n' + agent.IPS[source] + '\tYes\tYes\t\t\n'
                    sql = stack.enter_context(patch.object(agent, 'sql', return_value=replicas))
                    state = {}
                    self.assertTrue(agent.sync_check(config, request, state)['ready']); self.assertTrue(state['fileSyncChecked'])
                    self.assertTrue(all(call.args[0] == 'SHOW ALL SLAVES STATUS' for call in sql.call_args_list))


if __name__ == '__main__':
    unittest.main()
