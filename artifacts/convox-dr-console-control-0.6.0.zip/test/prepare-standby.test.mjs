import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { ControlController, controlTimeout } from '../lib/control.mjs';
import { IP, LOCAL_TABLES } from '../lib/model.mjs';

async function setup(t, source = 'production', failure = null) {
  const target = source === 'production' ? 'dr' : 'production';
  const action = target === 'dr' ? 'prepareDr' : 'rejoin';
  const phrase = target === 'dr' ? 'REBUILD DR' : 'REBUILD PRODUCTION';
  const dataDir = await mkdtemp(path.join(tmpdir(), 'convox-prepare-'));
  t.after(() => rm(dataDir, { recursive: true, force: true }));
  const obs = { active: source, fileSource: null, warnings: [], servers: {
    [source]: { ip: IP[source], reachable: true, sshReachable: true, role: 'primary', readOnly: false,
      control: { runtimeHealthy: true, databaseFenced: false, applicationFenced: false, prepareVersion: 2, fileSyncVersion: 1 } },
    [target]: { ip: IP[target], reachable: false, sshReachable: true, role: 'fenced', readOnly: null,
      control: { runtimeHealthy: false, databaseFenced: true, applicationFenced: true, prepareVersion: 2, fileSyncVersion: 1 } }
  } };
  const calls = [];
  const adapter = { observe: async () => structuredClone(obs), call: async (host, operation, jobId, details) => {
    calls.push({ host, operation, jobId, details: structuredClone(details) });
    if (failure === operation) throw new Error(`${operation} refused`);
    if (operation === 'rejoin-open') {
      Object.assign(obs.servers[target], { reachable: true, readOnly: true, role: 'read-only' });
      obs.servers[target].control.databaseFenced = false;
    }
    if (operation === 'rejoin-replicate') Object.assign(obs.servers[target], { role: 'replica', io: true, sql: true, lag: 0, upstream: IP[source] });
    if (operation === 'sync-stop') obs.servers[host].continuousSync = { state: 'stopped', watcherRunning: false };
    if (operation === 'sync-start') obs.servers[source].continuousSync = { state: 'watching', source, target, watcherRunning: true };
    return { ok: true, ready: true, prepareVersion: 2, credentialId: 'same-secret', checks: [], proof: { kind: operation } };
  } };
  const c = await new ControlController({ dataDir, adapter, mode: 'control' }).init();
  await c.refresh();
  return { c, obs, calls, source, target, action, phrase, dataDir };
}

for (const source of ['production', 'dr']) {
  test(`prepare from ${source} preserves source authority and fences only the standby application`, async t => {
    const { c, obs, calls, target, action, phrase } = await setup(t, source);
    assert.equal(c.view().actions[action].allowed, true, 'No cutover preflight needed');
    await c.start(action, phrase); await c.pending;
    assert.equal(c.state.jobs[0].state, 'complete', c.state.jobs[0].error);
    assert.equal(c.state.jobs[0].steps.length, 13);
    assert.equal(c.state.active, source); assert.equal(obs.servers[source].readOnly, false);
    assert.equal(obs.servers[target].readOnly, true);
    assert.equal(obs.servers[target].control.applicationFenced, true);
    assert.equal(obs.servers[target].control.runtimeHealthy, false);
    assert.equal(c.state.preflight, null);
    assert.equal(c.view().actions[source === 'production' ? 'failover' : 'failback'].allowed, false);
    const targetSteps = new Set(['rejoin-open', 'rejoin-restore', 'rejoin-replicate', 'rejoin-verify']);
    const sourceSteps = new Set(['rejoin-seed', 'rejoin-files']);
    for (const call of calls) {
      assert.equal(call.details.source, source); assert.equal(call.details.target, target);
      assert.deepEqual(call.details.localTables, LOCAL_TABLES); assert.equal(call.details.prepareVersion, 2);
      if (targetSteps.has(call.operation)) assert.equal(call.host, target);
      if (sourceSteps.has(call.operation)) assert.equal(call.host, source);
      assert.ok(!['activate', 'promote', 'fence', 'quiesce'].includes(call.operation));
    }
    const ops = calls.map(c => c.operation);
    for (const [before, after] of [['rejoin-check', 'rejoin-open'], ['backup', 'rejoin-seed'], ['rejoin-seed', 'rejoin-restore'], ['rejoin-restore', 'rejoin-replicate'], ['rejoin-replicate', 'rejoin-files'], ['rejoin-verify', 'release']])
      assert.ok(ops.indexOf(before) < ops.indexOf(after));
  });
}
for (const failure of ['reserve', 'rejoin-check', 'sync-stop', 'rejoin-open', 'backup', 'rejoin-seed', 'rejoin-restore', 'rejoin-replicate', 'rejoin-files', 'rejoin-verify', 'sync-ready', 'sync-start', 'release']) {
  test(`Prepare DR ${failure} failure halts later steps and requires reconciliation`, async t => {
    const { c, calls } = await setup(t, 'production', failure);
    await c.start('prepareDr', 'REBUILD DR'); await c.pending;
    assert.equal(c.state.jobs[0].state, 'failed'); assert.equal(c.state.reconcileRequired, true);
    const last = calls.findIndex(c => c.operation === failure);
    assert.ok(calls.slice(last).every(c => c.operation === failure), 'No later remote operation');
    await assert.rejects(c.start('prepareDr', 'REBUILD DR'), /reconcil/);
  });
}
test('wrong direction, wrong confirmation, mixed agents, pending validation and lost fence block before mutation', async t => {
  const { c, obs, calls } = await setup(t);
  await assert.rejects(c.start('prepareDr', 'REBUILD PRODUCTION'), /Confirmation/);
  await assert.rejects(c.start('rejoin', 'REBUILD PRODUCTION'), /sole active writer/);
  for (const host of ['production', 'dr']) {
    obs.servers[host].control.prepareVersion = undefined;
    await assert.rejects(c.start('prepareDr', 'REBUILD DR'), /both servers/);
    obs.servers[host].control.prepareVersion = 2;
  }
  c.state.jobs.push({ state: 'awaiting-validation' });
  await assert.rejects(c.start('prepareDr', 'REBUILD DR'), /Validate routing/);
  c.state.jobs = [];
  obs.servers.dr.control.applicationFenced = false;
  await assert.rejects(c.start('prepareDr', 'REBUILD DR'), /fenced/);
  assert.equal(calls.length, 0);
});
test('final observation failure keeps reservations and does not report completion', async t => {
  const { c, obs, calls } = await setup(t);
  const call = c.adapter.call;
  c.adapter.call = async (...args) => {
    const result = await call(...args);
    if (args[1] === 'rejoin-verify') obs.servers.dr.readOnly = false;
    return result;
  };
  await c.start('prepareDr', 'REBUILD DR'); await c.pending;
  assert.equal(c.state.jobs[0].state, 'failed');
  assert.ok(!calls.some(c => c.operation === 'release'));
});
test('restart after interrupted preparation records interruption without replay', async t => {
  const { c, dataDir, calls } = await setup(t);
  c.state.jobs.push({ action: 'prepareDr', source: 'production', target: 'dr', state: 'running', steps: [{ key: 'rejoin-restore', state: 'running' }] });
  await c.save();
  const next = await new ControlController({ dataDir, adapter: c.adapter, mode: 'control' }).init();
  assert.equal(next.state.jobs[0].state, 'interrupted'); assert.equal(next.state.reconcileRequired, true);
  assert.equal(calls.length, 0);
});
test('transport budgets cover the maximum bounded backup and eight-folder baseline', () => {
  assert.ok(controlTimeout('backup') > 2 * 180000);
  assert.ok(controlTimeout('rejoin-files') > 8 * 240000);
  assert.ok(controlTimeout('rejoin-seed') > 2 * 240000);
});
