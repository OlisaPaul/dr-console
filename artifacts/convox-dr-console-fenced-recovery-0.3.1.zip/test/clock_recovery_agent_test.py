"""Clock and fenced-job recovery tests use mock OS/DB operations only."""
import datetime
import pathlib
import tempfile
import unittest
from unittest.mock import patch
from control_agent_test import agent


class RecoveryAgentTests(unittest.TestCase):
    def setUp(self):
        self.cfg = {'host': 'production', 'clusterSecret': 'ab' * 32,
                    'fileIdentity': '/root/.ssh/convox-file-sync', 'fileKnownHosts': '/root/.ssh/known_hosts'}
        self.req = {'version': 1, 'host': 'production', 'source': 'production', 'target': 'dr',
                    'operation': 'recover-evidence', 'jobId': 'd6806999-884d-4cd5-b15c-2490123ad9be'}
        self.source = {'steps': {'fence': 'complete'}, 'fenced': True, 'boundary': '0-8111-98296', 'filesVerified': '0-8111-98296'}

    def test_unsynchronized_clock_blocks_ordinary_preflight_before_any_db_query(self):
        with patch.object(agent, 'command', return_value='no\n'), patch.object(agent, 'db') as db, self.assertRaisesRegex(agent.Refusal, 'Clock is not synchronized'):
            agent.preflight({**self.cfg, 'adminReviewedStartup': True}, self.req)
        db.assert_not_called()

    def test_manual_exception_requires_exact_job_unexpired_window_and_paused_chrony(self):
        with patch.object(agent.time, 'time', return_value=100), patch.object(agent, 'unit', return_value={'active': 'inactive'}):
            cfg = {**self.cfg, 'manualRecoveryJobId': self.req['jobId'], 'manualRecoveryExpires': 200}
            self.assertIn('manual', agent.require_clock(cfg, self.req, manual_recovery=True))
            with patch.object(agent, 'command', return_value='no'):
                for changes in [{'manualRecoveryJobId': 'other'}, {'manualRecoveryExpires': 99}, {'manualRecoveryExpires': 4000}]:
                    with self.subTest(changes=changes), self.assertRaises(agent.Refusal):
                        agent.require_clock({**cfg, **changes}, self.req, manual_recovery=True)
                with self.assertRaises(agent.Refusal):
                    agent.require_clock(cfg, self.req, manual_recovery=False)
            with patch.object(agent, 'unit', return_value={'active': 'active'}), patch.object(agent, 'command', return_value='no'), self.assertRaises(agent.Refusal):
                agent.require_clock(cfg, self.req, manual_recovery=True)

    def test_healthy_ntp_and_stale_reference_have_distinct_results(self):
        now = datetime.datetime(2026, 10, 5, 22, 20, tzinfo=datetime.timezone.utc).timestamp()
        tracking = '''Reference ID : ABCDEF12
Stratum : 3
Ref time (UTC) : Mon Oct 05 22:19:50 2026
Root delay : 0.010 seconds
Root dispersion : 0.020 seconds
Leap status : Normal
'''
        with patch.object(agent.time, 'time', return_value=now):
            with patch.object(agent, 'command', side_effect=['yes\n', tracking, '^* 10.0.0.1 2 6 377 5 +10us']):
                self.assertIn('Synchronized', agent.require_clock(self.cfg, self.req))
            with patch.object(agent, 'command', side_effect=['yes\n', tracking.replace('Oct 05 22:19:50', 'Sep 14 09:39:40')]), self.assertRaisesRegex(agent.Refusal, 'reference is stale'):
                agent.require_clock(self.cfg, self.req)

    def test_fresh_recovery_receipts_require_actual_fence_and_matching_read_only_file_checks(self):
        with patch.object(agent, 'require_clock'), patch.object(agent, 'database_fenced', return_value=True), \
             patch.object(agent.pathlib.Path, 'is_dir', return_value=True), \
             patch.object(agent.pathlib.Path, 'resolve', lambda self: self), \
             patch.object(agent, 'command', return_value='') as cmd:
            result = agent.recover_evidence(self.cfg, self.req, self.source)
            self.assertEqual(cmd.call_count, 8)
            for call in cmd.call_args_list:
                self.assertIn('-rlcni', call.args[0])
                self.assertNotIn('--delete', call.args[0])
            for kind, receipt in result['proofs'].items():
                self.assertEqual(agent.verify_receipt(self.cfg, self.req, receipt, kind)['gtid'], '0-8111-98296')
        with patch.object(agent, 'require_clock'), patch.object(agent, 'database_fenced', return_value=False), \
             patch.object(agent, 'command') as cmd, self.assertRaises(agent.Refusal):
            agent.recover_evidence(self.cfg, self.req, self.source)
        cmd.assert_not_called()

    def test_file_drift_blocks_new_recovery_evidence(self):
        with patch.object(agent, 'require_clock'), patch.object(agent, 'database_fenced', return_value=True), \
             patch.object(agent.pathlib.Path, 'is_dir', return_value=True), \
             patch.object(agent.pathlib.Path, 'resolve', lambda self: self), \
             patch.object(agent, 'command', return_value='>fcs....... changed.conf'), self.assertRaisesRegex(agent.Refusal, 'checksums differ'):
            agent.recover_evidence(self.cfg, self.req, self.source)

    def test_target_gtid_divergence_blocks_recovery_before_mutation(self):
        cfg = {**self.cfg, 'host': 'dr'}
        req = {**self.req, 'host': 'dr', 'operation': 'recover-check'}
        state = {'steps': {'backup': 'complete', 'promote': 'failed'}, 'caughtUp': '0-8111-98296'}
        db = {'serverId': 30150, 'readOnly': True, 'logBin': True, 'logSlaveUpdates': True, 'eventScheduler': 'OFF',
              'gtidCurrent': '0-30150-99999', 'gtidSlave': '0-8111-98296'}
        with patch.object(agent, 'require_clock'), patch.object(agent, 'application_fenced', return_value=True), \
             patch.object(agent, 'db', return_value=db), patch.object(agent, 'sql') as sql, self.assertRaisesRegex(agent.Refusal, 'diverged'):
            agent.recover_check(cfg, req, state)
        sql.assert_not_called()

    def test_matching_target_can_recover_while_io_reconnects_to_intentionally_stopped_source(self):
        cfg = {**self.cfg, 'host': 'dr'}
        req = {**self.req, 'host': 'dr', 'operation': 'recover-check'}
        state = {'steps': {'backup': 'complete', 'promote': 'failed'}, 'caughtUp': '0-8111-98296'}
        database = {'serverId': 30150, 'readOnly': True, 'logBin': True, 'logSlaveUpdates': True, 'eventScheduler': 'OFF',
                    'gtidCurrent': state['caughtUp'], 'gtidSlave': state['caughtUp']}
        def sql(statement):
            if statement == 'SHOW ALL SLAVES STATUS':
                return 'Master_Host\tSlave_SQL_Running\tLast_SQL_Error\tSlave_IO_Running\n10.81.0.11\tYes\t\tConnecting\n'
            if statement == 'SELECT @@replicate_wild_ignore_table':
                return 'filters\n' + ','.join('convoxcces_global.' + t for t in agent.TABLES) + '\n'
            if statement.startswith('SELECT COUNT(*)'):
                return 'count\n1\n'
            self.fail('Unexpected SQL: ' + statement)
        with patch.object(agent, 'require_clock'), patch.object(agent, 'application_fenced', return_value=True), \
             patch.object(agent, 'db', return_value=database), patch.object(agent, 'sql', side_effect=sql), \
             patch.object(agent, 'services_from_config'), patch.object(agent, 'wrapper_environment'), \
             patch.object(agent, 'command', return_value=''):
            self.assertTrue(agent.recover_check(cfg, req, state)['ready'])

    def test_mutating_recovery_is_single_attempt_and_marks_original_promotion_complete(self):
        cfg = {**self.cfg, 'host': 'dr', 'adminReviewedStartup': True}
        req = {**self.req, 'host': 'dr', 'operation': 'recover-promote'}
        state = {'jobId': req['jobId'], 'source': req['source'], 'target': req['target'], 'preflightPassed': True,
                 'steps': {'recover-check': 'complete', 'backup': 'complete', 'promote': 'failed'}}
        with tempfile.TemporaryDirectory() as directory, patch.object(agent, 'ROOT', pathlib.Path(directory)):
            agent.atomic_json(agent.ROOT / 'operation.json', state)
            with patch.object(agent, 'recover_check'), patch.object(agent, 'promote', return_value={'ok': True}) as promote:
                self.assertTrue(agent.dispatch(cfg, req)['ok'])
                self.assertEqual(promote.call_args.kwargs, {'recovery': True})
                with self.assertRaises(agent.Refusal):
                    agent.dispatch(cfg, req)
                self.assertEqual(promote.call_count, 1)
            saved = agent.json.loads((agent.ROOT / 'operation.json').read_text())
            self.assertEqual(saved['steps']['promote'], 'complete')
            self.assertTrue(saved['recoveredPromotion'])
